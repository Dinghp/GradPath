from __future__ import annotations

import math
from typing import Dict, Iterable, Optional, Sequence, Union

import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================
# DPT decoder
# ============================================================

def _make_scratch(
    in_shape,
    out_shape,
    groups=1,
    expand=False,
):
    scratch = nn.Module()

    out_shape1 = out_shape
    out_shape2 = out_shape
    out_shape3 = out_shape

    if len(in_shape) >= 4:
        out_shape4 = out_shape

    if expand:
        out_shape1 = out_shape
        out_shape2 = out_shape * 2
        out_shape3 = out_shape * 4

        if len(in_shape) >= 4:
            out_shape4 = out_shape * 8

    scratch.layer1_rn = nn.Conv2d(
        in_shape[0],
        out_shape1,
        kernel_size=3,
        stride=1,
        padding=1,
        bias=False,
        groups=groups,
    )
    scratch.layer2_rn = nn.Conv2d(
        in_shape[1],
        out_shape2,
        kernel_size=3,
        stride=1,
        padding=1,
        bias=False,
        groups=groups,
    )
    scratch.layer3_rn = nn.Conv2d(
        in_shape[2],
        out_shape3,
        kernel_size=3,
        stride=1,
        padding=1,
        bias=False,
        groups=groups,
    )

    if len(in_shape) >= 4:
        scratch.layer4_rn = nn.Conv2d(
            in_shape[3],
            out_shape4,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=False,
            groups=groups,
        )

    return scratch


class ResidualConvUnit(nn.Module):
    def __init__(
        self,
        features,
        activation,
        bn,
    ):
        super().__init__()

        self.bn = bool(bn)
        self.activation = activation
        self.skip_add = nn.quantized.FloatFunctional()

        self.conv1 = nn.Conv2d(
            features,
            features,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=True,
        )
        self.conv2 = nn.Conv2d(
            features,
            features,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=True,
        )

        if self.bn:
            self.bn1 = nn.BatchNorm2d(features)
            self.bn2 = nn.BatchNorm2d(features)

    def forward(self, x):
        out = self.activation(x)
        out = self.conv1(out)

        if self.bn:
            out = self.bn1(out)

        out = self.activation(out)
        out = self.conv2(out)

        if self.bn:
            out = self.bn2(out)

        return self.skip_add.add(out, x)


class FeatureFusionBlock(nn.Module):
    def __init__(
        self,
        features,
        activation,
        bn=False,
        expand=False,
        align_corners=True,
        size=None,
    ):
        super().__init__()

        self.align_corners = align_corners
        self.size = size

        out_features = features // 2 if expand else features

        self.out_conv = nn.Conv2d(
            features,
            out_features,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=True,
        )
        self.resConfUnit1 = ResidualConvUnit(
            features,
            activation,
            bn,
        )
        self.resConfUnit2 = ResidualConvUnit(
            features,
            activation,
            bn,
        )
        self.skip_add = nn.quantized.FloatFunctional()

    def forward(self, *xs, size=None):
        output = xs[0]

        if len(xs) == 2:
            residual = self.resConfUnit1(xs[1])
            output = self.skip_add.add(
                output,
                residual,
            )

        output = self.resConfUnit2(output)

        if size is None and self.size is None:
            modifier = {"scale_factor": 2}
        elif size is None:
            modifier = {"size": self.size}
        else:
            modifier = {"size": size}

        output = F.interpolate(
            output,
            **modifier,
            mode="bilinear",
            align_corners=self.align_corners,
        )

        return self.out_conv(output)


def _make_fusion_block(
    features,
    use_bn,
    size=None,
):
    return FeatureFusionBlock(
        features,
        nn.ReLU(False),
        bn=use_bn,
        expand=False,
        align_corners=True,
        size=size,
    )


class DPTHead(nn.Module):
    def __init__(
        self,
        nclass,
        in_channels,
        features=128,
        use_bn=False,
        out_channels=(96, 192, 384, 768),
    ):
        super().__init__()

        self.projects = nn.ModuleList(
            [
                nn.Conv2d(
                    in_channels=in_channels,
                    out_channels=out_channel,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
                for out_channel in out_channels
            ]
        )

        self.resize_layers = nn.ModuleList(
            [
                nn.ConvTranspose2d(
                    in_channels=out_channels[0],
                    out_channels=out_channels[0],
                    kernel_size=4,
                    stride=4,
                    padding=0,
                ),
                nn.ConvTranspose2d(
                    in_channels=out_channels[1],
                    out_channels=out_channels[1],
                    kernel_size=2,
                    stride=2,
                    padding=0,
                ),
                nn.Identity(),
                nn.Conv2d(
                    in_channels=out_channels[3],
                    out_channels=out_channels[3],
                    kernel_size=3,
                    stride=2,
                    padding=1,
                ),
            ]
        )

        self.scratch = _make_scratch(
            out_channels,
            features,
            groups=1,
            expand=False,
        )

        self.scratch.refinenet1 = _make_fusion_block(
            features,
            use_bn,
        )
        self.scratch.refinenet2 = _make_fusion_block(
            features,
            use_bn,
        )
        self.scratch.refinenet3 = _make_fusion_block(
            features,
            use_bn,
        )
        self.scratch.refinenet4 = _make_fusion_block(
            features,
            use_bn,
        )

        self.scratch.output_conv = nn.Sequential(
            nn.Conv2d(
                features,
                features,
                kernel_size=3,
                stride=1,
                padding=1,
            ),
            nn.ReLU(True),
            nn.Conv2d(
                features,
                nclass,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
        )

    def forward(
        self,
        out_features,
        patch_h,
        patch_w,
    ):
        outputs = []

        for index, feature in enumerate(out_features):
            feature = feature.permute(
                0,
                2,
                1,
            ).reshape(
                feature.shape[0],
                feature.shape[-1],
                patch_h,
                patch_w,
            )

            feature = self.projects[index](feature)
            feature = self.resize_layers[index](feature)
            outputs.append(feature)

        layer_1, layer_2, layer_3, layer_4 = outputs

        layer_1_rn = self.scratch.layer1_rn(layer_1)
        layer_2_rn = self.scratch.layer2_rn(layer_2)
        layer_3_rn = self.scratch.layer3_rn(layer_3)
        layer_4_rn = self.scratch.layer4_rn(layer_4)

        path_4 = self.scratch.refinenet4(
            layer_4_rn,
            size=layer_3_rn.shape[2:],
        )
        path_3 = self.scratch.refinenet3(
            path_4,
            layer_3_rn,
            size=layer_2_rn.shape[2:],
        )
        path_2 = self.scratch.refinenet2(
            path_3,
            layer_2_rn,
            size=layer_1_rn.shape[2:],
        )
        path_1 = self.scratch.refinenet1(
            path_2,
            layer_1_rn,
        )

        return self.scratch.output_conv(path_1)


# ============================================================
# Partial row/column linear layers
# ============================================================

class _PartialRowLinearFunction(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        x,
        weight,
        bias,
        selected_rows,
        selected_bias,
        selected_indices,
        scaling,
    ):
        ctx.scaling = float(scaling)
        ctx.row_parameter_dtype = selected_rows.dtype
        ctx.bias_parameter_dtype = (
            selected_bias.dtype
            if selected_bias is not None
            else None
        )
        ctx.has_selected_bias = (
            selected_bias is not None
        )
        ctx.save_for_backward(
            x,
            weight,
            selected_indices,
        )

        return F.linear(
            x,
            weight,
            bias,
        )

    @staticmethod
    def backward(
        ctx,
        grad_output,
    ):
        x, weight, selected_indices = ctx.saved_tensors

        grad_x = None
        grad_selected_rows = None
        grad_selected_bias = None
        selected_grad_output = None

        if ctx.needs_input_grad[0]:
            grad_x = torch.matmul(
                grad_output,
                weight.to(dtype=grad_output.dtype),
            )

        if (
            ctx.needs_input_grad[3]
            or (
                ctx.has_selected_bias
                and ctx.needs_input_grad[4]
            )
        ):
            selected_grad_output = grad_output.index_select(
                dim=-1,
                index=selected_indices,
            )

        if ctx.needs_input_grad[3]:
            selected_grad_output_2d = selected_grad_output.reshape(
                -1,
                selected_grad_output.shape[-1],
            )
            x_2d = x.reshape(
                -1,
                x.shape[-1],
            )

            grad_selected_rows = (
                selected_grad_output_2d.float().transpose(0, 1)
                @ x_2d.float()
            )
            grad_selected_rows.mul_(ctx.scaling)
            grad_selected_rows = grad_selected_rows.to(
                ctx.row_parameter_dtype
            )

        if (
            ctx.has_selected_bias
            and ctx.needs_input_grad[4]
        ):
            reduce_dims = tuple(
                range(
                    selected_grad_output.ndim - 1
                )
            )
            grad_selected_bias = (
                selected_grad_output.float().sum(
                    dim=reduce_dims
                )
            )
            grad_selected_bias.mul_(ctx.scaling)
            grad_selected_bias = grad_selected_bias.to(
                ctx.bias_parameter_dtype
            )

        return (
            grad_x,
            None,
            None,
            grad_selected_rows,
            grad_selected_bias,
            None,
            None,
        )


class _PartialColumnLinearFunction(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        x,
        weight,
        bias,
        selected_columns,
        selected_indices,
        scaling,
    ):
        selected_x = x.index_select(
            dim=-1,
            index=selected_indices,
        )

        ctx.scaling = float(scaling)
        ctx.parameter_dtype = selected_columns.dtype
        ctx.save_for_backward(
            selected_x,
            weight,
        )

        return F.linear(
            x,
            weight,
            bias,
        )

    @staticmethod
    def backward(
        ctx,
        grad_output,
    ):
        selected_x, weight = ctx.saved_tensors

        grad_x = None
        grad_selected_columns = None

        if ctx.needs_input_grad[0]:
            grad_x = torch.matmul(
                grad_output,
                weight.to(dtype=grad_output.dtype),
            )

        if ctx.needs_input_grad[3]:
            grad_output_2d = grad_output.reshape(
                -1,
                grad_output.shape[-1],
            )
            selected_x_2d = selected_x.reshape(
                -1,
                selected_x.shape[-1],
            )

            grad_selected_columns = (
                grad_output_2d.float().transpose(0, 1)
                @ selected_x_2d.float()
            )
            grad_selected_columns.mul_(ctx.scaling)
            grad_selected_columns = grad_selected_columns.to(
                ctx.parameter_dtype
            )

        return (
            grad_x,
            None,
            None,
            grad_selected_columns,
            None,
            None,
        )


class PartialRowLinear(nn.Module):
    def __init__(
        self,
        in_features,
        out_features,
        selected_indices,
        bias=True,
        alpha=None,
        update_selected_bias=False,
        device=None,
        dtype=None,
    ):
        super().__init__()

        indices = torch.as_tensor(
            selected_indices,
            dtype=torch.long,
            device="cpu",
        ).flatten()

        if indices.numel() == 0:
            raise ValueError(
                "selected_indices cannot be empty"
            )
        if indices.unique().numel() != indices.numel():
            raise ValueError(
                "selected_indices must not contain duplicates"
            )
        if (
            indices.min().item() < 0
            or indices.max().item() >= out_features
        ):
            raise ValueError(
                "selected row index is out of range"
            )

        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.rank = int(indices.numel())
        self.alpha = float(
            alpha if alpha is not None else self.rank
        )
        self.scaling = self.alpha / self.rank
        self.update_selected_bias = bool(
            update_selected_bias
        )

        self.weight = nn.Parameter(
            torch.empty(
                out_features,
                in_features,
                device=device,
                dtype=dtype,
            ),
            requires_grad=False,
        )

        if bias:
            self.bias = nn.Parameter(
                torch.empty(
                    out_features,
                    device=device,
                    dtype=dtype,
                ),
                requires_grad=False,
            )
        else:
            self.register_parameter(
                "bias",
                None,
            )

        self.register_buffer(
            "selected_indices",
            indices,
            persistent=True,
        )

        self.selected_rows = nn.Parameter(
            torch.empty(
                self.rank,
                in_features,
                device=device,
                dtype=dtype,
            ),
            requires_grad=True,
        )

        if (
            self.bias is not None
            and self.update_selected_bias
        ):
            self.selected_bias = nn.Parameter(
                torch.empty(
                    self.rank,
                    device=device,
                    dtype=dtype,
                ),
                requires_grad=True,
            )
        else:
            self.register_parameter(
                "selected_bias",
                None,
            )

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(
            self.weight,
            a=math.sqrt(5),
        )

        if self.bias is not None:
            fan_in, _ = nn.init._calculate_fan_in_and_fan_out(
                self.weight
            )
            bound = (
                1 / math.sqrt(fan_in)
                if fan_in > 0
                else 0
            )
            nn.init.uniform_(
                self.bias,
                -bound,
                bound,
            )

        with torch.no_grad():
            indices = self.selected_indices.to(
                self.weight.device
            )
            selected = self.weight.index_select(
                dim=0,
                index=indices,
            )
            self.selected_rows.copy_(
                selected / self.scaling
            )

            if self.selected_bias is not None:
                selected_bias = self.bias.index_select(
                    dim=0,
                    index=indices,
                )
                self.selected_bias.copy_(
                    selected_bias / self.scaling
                )

    @classmethod
    def from_linear(
        cls,
        linear,
        selected_indices,
        alpha=None,
        update_selected_bias=False,
    ):
        layer = cls(
            in_features=linear.in_features,
            out_features=linear.out_features,
            selected_indices=selected_indices,
            bias=linear.bias is not None,
            alpha=alpha,
            update_selected_bias=update_selected_bias,
            device=linear.weight.device,
            dtype=linear.weight.dtype,
        )

        with torch.no_grad():
            layer.weight.copy_(
                linear.weight
            )

            if linear.bias is not None:
                layer.bias.copy_(
                    linear.bias
                )

            indices = layer.selected_indices.to(
                layer.weight.device
            )
            selected = layer.weight.index_select(
                dim=0,
                index=indices,
            )
            layer.selected_rows.copy_(
                selected / layer.scaling
            )

            if layer.selected_bias is not None:
                selected_bias = layer.bias.index_select(
                    dim=0,
                    index=indices,
                )
                layer.selected_bias.copy_(
                    selected_bias / layer.scaling
                )

            layer.sync_weight()

        return layer

    @torch.no_grad()
    def sync_weight(self):
        indices = self.selected_indices.to(
            self.weight.device
        )
        updated_rows = (
            self.scaling * self.selected_rows
        )

        self.weight.index_copy_(
            dim=0,
            index=indices,
            source=updated_rows.to(
                device=self.weight.device,
                dtype=self.weight.dtype,
            ),
        )

        if self.selected_bias is not None:
            updated_bias = (
                self.scaling * self.selected_bias
            )
            self.bias.index_copy_(
                dim=0,
                index=indices,
                source=updated_bias.to(
                    device=self.bias.device,
                    dtype=self.bias.dtype,
                ),
            )

    def forward(self, x):
        self.sync_weight()

        return _PartialRowLinearFunction.apply(
            x,
            self.weight,
            self.bias,
            self.selected_rows,
            self.selected_bias,
            self.selected_indices.to(x.device),
            self.scaling,
        )

    @torch.no_grad()
    def to_merged_linear(self):
        self.sync_weight()

        merged = nn.Linear(
            self.in_features,
            self.out_features,
            bias=self.bias is not None,
            device=self.weight.device,
            dtype=self.weight.dtype,
        )
        merged.weight.copy_(
            self.weight
        )

        if self.bias is not None:
            merged.bias.copy_(
                self.bias
            )

        return merged


class PartialColumnLinear(nn.Module):
    def __init__(
        self,
        in_features,
        out_features,
        selected_indices,
        bias=True,
        alpha=None,
        device=None,
        dtype=None,
    ):
        super().__init__()

        indices = torch.as_tensor(
            selected_indices,
            dtype=torch.long,
            device="cpu",
        ).flatten()

        if indices.numel() == 0:
            raise ValueError(
                "selected_indices cannot be empty"
            )
        if indices.unique().numel() != indices.numel():
            raise ValueError(
                "selected_indices must not contain duplicates"
            )
        if (
            indices.min().item() < 0
            or indices.max().item() >= in_features
        ):
            raise ValueError(
                "selected column index is out of range"
            )

        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.rank = int(indices.numel())
        self.alpha = float(
            alpha if alpha is not None else self.rank
        )
        self.scaling = self.alpha / self.rank

        self.weight = nn.Parameter(
            torch.empty(
                out_features,
                in_features,
                device=device,
                dtype=dtype,
            ),
            requires_grad=False,
        )

        if bias:
            self.bias = nn.Parameter(
                torch.empty(
                    out_features,
                    device=device,
                    dtype=dtype,
                ),
                requires_grad=False,
            )
        else:
            self.register_parameter(
                "bias",
                None,
            )

        self.register_buffer(
            "selected_indices",
            indices,
            persistent=True,
        )

        self.selected_columns = nn.Parameter(
            torch.empty(
                out_features,
                self.rank,
                device=device,
                dtype=dtype,
            ),
            requires_grad=True,
        )

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(
            self.weight,
            a=math.sqrt(5),
        )

        if self.bias is not None:
            fan_in, _ = nn.init._calculate_fan_in_and_fan_out(
                self.weight
            )
            bound = (
                1 / math.sqrt(fan_in)
                if fan_in > 0
                else 0
            )
            nn.init.uniform_(
                self.bias,
                -bound,
                bound,
            )

        with torch.no_grad():
            indices = self.selected_indices.to(
                self.weight.device
            )
            selected = self.weight.index_select(
                dim=1,
                index=indices,
            )
            self.selected_columns.copy_(
                selected / self.scaling
            )

    @classmethod
    def from_linear(
        cls,
        linear,
        selected_indices,
        alpha=None,
    ):
        layer = cls(
            in_features=linear.in_features,
            out_features=linear.out_features,
            selected_indices=selected_indices,
            bias=linear.bias is not None,
            alpha=alpha,
            device=linear.weight.device,
            dtype=linear.weight.dtype,
        )

        with torch.no_grad():
            layer.weight.copy_(
                linear.weight
            )

            if linear.bias is not None:
                layer.bias.copy_(
                    linear.bias
                )

            indices = layer.selected_indices.to(
                layer.weight.device
            )
            selected = layer.weight.index_select(
                dim=1,
                index=indices,
            )
            layer.selected_columns.copy_(
                selected / layer.scaling
            )
            layer.sync_weight()

        return layer

    @torch.no_grad()
    def sync_weight(self):
        indices = self.selected_indices.to(
            self.weight.device
        )
        updated_columns = (
            self.scaling * self.selected_columns
        )

        self.weight.index_copy_(
            dim=1,
            index=indices,
            source=updated_columns.to(
                device=self.weight.device,
                dtype=self.weight.dtype,
            ),
        )

    def forward(self, x):
        self.sync_weight()

        return _PartialColumnLinearFunction.apply(
            x,
            self.weight,
            self.bias,
            self.selected_columns,
            self.selected_indices.to(x.device),
            self.scaling,
        )

    @torch.no_grad()
    def to_merged_linear(self):
        self.sync_weight()

        merged = nn.Linear(
            self.in_features,
            self.out_features,
            bias=self.bias is not None,
            device=self.weight.device,
            dtype=self.weight.dtype,
        )
        merged.weight.copy_(
            self.weight
        )

        if self.bias is not None:
            merged.bias.copy_(
                self.bias
            )

        return merged


# ============================================================
# Multi-kernel depthwise spatial enhancement for selected paths
# ============================================================
class MonaOp(nn.Module):
    """
    Multi-kernel depthwise spatial operator.

    For a non-empty subset K of {3, 5, 7}:
        conv_mean = mean(DWConv_k(x), k in K)
        alpha = sigmoid(gamma)
        out = (1 - alpha) * x + alpha * conv_mean

    gamma_init=-5 gives alpha ~= 0.0067, so the selected hidden
    features stay close to the pretrained representation initially.
    """

    SUPPORTED_KERNELS = (3, 5, 7)

    def __init__(
        self,
        in_features,
        kernels=(3, 5, 7),
        gamma_init=-5.0,
        device=None,
        dtype=None,
    ):
        super().__init__()

        kernels = tuple(int(kernel) for kernel in kernels)
        if not kernels:
            raise ValueError("kernels cannot be empty")
        if len(set(kernels)) != len(kernels):
            raise ValueError("kernels must not contain duplicates")

        unsupported = [
            kernel
            for kernel in kernels
            if kernel not in self.SUPPORTED_KERNELS
        ]
        if unsupported:
            raise ValueError(
                "Only kernel sizes 3, 5, and 7 are supported, "
                "but got unsupported values: {}".format(unsupported)
            )

        self.kernels = kernels
        factory_kwargs = {
            "device": device,
            "dtype": dtype,
        }

        self.convs = nn.ModuleList(
            [
                nn.Conv2d(
                    in_features,
                    in_features,
                    kernel_size=kernel,
                    padding=kernel // 2,
                    groups=in_features,
                    **factory_kwargs,
                )
                for kernel in self.kernels
            ]
        )

        self.gamma = nn.Parameter(
            torch.tensor(
                float(gamma_init),
                device=device,
                dtype=dtype,
            ),
            requires_grad=True,
        )

    def forward(self, x):
        branch_outputs = [conv(x) for conv in self.convs]
        conv_mean = torch.stack(branch_outputs, dim=0).mean(dim=0)
        alpha = torch.sigmoid(self.gamma)
        return (1.0 - alpha) * x + alpha * conv_mean


class SelectedMonaSpatial(nn.Module):
    """
    Apply MonaOp only to the GradAct-selected hidden channels.

    spatial_dim <= 0 means spatial_dim == rank, so no 1x1 down/up
    projections are inserted. If spatial_dim != rank, lightweight
    1x1 projections are used around MonaOp.
    """

    def __init__(
        self,
        rank,
        spatial_dim=0,
        kernels=(3, 5, 7),
        gamma_init=-5.0,
        device=None,
        dtype=None,
    ):
        super().__init__()

        self.rank = int(rank)
        self.spatial_dim = (
            self.rank
            if spatial_dim is None or int(spatial_dim) <= 0
            else int(spatial_dim)
        )
        self.kernels = tuple(int(kernel) for kernel in kernels)

        if self.rank <= 0:
            raise ValueError("rank must be positive")
        if self.spatial_dim <= 0:
            raise ValueError("spatial_dim must be positive")

        factory_kwargs = {
            "device": device,
            "dtype": dtype,
        }

        if self.spatial_dim == self.rank:
            self.down = nn.Identity()
            self.up = nn.Identity()
        else:
            self.down = nn.Conv2d(
                self.rank,
                self.spatial_dim,
                kernel_size=1,
                bias=False,
                **factory_kwargs,
            )
            self.up = nn.Conv2d(
                self.spatial_dim,
                self.rank,
                kernel_size=1,
                bias=False,
                **factory_kwargs,
            )

        self.mona = MonaOp(
            in_features=self.spatial_dim,
            kernels=self.kernels,
            gamma_init=gamma_init,
            device=device,
            dtype=dtype,
        )

    def forward(self, x):
        x = self.down(x)
        x = self.mona(x)
        x = self.up(x)
        return x


class SpatialPartialColumnLinear(PartialColumnLinear):
    """
    Output projection with spatial enhancement on selected hidden channels.

    DINOv3 hidden input is expected as [B, N, H]. Only real image patch
    tokens are enhanced. CLS and storage tokens remain unchanged.
    """

    def __init__(
        self,
        in_features,
        out_features,
        selected_indices,
        bias=True,
        alpha=None,
        patch_start=1,
        spatial_dim=0,
        kernels=(3, 5, 7),
        gamma_init=-5.0,
        device=None,
        dtype=None,
    ):
        super().__init__(
            in_features=in_features,
            out_features=out_features,
            selected_indices=selected_indices,
            bias=bias,
            alpha=alpha,
            device=device,
            dtype=dtype,
        )

        self.patch_start = int(patch_start)
        self.spatial_dim = int(spatial_dim)
        self.kernels = tuple(int(kernel) for kernel in kernels)
        self.gamma_init = float(gamma_init)
        self.patch_hw = None

        self.spatial_conv = SelectedMonaSpatial(
            rank=self.rank,
            spatial_dim=self.spatial_dim,
            kernels=self.kernels,
            gamma_init=self.gamma_init,
            device=device,
            dtype=dtype,
        )

    @classmethod
    def from_linear(
        cls,
        linear,
        selected_indices,
        alpha=None,
        patch_start=1,
        spatial_dim=0,
        kernels=(3, 5, 7),
        gamma_init=-5.0,
    ):
        layer = cls(
            in_features=linear.in_features,
            out_features=linear.out_features,
            selected_indices=selected_indices,
            bias=linear.bias is not None,
            alpha=alpha,
            patch_start=patch_start,
            spatial_dim=spatial_dim,
            kernels=kernels,
            gamma_init=gamma_init,
            device=linear.weight.device,
            dtype=linear.weight.dtype,
        )

        with torch.no_grad():
            layer.weight.copy_(linear.weight)
            if linear.bias is not None:
                layer.bias.copy_(linear.bias)

            indices = layer.selected_indices.to(layer.weight.device)
            selected = layer.weight.index_select(dim=1, index=indices)
            layer.selected_columns.copy_(selected / layer.scaling)
            layer.sync_weight()

        return layer

    def set_patch_grid(self, patch_h, patch_w):
        patch_h = int(patch_h)
        patch_w = int(patch_w)
        if patch_h <= 0 or patch_w <= 0:
            raise ValueError("patch_h and patch_w must be positive")
        self.patch_hw = (patch_h, patch_w)

    def _spatial_enhance(self, x):
        if x.ndim != 3:
            raise ValueError(
                "SpatialPartialColumnLinear expects [B, N, H], got {}".format(
                    tuple(x.shape)
                )
            )
        if x.shape[1] <= self.patch_start:
            raise RuntimeError(
                "No patch tokens remain after removing CLS/storage tokens"
            )

        prefix = x[:, :self.patch_start, :]
        patch_tokens = x[:, self.patch_start:, :]
        indices = self.selected_indices.to(x.device)

        selected = patch_tokens.index_select(dim=-1, index=indices)
        batch_size, patch_num, _ = selected.shape

        if self.patch_hw is None:
            side = int(math.isqrt(patch_num))
            if side * side != patch_num:
                raise RuntimeError(
                    "Patch grid is unknown and patch_num={} is not square. "
                    "Call set_patch_grid() before forward.".format(patch_num)
                )
            patch_h, patch_w = side, side
        else:
            patch_h, patch_w = self.patch_hw
            if patch_h * patch_w != patch_num:
                raise RuntimeError(
                    "Patch grid {}x{} does not match patch_num={}".format(
                        patch_h, patch_w, patch_num
                    )
                )

        selected_2d = (
            selected.transpose(1, 2)
            .contiguous()
            .view(batch_size, self.rank, patch_h, patch_w)
        )
        enhanced_2d = self.spatial_conv(selected_2d)
        enhanced = (
            enhanced_2d.flatten(2)
            .transpose(1, 2)
            .contiguous()
        )

        enhanced_patch_tokens = patch_tokens.clone()
        enhanced_patch_tokens.index_copy_(
            dim=-1,
            index=indices,
            source=enhanced,
        )

        return torch.cat(
            [prefix, enhanced_patch_tokens],
            dim=1,
        )

    def forward(self, x):
        self.sync_weight()
        enhanced_x = self._spatial_enhance(x)

        return _PartialColumnLinearFunction.apply(
            enhanced_x,
            self.weight,
            self.bias,
            self.selected_columns,
            self.selected_indices.to(x.device),
            self.scaling,
        )


def set_spatial_patch_grid(backbone, patch_h, patch_w):
    for module in backbone.modules():
        if isinstance(module, SpatialPartialColumnLinear):
            module.set_patch_grid(patch_h, patch_w)


# ============================================================
# DINOv3 FFN discovery and importance collection
# ============================================================

def normalize_target_blocks(
    depth,
    target_blocks,
):
    if target_blocks is None or target_blocks == "all":
        return list(range(depth))

    if isinstance(target_blocks, str):
        value = target_blocks.lower().replace(
            " ",
            "",
        )

        if value.startswith("last"):
            count = int(value[4:])

            if not 1 <= count <= depth:
                raise ValueError(
                    "Invalid target_blocks={}".format(
                        target_blocks
                    )
                )

            return list(
                range(
                    depth - count,
                    depth,
                )
            )

        if "," in value:
            target_blocks = [
                int(index)
                for index in value.split(",")
                if index
            ]
        else:
            target_blocks = [int(value)]

    indices = sorted(
        {
            int(index)
            for index in target_blocks
        }
    )

    if not indices:
        raise ValueError(
            "target_blocks cannot be empty"
        )
    if indices[0] < 0 or indices[-1] >= depth:
        raise ValueError(
            "target_blocks must be within [0, {}]".format(
                depth - 1
            )
        )

    return indices


def identify_ffn_type(ffn):
    if (
        hasattr(ffn, "fc1")
        and hasattr(ffn, "fc2")
        and isinstance(ffn.fc1, nn.Linear)
        and isinstance(ffn.fc2, nn.Linear)
    ):
        return "mlp"

    if (
        hasattr(ffn, "w1")
        and hasattr(ffn, "w2")
        and hasattr(ffn, "w3")
        and isinstance(ffn.w1, nn.Linear)
        and isinstance(ffn.w2, nn.Linear)
        and isinstance(ffn.w3, nn.Linear)
    ):
        return "swiglu"

    raise TypeError(
        "Unsupported DINOv3 FFN structure: {}. "
        "Expected fc1/fc2 MLP or w1/w2/w3 SwiGLU.".format(
            type(ffn).__name__
        )
    )


def get_ffn_output_projection(ffn):
    ffn_type = identify_ffn_type(ffn)

    if ffn_type == "mlp":
        return ffn.fc2

    return ffn.w3


class GradientActivationImportanceCollector:
    def __init__(
        self,
        backbone,
        block_indices,
        token_mode="patch",
        balance_mode="foreground_background",
    ):
        token_mode = token_mode.lower()
        balance_mode = balance_mode.lower()

        if token_mode not in {
            "all",
            "cls",
            "patch",
        }:
            raise ValueError(
                "token_mode must be all, cls, or patch"
            )

        if balance_mode not in {
            "none",
            "foreground_background",
        }:
            raise ValueError(
                "balance_mode must be none or foreground_background"
            )

        if (
            balance_mode == "foreground_background"
            and token_mode != "patch"
        ):
            raise ValueError(
                "foreground/background balancing requires token_mode=patch"
            )

        self.backbone = backbone
        self.block_indices = list(
            block_indices
        )
        self.token_mode = token_mode
        self.balance_mode = balance_mode
        self.patch_start = (
            1
            + int(
                getattr(
                    backbone,
                    "n_storage_tokens",
                    0,
                )
            )
        )

        self.scores = {}
        self.counts = {}
        self.foreground_scores = {}
        self.background_scores = {}
        self.foreground_mass = {}
        self.background_mass = {}
        self.ffn_types = {}
        self.handles = []
        self.current_foreground_ratio = None

        for block_index in self.block_indices:
            ffn = backbone.blocks[
                block_index
            ].mlp
            ffn_type = identify_ffn_type(
                ffn
            )
            output_projection = get_ffn_output_projection(
                ffn
            )
            hidden_dim = output_projection.in_features

            self.ffn_types[block_index] = ffn_type
            self.scores[block_index] = torch.zeros(
                hidden_dim,
                dtype=torch.float64,
                device="cpu",
            )
            self.counts[block_index] = 0
            self.foreground_scores[block_index] = torch.zeros(
                hidden_dim,
                dtype=torch.float64,
                device="cpu",
            )
            self.background_scores[block_index] = torch.zeros(
                hidden_dim,
                dtype=torch.float64,
                device="cpu",
            )
            self.foreground_mass[block_index] = 0.0
            self.background_mass[block_index] = 0.0

            handle = output_projection.register_forward_hook(
                self._make_forward_hook(
                    block_index
                )
            )
            self.handles.append(handle)

    def set_foreground_ratio(
        self,
        foreground_ratio,
    ):
        if self.balance_mode == "none":
            self.current_foreground_ratio = None
            return

        if foreground_ratio.ndim != 2:
            raise ValueError(
                "foreground_ratio must have shape [B, patch_num]"
            )

        self.current_foreground_ratio = (
            foreground_ratio.detach()
            .float()
            .clamp(0.0, 1.0)
        )

    def select_tokens(
        self,
        tensor,
    ):
        if tensor.ndim != 3:
            return tensor

        if self.token_mode == "all":
            return tensor

        if self.token_mode == "cls":
            return tensor[:, :1, :]

        if tensor.shape[1] <= self.patch_start:
            raise RuntimeError(
                "No patch tokens remain after removing "
                "CLS and storage tokens"
            )

        return tensor[
            :,
            self.patch_start:,
            :,
        ]

    def _make_forward_hook(
        self,
        block_index,
    ):
        def forward_hook(
            module,
            inputs,
            output,
        ):
            del module, output

            hidden = inputs[0]

            if not hidden.requires_grad:
                raise RuntimeError(
                    "FFN hidden activation has no gradient graph. "
                    "Calibration images must require gradients."
                )

            activation = hidden.detach()

            if self.balance_mode == "foreground_background":
                if self.current_foreground_ratio is None:
                    raise RuntimeError(
                        "Foreground ratios were not set before forward"
                    )
                foreground_ratio = (
                    self.current_foreground_ratio.detach()
                )
            else:
                foreground_ratio = None

            def gradient_hook(
                gradient,
            ):
                selected_activation = self.select_tokens(
                    activation
                )
                selected_gradient = self.select_tokens(
                    gradient.detach()
                )

                contribution = (
                    selected_activation.float()
                    * selected_gradient.float()
                ).abs()

                if self.balance_mode == "foreground_background":
                    if contribution.ndim != 3:
                        raise RuntimeError(
                            "Balanced importance expects [B, P, H] activations"
                        )

                    if (
                        foreground_ratio.shape[0]
                        != contribution.shape[0]
                        or foreground_ratio.shape[1]
                        != contribution.shape[1]
                    ):
                        raise RuntimeError(
                            "Patch mask shape {} does not match FFN patch "
                            "tokens {}".format(
                                tuple(foreground_ratio.shape),
                                tuple(contribution.shape[:2]),
                            )
                        )

                    foreground_weight = foreground_ratio.to(
                        device=contribution.device,
                        dtype=contribution.dtype,
                    )
                    background_weight = 1.0 - foreground_weight

                    foreground_batch_mass = float(
                        foreground_weight.sum().detach().cpu()
                    )
                    background_batch_mass = float(
                        background_weight.sum().detach().cpu()
                    )

                    foreground_batch_score = (
                        contribution
                        * foreground_weight.unsqueeze(-1)
                    ).sum(dim=(0, 1))
                    background_batch_score = (
                        contribution
                        * background_weight.unsqueeze(-1)
                    ).sum(dim=(0, 1))

                    self.foreground_scores[block_index].add_(
                        foreground_batch_score.double().cpu()
                    )
                    self.background_scores[block_index].add_(
                        background_batch_score.double().cpu()
                    )
                    self.foreground_mass[block_index] += (
                        foreground_batch_mass
                    )
                    self.background_mass[block_index] += (
                        background_batch_mass
                    )
                else:
                    reduce_dims = tuple(
                        range(
                            contribution.ndim - 1
                        )
                    )
                    batch_score = contribution.sum(
                        dim=reduce_dims
                    )
                    sample_count = (
                        contribution.numel()
                        // contribution.shape[-1]
                    )

                    self.scores[block_index].add_(
                        batch_score.double().cpu()
                    )
                    self.counts[block_index] += int(
                        sample_count
                    )

            hidden.register_hook(
                gradient_hook
            )

        return forward_hook

    def normalized_scores(self):
        normalized = {}

        for block_index in self.block_indices:
            if self.balance_mode == "foreground_background":
                foreground_mass = self.foreground_mass[
                    block_index
                ]
                background_mass = self.background_mass[
                    block_index
                ]

                has_foreground = foreground_mass > 0.0
                has_background = background_mass > 0.0

                if has_foreground:
                    foreground_mean = (
                        self.foreground_scores[block_index]
                        / foreground_mass
                    )
                else:
                    foreground_mean = torch.zeros_like(
                        self.foreground_scores[block_index]
                    )

                if has_background:
                    background_mean = (
                        self.background_scores[block_index]
                        / background_mass
                    )
                else:
                    background_mean = torch.zeros_like(
                        self.background_scores[block_index]
                    )

                if has_foreground and has_background:
                    score = 0.5 * (
                        foreground_mean
                        + background_mean
                    )
                elif has_foreground:
                    score = foreground_mean
                elif has_background:
                    score = background_mean
                else:
                    raise RuntimeError(
                        "No foreground or background patch mass was collected"
                    )

                normalized[block_index] = score.float()
            else:
                count = max(
                    self.counts[block_index],
                    1,
                )
                normalized[block_index] = (
                    self.scores[block_index]
                    / count
                ).float()

        return normalized

    def balance_report(self):
        if self.balance_mode == "none":
            return {
                "mode": "none",
            }

        reference_block = self.block_indices[0]
        foreground_mass = self.foreground_mass[
            reference_block
        ]
        background_mass = self.background_mass[
            reference_block
        ]
        total_mass = foreground_mass + background_mass

        return {
            "mode": "foreground_background",
            "foreground_patch_mass": float(
                foreground_mass
            ),
            "background_patch_mass": float(
                background_mass
            ),
            "foreground_fraction": float(
                foreground_mass / max(total_mass, 1e-12)
            ),
            "background_fraction": float(
                background_mass / max(total_mass, 1e-12)
            ),
            "foreground_score_weight": 0.5,
            "background_score_weight": 0.5,
        }

    def close(self):
        for handle in self.handles:
            handle.remove()

        self.handles = []


def extract_images_masks(batch):
    if (
        isinstance(batch, (tuple, list))
        and len(batch) >= 2
    ):
        return batch[0], batch[1]

    if isinstance(batch, dict):
        image = None
        mask = None

        for key in (
            "image",
            "images",
            "input",
            "inputs",
            "x",
        ):
            if key in batch:
                image = batch[key]
                break

        for key in (
            "mask",
            "masks",
            "label",
            "labels",
            "target",
            "targets",
            "y",
        ):
            if key in batch:
                mask = batch[key]
                break

        if image is not None and mask is not None:
            return image, mask

    raise TypeError(
        "Each calibration batch must provide images and masks"
    )



def build_foreground_patch_ratio(
    masks,
    patch_h,
    patch_w,
):
    if masks.ndim == 3:
        masks = masks.unsqueeze(1)
    elif masks.ndim == 4 and masks.shape[-1] == 1:
        masks = masks.permute(0, 3, 1, 2)

    if masks.ndim != 4:
        raise ValueError(
            "Segmentation masks must have shape [B, H, W] or [B, C, H, W]"
        )

    if masks.shape[1] > 1:
        foreground_mask = masks.amax(
            dim=1,
            keepdim=True,
        )
    else:
        foreground_mask = masks

    foreground_mask = (
        foreground_mask > 0.5
    ).float()

    foreground_ratio = F.interpolate(
        foreground_mask,
        size=(patch_h, patch_w),
        mode="area",
    )

    return foreground_ratio.flatten(1)


def collect_gradient_activation_importance(
    model,
    data_loader,
    criterion,
    device,
    block_indices,
    num_batches=20,
    token_mode="patch",
    use_amp=False,
    balance_mode="foreground_background",
):
    if num_batches <= 0:
        raise ValueError(
            "num_batches must be positive"
        )

    if (
        balance_mode == "foreground_background"
        and token_mode != "patch"
    ):
        raise ValueError(
            "foreground/background balancing requires token_mode=patch"
        )

    device = torch.device(device)
    previous_training_state = model.training
    model.eval()

    collector = GradientActivationImportanceCollector(
        backbone=model.backbone,
        block_indices=block_indices,
        token_mode=token_mode,
        balance_mode=balance_mode,
    )

    amp_enabled = bool(
        use_amp
        and device.type == "cuda"
    )
    processed_batches = 0
    foreground_pixel_count = 0.0
    background_pixel_count = 0.0

    patch_size = model.backbone.patch_size
    if isinstance(patch_size, (tuple, list)):
        patch_size_h = int(patch_size[0])
        patch_size_w = int(patch_size[1])
    else:
        patch_size_h = int(patch_size)
        patch_size_w = int(patch_size)

    try:
        for batch_index, batch in enumerate(
            data_loader
        ):
            if batch_index >= num_batches:
                break

            images, masks = extract_images_masks(
                batch
            )
            images = images.to(
                device=device,
                dtype=torch.float32,
                non_blocking=True,
            )
            masks = masks.to(
                device=device,
                dtype=torch.float32,
                non_blocking=True,
            )

            if balance_mode == "foreground_background":
                patch_h = images.shape[-2] // patch_size_h
                patch_w = images.shape[-1] // patch_size_w

                foreground_ratio = build_foreground_patch_ratio(
                    masks=masks,
                    patch_h=patch_h,
                    patch_w=patch_w,
                )
                collector.set_foreground_ratio(
                    foreground_ratio
                )

                binary_mask = (
                    masks > 0.5
                ).float()
                foreground_pixel_count += float(
                    binary_mask.sum().detach().cpu()
                )
                background_pixel_count += float(
                    binary_mask.numel()
                    - binary_mask.sum().detach().cpu()
                )

            images = images.detach().requires_grad_(
                True
            )

            model.zero_grad(
                set_to_none=True
            )

            with torch.cuda.amp.autocast(
                enabled=amp_enabled,
            ):
                logits = model(images)
                loss = criterion(
                    logits,
                    masks,
                )

            loss.backward()
            processed_batches += 1

    finally:
        collector.close()
        model.train(
            previous_training_state
        )
        model.zero_grad(
            set_to_none=True
        )

    if processed_batches == 0:
        raise RuntimeError(
            "No calibration batch was processed"
        )

    balance_report = collector.balance_report()
    balance_report.update(
        {
            "foreground_pixel_count": float(
                foreground_pixel_count
            ),
            "background_pixel_count": float(
                background_pixel_count
            ),
            "processed_batches": int(
                processed_batches
            ),
        }
    )

    total_pixels = (
        foreground_pixel_count
        + background_pixel_count
    )
    if total_pixels > 0:
        balance_report[
            "foreground_pixel_fraction"
        ] = float(
            foreground_pixel_count
            / total_pixels
        )
        balance_report[
            "background_pixel_fraction"
        ] = float(
            background_pixel_count
            / total_pixels
        )

    return (
        collector.normalized_scores(),
        collector.ffn_types,
        balance_report,
    )


# ============================================================
# Selection
# ============================================================

def select_topk_per_block(
    importance_scores,
    rank_per_block,
):
    if rank_per_block <= 0:
        raise ValueError(
            "rank_per_block must be positive"
        )

    selected = {}

    for block_index, score in importance_scores.items():
        if rank_per_block > score.numel():
            raise ValueError(
                "rank_per_block={} exceeds hidden size={} "
                "in block {}".format(
                    rank_per_block,
                    score.numel(),
                    block_index,
                )
            )

        indices = torch.topk(
            score,
            k=rank_per_block,
            largest=True,
            sorted=False,
        ).indices

        selected[block_index] = (
            indices.sort().values.cpu()
        )

    return selected


def select_with_global_budget(
    importance_scores,
    total_budget,
    min_rank_per_block=16,
    max_rank_per_block=128,
    normalize_mode="mean",
    eps=1e-8,
):
    block_indices = sorted(
        importance_scores
    )

    if not block_indices:
        raise ValueError(
            "importance_scores cannot be empty"
        )
    if total_budget <= 0:
        raise ValueError(
            "total_budget must be positive"
        )
    if min_rank_per_block < 0:
        raise ValueError(
            "min_rank_per_block cannot be negative"
        )
    if max_rank_per_block <= 0:
        raise ValueError(
            "max_rank_per_block must be positive"
        )
    if min_rank_per_block > max_rank_per_block:
        raise ValueError(
            "minimum rank cannot exceed maximum rank"
        )

    normalize_mode = normalize_mode.lower()

    if normalize_mode not in {
        "mean",
        "l2",
        "max",
        "none",
    }:
        raise ValueError(
            "normalize_mode must be mean, l2, max, or none"
        )

    minimum_budget = (
        min_rank_per_block
        * len(block_indices)
    )
    maximum_budget = sum(
        min(
            max_rank_per_block,
            importance_scores[
                block_index
            ].numel(),
        )
        for block_index in block_indices
    )

    if total_budget < minimum_budget:
        raise ValueError(
            "total_budget={} is below minimum={}".format(
                total_budget,
                minimum_budget,
            )
        )
    if total_budget > maximum_budget:
        raise ValueError(
            "total_budget={} exceeds maximum={}".format(
                total_budget,
                maximum_budget,
            )
        )

    normalized_scores = {}

    for block_index in block_indices:
        score = (
            importance_scores[block_index]
            .detach()
            .float()
            .cpu()
            .clamp_min(0)
        )

        layer_max_rank = min(
            max_rank_per_block,
            score.numel(),
        )

        if min_rank_per_block > layer_max_rank:
            raise ValueError(
                "Block {} minimum rank {} exceeds maximum {}".format(
                    block_index,
                    min_rank_per_block,
                    layer_max_rank,
                )
            )

        if normalize_mode == "mean":
            denominator = score.mean()
        elif normalize_mode == "l2":
            denominator = torch.sqrt(
                torch.mean(
                    score.pow(2)
                )
            )
        elif normalize_mode == "max":
            denominator = score.max()
        else:
            denominator = torch.tensor(
                1.0,
                dtype=score.dtype,
            )

        normalized_scores[block_index] = (
            score
            / denominator.clamp_min(eps)
        )

    selected_sets = {
        block_index: set()
        for block_index in block_indices
    }

    for block_index in block_indices:
        if min_rank_per_block > 0:
            initial_indices = torch.topk(
                normalized_scores[block_index],
                k=min_rank_per_block,
                largest=True,
                sorted=False,
            ).indices.tolist()

            selected_sets[block_index].update(
                initial_indices
            )

    remaining_budget = (
        total_budget
        - minimum_budget
    )
    candidates = []

    for block_index in block_indices:
        score = normalized_scores[block_index]

        for neuron_index, value in enumerate(
            score.tolist()
        ):
            if neuron_index not in selected_sets[
                block_index
            ]:
                candidates.append(
                    (
                        float(value),
                        block_index,
                        neuron_index,
                    )
                )

    candidates.sort(
        key=lambda item: item[0],
        reverse=True,
    )

    allocated = 0

    for _, block_index, neuron_index in candidates:
        if allocated >= remaining_budget:
            break

        layer_max_rank = min(
            max_rank_per_block,
            normalized_scores[
                block_index
            ].numel(),
        )

        if (
            len(
                selected_sets[
                    block_index
                ]
            )
            >= layer_max_rank
        ):
            continue

        selected_sets[block_index].add(
            neuron_index
        )
        allocated += 1

    if allocated != remaining_budget:
        raise RuntimeError(
            "Only allocated {} of {} remaining paths".format(
                allocated,
                remaining_budget,
            )
        )

    return {
        block_index: torch.tensor(
            sorted(
                selected_sets[
                    block_index
                ]
            ),
            dtype=torch.long,
        )
        for block_index in block_indices
    }


# ============================================================
# Injection, freezing, optimizer groups
# ============================================================

def inject_paired_paths_into_dinov3(
    backbone,
    selected_indices,
    update_selected_bias=False,
    use_spatial=False,
    spatial_dim=0,
    spatial_kernels=(3, 5, 7),
    spatial_gamma_init=-5.0,
):
    ffn_type_by_block = {}
    patch_start = (
        1
        + int(
            getattr(
                backbone,
                "n_storage_tokens",
                0,
            )
        )
    )

    for block_index in sorted(selected_indices):
        indices = selected_indices[block_index]
        ffn = backbone.blocks[block_index].mlp
        ffn_type = identify_ffn_type(ffn)

        if ffn_type == "mlp":
            if ffn.fc1.out_features != ffn.fc2.in_features:
                raise ValueError(
                    "Block {} MLP hidden dimensions do not match".format(
                        block_index
                    )
                )

            old_fc1 = ffn.fc1
            old_fc2 = ffn.fc2
            ffn.fc1 = PartialRowLinear.from_linear(
                old_fc1,
                selected_indices=indices,
                update_selected_bias=update_selected_bias,
            )

            if use_spatial:
                ffn.fc2 = SpatialPartialColumnLinear.from_linear(
                    old_fc2,
                    selected_indices=indices,
                    patch_start=patch_start,
                    spatial_dim=spatial_dim,
                    kernels=spatial_kernels,
                    gamma_init=spatial_gamma_init,
                )
            else:
                ffn.fc2 = PartialColumnLinear.from_linear(
                    old_fc2,
                    selected_indices=indices,
                )

        else:
            hidden_dim = ffn.w3.in_features
            if (
                ffn.w1.out_features != hidden_dim
                or ffn.w2.out_features != hidden_dim
            ):
                raise ValueError(
                    "Block {} SwiGLU hidden dimensions do not match".format(
                        block_index
                    )
                )

            old_w1 = ffn.w1
            old_w2 = ffn.w2
            old_w3 = ffn.w3
            ffn.w1 = PartialRowLinear.from_linear(
                old_w1,
                selected_indices=indices,
                update_selected_bias=update_selected_bias,
            )
            ffn.w2 = PartialRowLinear.from_linear(
                old_w2,
                selected_indices=indices,
                update_selected_bias=update_selected_bias,
            )

            if use_spatial:
                ffn.w3 = SpatialPartialColumnLinear.from_linear(
                    old_w3,
                    selected_indices=indices,
                    patch_start=patch_start,
                    spatial_dim=spatial_dim,
                    kernels=spatial_kernels,
                    gamma_init=spatial_gamma_init,
                )
            else:
                ffn.w3 = PartialColumnLinear.from_linear(
                    old_w3,
                    selected_indices=indices,
                )

        ffn_type_by_block[block_index] = ffn_type

    return ffn_type_by_block


@torch.no_grad()
def sync_all_selected_weights(
    model,
):
    for module in model.modules():
        if isinstance(
            module,
            (
                PartialRowLinear,
                PartialColumnLinear,
            ),
        ):
            module.sync_weight()


@torch.no_grad()
def merge_all_selected_paths(
    backbone,
):
    for block in backbone.blocks:
        ffn = block.mlp

        if hasattr(ffn, "fc1"):
            if isinstance(ffn.fc1, PartialRowLinear):
                ffn.fc1 = ffn.fc1.to_merged_linear()

            if isinstance(ffn.fc2, SpatialPartialColumnLinear):
                # Spatial token mixing cannot be folded into a single Linear.
                # Keep the spatial output projection and only synchronize its
                # selected columns.
                ffn.fc2.sync_weight()
            elif isinstance(ffn.fc2, PartialColumnLinear):
                ffn.fc2 = ffn.fc2.to_merged_linear()

        if hasattr(ffn, "w1"):
            if isinstance(ffn.w1, PartialRowLinear):
                ffn.w1 = ffn.w1.to_merged_linear()

            if isinstance(ffn.w2, PartialRowLinear):
                ffn.w2 = ffn.w2.to_merged_linear()

            if isinstance(ffn.w3, SpatialPartialColumnLinear):
                ffn.w3.sync_weight()
            elif isinstance(ffn.w3, PartialColumnLinear):
                ffn.w3 = ffn.w3.to_merged_linear()


def freeze_backbone_train_head(
    model,
):
    for parameter in model.parameters():
        parameter.requires_grad = False

    for parameter in model.head.parameters():
        parameter.requires_grad = True


def freeze_except_paths_and_head(
    model,
    selected_block_indices,
    update_selected_bias=False,
    update_norm2=False,
):
    for parameter in model.parameters():
        parameter.requires_grad = False

    for module in model.backbone.modules():
        if isinstance(module, PartialRowLinear):
            module.selected_rows.requires_grad = True

            if (
                update_selected_bias
                and module.selected_bias is not None
            ):
                module.selected_bias.requires_grad = True

        elif isinstance(module, PartialColumnLinear):
            module.selected_columns.requires_grad = True

            if isinstance(module, SpatialPartialColumnLinear):
                for parameter in module.spatial_conv.parameters():
                    parameter.requires_grad = True

    if update_norm2:
        for block_index in sorted(
            int(index)
            for index in selected_block_indices
        ):
            block = model.backbone.blocks[block_index]

            if not hasattr(block, "norm2"):
                raise AttributeError(
                    "Block {} has no norm2 module".format(block_index)
                )

            norm2_parameters = list(block.norm2.parameters())
            if not norm2_parameters:
                raise RuntimeError(
                    "Block {} norm2 has no trainable parameters".format(
                        block_index
                    )
                )

            for parameter in norm2_parameters:
                parameter.requires_grad = True

    for parameter in model.head.parameters():
        parameter.requires_grad = True


def get_trainable_backbone_parameter_summary(
    model,
):
    summary = {
        "selected_ffn_rows": 0,
        "selected_ffn_columns": 0,
        "selected_ffn_bias": 0,
        "spatial_conv": 0,
        "spatial_gamma": 0,
        "norm2": 0,
        "other": 0,
        "total": 0,
    }

    for name, parameter in model.backbone.named_parameters():
        if not parameter.requires_grad:
            continue

        parameter_count = int(parameter.numel())
        summary["total"] += parameter_count

        if name.endswith("selected_rows"):
            summary["selected_ffn_rows"] += parameter_count
        elif name.endswith("selected_columns"):
            summary["selected_ffn_columns"] += parameter_count
        elif name.endswith("selected_bias"):
            summary["selected_ffn_bias"] += parameter_count
        elif ".spatial_conv." in name:
            if name.endswith("mona.gamma"):
                summary["spatial_gamma"] += parameter_count
            else:
                summary["spatial_conv"] += parameter_count
        elif ".norm2." in name:
            summary["norm2"] += parameter_count
        else:
            summary["other"] += parameter_count

    return summary


def get_final_parameter_groups(
    model,
    path_lr,
    head_lr=None,
    weight_decay=0.0,
):
    if head_lr is None:
        head_lr = path_lr

    row_parameters = []
    column_parameters = []
    selected_bias_parameters = []
    spatial_conv_parameters = []
    spatial_gamma_parameters = []
    norm2_parameters = []

    for module in model.backbone.modules():
        if isinstance(module, PartialRowLinear):
            if module.selected_rows.requires_grad:
                row_parameters.append(module.selected_rows)

            if (
                module.selected_bias is not None
                and module.selected_bias.requires_grad
            ):
                selected_bias_parameters.append(module.selected_bias)

        elif isinstance(module, PartialColumnLinear):
            if module.selected_columns.requires_grad:
                column_parameters.append(module.selected_columns)

            if isinstance(module, SpatialPartialColumnLinear):
                for parameter_name, parameter in (
                    module.spatial_conv.named_parameters()
                ):
                    if not parameter.requires_grad:
                        continue
                    if parameter_name.endswith("mona.gamma"):
                        spatial_gamma_parameters.append(parameter)
                    else:
                        spatial_conv_parameters.append(parameter)

    for block_index in sorted(model.selected_indices):
        block = model.backbone.blocks[block_index]
        if hasattr(block, "norm2"):
            norm2_parameters.extend(
                parameter
                for parameter in block.norm2.parameters()
                if parameter.requires_grad
            )

    if not row_parameters or not column_parameters:
        raise RuntimeError("No selected FFN path parameters were found")

    parameter_groups = [
        {
            "params": row_parameters,
            "lr": path_lr,
            "weight_decay": weight_decay,
            "name": "selected_ffn_rows",
        },
        {
            "params": column_parameters,
            "lr": path_lr,
            "weight_decay": weight_decay,
            "name": "selected_ffn_columns",
        },
    ]

    if selected_bias_parameters:
        parameter_groups.append(
            {
                "params": selected_bias_parameters,
                "lr": path_lr,
                "weight_decay": 0.0,
                "name": "selected_ffn_bias",
            }
        )

    if spatial_conv_parameters:
        parameter_groups.append(
            {
                "params": spatial_conv_parameters,
                "lr": path_lr,
                "weight_decay": weight_decay,
                "name": "selected_spatial_conv",
            }
        )

    if spatial_gamma_parameters:
        parameter_groups.append(
            {
                "params": spatial_gamma_parameters,
                "lr": path_lr,
                "weight_decay": 0.0,
                "name": "selected_spatial_gamma",
            }
        )

    if norm2_parameters:
        parameter_groups.append(
            {
                "params": norm2_parameters,
                "lr": path_lr,
                "weight_decay": 0.0,
                "name": "norm2",
            }
        )

    parameter_groups.append(
        {
            "params": list(model.head.parameters()),
            "lr": head_lr,
            "weight_decay": weight_decay,
            "name": "dpt_head",
        }
    )

    return parameter_groups


# ============================================================
# Complete DINOv3 + DPT model
# ============================================================

class DINO_GradActPaired_DPT(nn.Module):
    def __init__(
        self,
        nclass=1,
        encoder_size="small",
        features=128,
        out_channels=(96, 192, 384, 768),
        use_bn=False,
        dino_repo=r"models",
        hub_model="dinov3_vits16plus",
        weights_path=None,
        target_blocks="all",
    ):
        super().__init__()

        self.intermediate_layer_idx = {
            "small": [2, 5, 8, 11],
            "base": [2, 5, 8, 11],
            "large": [4, 11, 17, 23],
            "giant": [9, 19, 29, 39],
        }

        if encoder_size not in self.intermediate_layer_idx:
            raise ValueError(
                "Unknown encoder_size={}".format(
                    encoder_size
                )
            )

        self.encoder_size = encoder_size

        load_kwargs = {
            "source": "local",
        }

        if weights_path is not None:
            load_kwargs["weights"] = weights_path

        self.backbone = torch.hub.load(
            dino_repo,
            hub_model,
            **load_kwargs,
        )

        self.head = DPTHead(
            nclass=nclass,
            in_channels=self.backbone.embed_dim,
            features=features,
            use_bn=use_bn,
            out_channels=out_channels,
        )

        self.target_block_indices = normalize_target_blocks(
            depth=len(
                self.backbone.blocks
            ),
            target_blocks=target_blocks,
        )

        self.importance_scores = {}
        self.selected_indices = {}
        self.ffn_type_by_block = {}
        self.importance_balance_report = {}
        self.update_selected_bias = False
        self.update_norm2 = False
        self.use_spatial = False
        self.spatial_dim = 0
        self.spatial_kernels = (3, 5, 7)
        self.spatial_gamma_init = -5.0
        self.paths_injected = False

        freeze_backbone_train_head(
            self
        )

    def forward(
        self,
        x,
    ):
        patch_size = int(
            self.backbone.patch_size
        )
        patch_h = (
            x.shape[-2]
            // patch_size
        )
        patch_w = (
            x.shape[-1]
            // patch_size
        )

        set_spatial_patch_grid(
            self.backbone,
            patch_h,
            patch_w,
        )

        features = self.backbone.get_intermediate_layers(
            x,
            n=self.intermediate_layer_idx[
                self.encoder_size
            ],
        )

        output = self.head(
            features,
            patch_h,
            patch_w,
        )
        output = F.interpolate(
            output,
            (
                patch_h * patch_size,
                patch_w * patch_size,
            ),
            mode="bilinear",
            align_corners=True,
        )

        return output

    def select_and_inject(
        self,
        data_loader,
        criterion,
        device,
        num_calibration_batches=20,
        rank_per_block=64,
        total_budget=None,
        min_rank_per_block=16,
        max_rank_per_block=128,
        normalize_mode="mean",
        token_mode="patch",
        use_amp=False,
        importance_balance="foreground_background",
        update_selected_bias=False,
        update_norm2=False,
        use_spatial=False,
        spatial_dim=0,
        spatial_kernels=(3, 5, 7),
        spatial_gamma_init=-5.0,
    ):
        if self.paths_injected:
            raise RuntimeError(
                "Selected paths have already been injected"
            )
        if (
            rank_per_block is None
            and total_budget is None
        ):
            raise ValueError(
                "Provide rank_per_block or total_budget"
            )
        if (
            rank_per_block is not None
            and total_budget is not None
        ):
            raise ValueError(
                "Use either rank_per_block or total_budget"
            )

        (
            self.importance_scores,
            detected_ffn_types,
            self.importance_balance_report,
        ) = collect_gradient_activation_importance(
            model=self,
            data_loader=data_loader,
            criterion=criterion,
            device=device,
            block_indices=self.target_block_indices,
            num_batches=num_calibration_batches,
            token_mode=token_mode,
            use_amp=use_amp,
            balance_mode=importance_balance,
        )

        if total_budget is not None:
            self.selected_indices = select_with_global_budget(
                importance_scores=self.importance_scores,
                total_budget=total_budget,
                min_rank_per_block=min_rank_per_block,
                max_rank_per_block=max_rank_per_block,
                normalize_mode=normalize_mode,
            )
        else:
            self.selected_indices = select_topk_per_block(
                importance_scores=self.importance_scores,
                rank_per_block=int(
                    rank_per_block
                ),
            )

        self.update_selected_bias = bool(
            update_selected_bias
        )
        self.update_norm2 = bool(
            update_norm2
        )
        self.use_spatial = bool(use_spatial)
        self.spatial_dim = int(spatial_dim)
        self.spatial_kernels = tuple(
            int(kernel)
            for kernel in spatial_kernels
        )
        self.spatial_gamma_init = float(
            spatial_gamma_init
        )

        self.ffn_type_by_block = inject_paired_paths_into_dinov3(
            backbone=self.backbone,
            selected_indices=self.selected_indices,
            update_selected_bias=self.update_selected_bias,
            use_spatial=self.use_spatial,
            spatial_dim=self.spatial_dim,
            spatial_kernels=self.spatial_kernels,
            spatial_gamma_init=self.spatial_gamma_init,
        )

        if self.ffn_type_by_block != detected_ffn_types:
            raise RuntimeError(
                "Detected FFN types changed during injection"
            )

        freeze_except_paths_and_head(
            model=self,
            selected_block_indices=self.selected_indices.keys(),
            update_selected_bias=self.update_selected_bias,
            update_norm2=self.update_norm2,
        )
        self.paths_injected = True

        return {
            "rank_by_block": {
                block_index: int(
                    indices.numel()
                )
                for block_index, indices
                in self.selected_indices.items()
            },
            "mean_score_by_block": {
                block_index: float(
                    score.mean()
                )
                for block_index, score
                in self.importance_scores.items()
            },
            "ffn_type_by_block": dict(
                self.ffn_type_by_block
            ),
            "importance_balance_report": dict(
                self.importance_balance_report
            ),
            "update_selected_bias": self.update_selected_bias,
            "update_norm2": self.update_norm2,
            "use_spatial": self.use_spatial,
            "spatial_dim": self.spatial_dim,
            "spatial_kernels": list(self.spatial_kernels),
            "spatial_gamma_init": self.spatial_gamma_init,
            "trainable_backbone_summary": (
                get_trainable_backbone_parameter_summary(
                    self
                )
            ),
            "selected_indices": {
                block_index: indices.clone()
                for block_index, indices
                in self.selected_indices.items()
            },
        }

    def inject_from_indices(
        self,
        selected_indices,
        update_selected_bias=False,
        update_norm2=False,
        use_spatial=False,
        spatial_dim=0,
        spatial_kernels=(3, 5, 7),
        spatial_gamma_init=-5.0,
    ):
        if self.paths_injected:
            raise RuntimeError(
                "Selected paths have already been injected"
            )

        self.selected_indices = {
            int(block_index): torch.as_tensor(
                indices,
                dtype=torch.long,
            ).cpu()
            for block_index, indices
            in selected_indices.items()
        }

        self.update_selected_bias = bool(
            update_selected_bias
        )
        self.update_norm2 = bool(
            update_norm2
        )
        self.use_spatial = bool(use_spatial)
        self.spatial_dim = int(spatial_dim)
        self.spatial_kernels = tuple(
            int(kernel)
            for kernel in spatial_kernels
        )
        self.spatial_gamma_init = float(
            spatial_gamma_init
        )

        self.ffn_type_by_block = inject_paired_paths_into_dinov3(
            backbone=self.backbone,
            selected_indices=self.selected_indices,
            update_selected_bias=self.update_selected_bias,
            use_spatial=self.use_spatial,
            spatial_dim=self.spatial_dim,
            spatial_kernels=self.spatial_kernels,
            spatial_gamma_init=self.spatial_gamma_init,
        )

        freeze_except_paths_and_head(
            model=self,
            selected_block_indices=self.selected_indices.keys(),
            update_selected_bias=self.update_selected_bias,
            update_norm2=self.update_norm2,
        )
        self.paths_injected = True

    @torch.no_grad()
    def sync_selected_weights(
        self,
    ):
        sync_all_selected_weights(
            self.backbone
        )

    @torch.no_grad()
    def merge_for_inference(
        self,
    ):
        self.sync_selected_weights()
        merge_all_selected_paths(
            self.backbone
        )
        self.paths_injected = False

    def print_ffn_structure(
        self,
    ):
        information = {}

        for block_index in self.target_block_indices:
            ffn = self.backbone.blocks[
                block_index
            ].mlp
            ffn_type = identify_ffn_type(
                ffn
            )
            output_projection = get_ffn_output_projection(
                ffn
            )

            information[block_index] = {
                "type": ffn_type,
                "hidden_dim": int(
                    output_projection.in_features
                ),
            }

        print(information)
        return information