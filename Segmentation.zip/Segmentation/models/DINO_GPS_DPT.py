from __future__ import annotations

import math
from typing import Dict, Iterable, Optional, Sequence, Union

import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================
# DPT decoder
# ============================================================

def _make_scratch(
    in_shape,
    out_shape,
    groups=1,
    expand=False,
):
    scratch = nn.Module()

    out_shape1 = out_shape
    out_shape2 = out_shape
    out_shape3 = out_shape

    if len(in_shape) >= 4:
        out_shape4 = out_shape

    if expand:
        out_shape1 = out_shape
        out_shape2 = out_shape * 2
        out_shape3 = out_shape * 4

        if len(in_shape) >= 4:
            out_shape4 = out_shape * 8

    scratch.layer1_rn = nn.Conv2d(
        in_shape[0],
        out_shape1,
        kernel_size=3,
        stride=1,
        padding=1,
        bias=False,
        groups=groups,
    )
    scratch.layer2_rn = nn.Conv2d(
        in_shape[1],
        out_shape2,
        kernel_size=3,
        stride=1,
        padding=1,
        bias=False,
        groups=groups,
    )
    scratch.layer3_rn = nn.Conv2d(
        in_shape[2],
        out_shape3,
        kernel_size=3,
        stride=1,
        padding=1,
        bias=False,
        groups=groups,
    )

    if len(in_shape) >= 4:
        scratch.layer4_rn = nn.Conv2d(
            in_shape[3],
            out_shape4,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=False,
            groups=groups,
        )

    return scratch


class ResidualConvUnit(nn.Module):
    def __init__(
        self,
        features,
        activation,
        bn,
    ):
        super().__init__()

        self.bn = bool(bn)
        self.activation = activation
        self.skip_add = nn.quantized.FloatFunctional()

        self.conv1 = nn.Conv2d(
            features,
            features,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=True,
        )
        self.conv2 = nn.Conv2d(
            features,
            features,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=True,
        )

        if self.bn:
            self.bn1 = nn.BatchNorm2d(features)
            self.bn2 = nn.BatchNorm2d(features)

    def forward(self, x):
        out = self.activation(x)
        out = self.conv1(out)

        if self.bn:
            out = self.bn1(out)

        out = self.activation(out)
        out = self.conv2(out)

        if self.bn:
            out = self.bn2(out)

        return self.skip_add.add(out, x)


class FeatureFusionBlock(nn.Module):
    def __init__(
        self,
        features,
        activation,
        bn=False,
        expand=False,
        align_corners=True,
        size=None,
    ):
        super().__init__()

        self.align_corners = align_corners
        self.size = size

        out_features = features // 2 if expand else features

        self.out_conv = nn.Conv2d(
            features,
            out_features,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=True,
        )
        self.resConfUnit1 = ResidualConvUnit(
            features,
            activation,
            bn,
        )
        self.resConfUnit2 = ResidualConvUnit(
            features,
            activation,
            bn,
        )
        self.skip_add = nn.quantized.FloatFunctional()

    def forward(self, *xs, size=None):
        output = xs[0]

        if len(xs) == 2:
            residual = self.resConfUnit1(xs[1])
            output = self.skip_add.add(
                output,
                residual,
            )

        output = self.resConfUnit2(output)

        if size is None and self.size is None:
            modifier = {"scale_factor": 2}
        elif size is None:
            modifier = {"size": self.size}
        else:
            modifier = {"size": size}

        output = F.interpolate(
            output,
            **modifier,
            mode="bilinear",
            align_corners=self.align_corners,
        )

        return self.out_conv(output)


def _make_fusion_block(
    features,
    use_bn,
    size=None,
):
    return FeatureFusionBlock(
        features,
        nn.ReLU(False),
        bn=use_bn,
        expand=False,
        align_corners=True,
        size=size,
    )


class DPTHead(nn.Module):
    def __init__(
        self,
        nclass,
        in_channels,
        features=128,
        use_bn=False,
        out_channels=(96, 192, 384, 768),
    ):
        super().__init__()

        self.projects = nn.ModuleList(
            [
                nn.Conv2d(
                    in_channels=in_channels,
                    out_channels=out_channel,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
                for out_channel in out_channels
            ]
        )

        self.resize_layers = nn.ModuleList(
            [
                nn.ConvTranspose2d(
                    in_channels=out_channels[0],
                    out_channels=out_channels[0],
                    kernel_size=4,
                    stride=4,
                    padding=0,
                ),
                nn.ConvTranspose2d(
                    in_channels=out_channels[1],
                    out_channels=out_channels[1],
                    kernel_size=2,
                    stride=2,
                    padding=0,
                ),
                nn.Identity(),
                nn.Conv2d(
                    in_channels=out_channels[3],
                    out_channels=out_channels[3],
                    kernel_size=3,
                    stride=2,
                    padding=1,
                ),
            ]
        )

        self.scratch = _make_scratch(
            out_channels,
            features,
            groups=1,
            expand=False,
        )

        self.scratch.refinenet1 = _make_fusion_block(
            features,
            use_bn,
        )
        self.scratch.refinenet2 = _make_fusion_block(
            features,
            use_bn,
        )
        self.scratch.refinenet3 = _make_fusion_block(
            features,
            use_bn,
        )
        self.scratch.refinenet4 = _make_fusion_block(
            features,
            use_bn,
        )

        self.scratch.output_conv = nn.Sequential(
            nn.Conv2d(
                features,
                features,
                kernel_size=3,
                stride=1,
                padding=1,
            ),
            nn.ReLU(True),
            nn.Conv2d(
                features,
                nclass,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
        )

    def forward(
        self,
        out_features,
        patch_h,
        patch_w,
    ):
        outputs = []

        for index, feature in enumerate(out_features):
            feature = feature.permute(
                0,
                2,
                1,
            ).reshape(
                feature.shape[0],
                feature.shape[-1],
                patch_h,
                patch_w,
            )

            feature = self.projects[index](feature)
            feature = self.resize_layers[index](feature)
            outputs.append(feature)

        layer_1, layer_2, layer_3, layer_4 = outputs

        layer_1_rn = self.scratch.layer1_rn(layer_1)
        layer_2_rn = self.scratch.layer2_rn(layer_2)
        layer_3_rn = self.scratch.layer3_rn(layer_3)
        layer_4_rn = self.scratch.layer4_rn(layer_4)

        path_4 = self.scratch.refinenet4(
            layer_4_rn,
            size=layer_3_rn.shape[2:],
        )
        path_3 = self.scratch.refinenet3(
            path_4,
            layer_3_rn,
            size=layer_2_rn.shape[2:],
        )
        path_2 = self.scratch.refinenet2(
            path_3,
            layer_2_rn,
            size=layer_1_rn.shape[2:],
        )
        path_1 = self.scratch.refinenet1(
            path_2,
            layer_1_rn,
        )

        return self.scratch.output_conv(path_1)

# ============================================================
# GPS: Gradient-based Parameter Selection
# ============================================================

def _extract_images_masks(batch):
    """Accept either (image, mask) or a dictionary batch."""
    if isinstance(batch, (tuple, list)) and len(batch) >= 2:
        return batch[0], batch[1]

    if isinstance(batch, dict):
        image = None
        mask = None

        for key in ("image", "images", "input", "inputs", "x"):
            if key in batch:
                image = batch[key]
                break

        for key in (
            "mask", "masks", "label", "labels",
            "target", "targets", "y",
        ):
            if key in batch:
                mask = batch[key]
                break

        if image is not None and mask is not None:
            return image, mask

    raise TypeError(
        "Each calibration batch must provide images and masks."
    )


def freeze_backbone_train_head(model):
    """Initial state: frozen DINOv3 backbone + trainable DPT head."""
    for parameter in model.parameters():
        parameter.requires_grad = False

    for parameter in model.head.parameters():
        parameter.requires_grad = True


def _module_matches_gps_scope(module_name, gps_scope):
    """Match Linear/Conv candidate modules for GPS."""
    scope = str(gps_scope).lower()

    if scope == "all":
        return True

    name = module_name.lower()

    if scope == "ffn":
        return (
            ".mlp" in name
            or name.endswith("mlp")
            or ".ffn" in name
            or name.endswith("ffn")
        )

    if scope == "attn":
        return (
            ".attn" in name
            or name.endswith("attn")
            or ".attention" in name
            or name.endswith("attention")
        )

    raise ValueError(
        "gps_scope must be one of {'all', 'ffn', 'attn'}, "
        "got {!r}".format(gps_scope)
    )


def _norm_matches_gps_scope(module_name, gps_scope):
    """
    Match normalization modules.

    For the normal GPS setting (scope='all'), every backbone normalization
    parameter is eligible.  For controlled ffn/attn ablations, the common ViT
    convention norm1 -> attention and norm2 -> FFN is used when possible.
    """
    scope = str(gps_scope).lower()
    if scope == "all":
        return True

    name = module_name.lower()

    if scope == "attn":
        return (
            name.endswith("norm1")
            or ".norm1" in name
            or ".attn" in name
            or ".attention" in name
        )

    if scope == "ffn":
        return (
            name.endswith("norm2")
            or ".norm2" in name
            or ".mlp" in name
            or ".ffn" in name
        )

    return False


def _get_norm_types():
    norm_types = [
        nn.LayerNorm,
        nn.BatchNorm1d,
        nn.BatchNorm2d,
        nn.BatchNorm3d,
        nn.GroupNorm,
        nn.InstanceNorm1d,
        nn.InstanceNorm2d,
        nn.InstanceNorm3d,
    ]
    if hasattr(nn, "RMSNorm"):
        norm_types.append(nn.RMSNorm)
    return tuple(norm_types)


_NORM_TYPES = _get_norm_types()


def get_gps_candidate_parameters(
    backbone,
    gps_scope="all",
    select_bias=False,
    select_norm=False,
):
    """
    Return GPS candidate tensors and their semantic kinds.

    Matrix/conv weights:
        - Linear.weight: [out_features, in_features]
        - Conv2d.weight: [out_channels, in_channels, kh, kw]
        Selection is Top-K input connections PER output neuron/channel.

    Optional 1-D parameters:
        - Linear/Conv2d bias
        - normalization affine weight/bias
        Selection is Top-K scalar entries PER tensor.

    cls_token / positional embeddings / LayerScale gamma are intentionally not
    added here.  They remain frozen unless explicitly added in a future ablation.
    """
    candidates = {}
    kinds = {}
    seen_parameter_ids = set()

    def add_candidate(name, parameter, kind):
        if parameter is None or not isinstance(parameter, nn.Parameter):
            return
        parameter_id = id(parameter)
        if parameter_id in seen_parameter_ids:
            return
        seen_parameter_ids.add(parameter_id)
        candidates[name] = parameter
        kinds[name] = kind

    for module_name, module in backbone.named_modules():
        # Original GPS connection candidates.
        if isinstance(module, (nn.Linear, nn.Conv2d)) and _module_matches_gps_scope(
            module_name,
            gps_scope,
        ):
            weight = getattr(module, "weight", None)
            if isinstance(weight, nn.Parameter) and weight.ndim >= 2:
                name = "{}.weight".format(module_name) if module_name else "weight"
                add_candidate(name, weight, "matrix_weight")

            if bool(select_bias):
                bias = getattr(module, "bias", None)
                if isinstance(bias, nn.Parameter):
                    name = "{}.bias".format(module_name) if module_name else "bias"
                    add_candidate(name, bias, "bias")

        # User-requested sparse normalization selection.
        if bool(select_norm) and isinstance(module, _NORM_TYPES):
            if not _norm_matches_gps_scope(module_name, gps_scope):
                continue

            for local_name, parameter in module.named_parameters(recurse=False):
                if parameter is None:
                    continue
                full_name = (
                    "{}.{}".format(module_name, local_name)
                    if module_name
                    else local_name
                )
                kind = "norm_bias" if local_name == "bias" else "norm_weight"
                add_candidate(full_name, parameter, kind)

    if not candidates:
        raise RuntimeError(
            "No GPS candidate parameters were found for "
            "gps_scope={!r}, select_bias={}, select_norm={}.".format(
                gps_scope,
                bool(select_bias),
                bool(select_norm),
            )
        )

    return candidates, kinds


def collect_gps_gradient_importance(
    model,
    data_loader,
    criterion,
    device,
    num_batches=20,
    gps_scope="all",
    use_amp=False,
    select_bias=False,
    select_norm=False,
):
    """
    Collect GPS task-gradient importance.

    GPS-faithful accumulation rule:
        1) zero gradients ONCE before the calibration loader;
        2) accumulate signed gradients across calibration batches;
        3) score = abs(accumulated_gradient) / num_processed_batches.

    Dividing by the number of batches only rescales a tensor and therefore does
    not change its Top-K selection.  It makes reported scores easier to compare
    across different calibration lengths.

    The DPT head participates in the forward pass but is frozen while GPS
    gradients are collected.  Calibration uses only the supplied data loader.
    """
    if num_batches <= 0:
        raise ValueError("num_batches must be positive")

    device = torch.device(device)
    previous_training_state = model.training

    previous_requires_grad = {
        id(parameter): bool(parameter.requires_grad)
        for parameter in model.parameters()
    }

    candidates, candidate_kinds = get_gps_candidate_parameters(
        model.backbone,
        gps_scope=gps_scope,
        select_bias=select_bias,
        select_norm=select_norm,
    )

    # Selection stage: only backbone GPS candidates require gradients.
    for parameter in model.parameters():
        parameter.requires_grad = False

    for parameter in candidates.values():
        parameter.requires_grad = True

    # Official GPS selection code performs gradient collection in train mode.
    model.train()
    model.zero_grad(set_to_none=True)

    amp_enabled = bool(use_amp and device.type == "cuda")
    processed_batches = 0
    mean_loss = 0.0

    try:
        for batch_index, batch in enumerate(data_loader):
            if batch_index >= num_batches:
                break

            images, masks = _extract_images_masks(batch)

            images = images.to(
                device=device,
                dtype=torch.float32,
                non_blocking=True,
            )
            masks = masks.to(
                device=device,
                dtype=torch.float32,
                non_blocking=True,
            )

            # IMPORTANT: do NOT zero gradients here. GPS accumulates signed
            # gradients over the calibration set before taking abs().
            with torch.cuda.amp.autocast(enabled=amp_enabled):
                logits = model(images)
                loss = criterion(logits, masks)

            loss.backward()

            processed_batches += 1
            mean_loss += float(loss.detach().float().cpu())

        if processed_batches == 0:
            raise RuntimeError("No calibration batch was processed.")

        importance = {}
        unused = []

        for name, parameter in candidates.items():
            if parameter.grad is None:
                unused.append(name)
                continue

            importance[name] = (
                parameter.grad.detach()
                .float()
                .abs()
                .div(float(processed_batches))
                .cpu()
            )

    finally:
        model.zero_grad(set_to_none=True)

        for parameter in model.parameters():
            parameter.requires_grad = previous_requires_grad[id(parameter)]

        model.train(previous_training_state)

    if not importance:
        raise RuntimeError(
            "None of the GPS candidate parameters received gradients."
        )

    report = {
        "processed_batches": int(processed_batches),
        "mean_calibration_loss": float(mean_loss / processed_batches),
        "candidate_tensor_count": int(len(importance)),
        "candidate_parameter_count": int(
            sum(score.numel() for score in importance.values())
        ),
        "unused_candidate_tensors": unused,
        "score_definition": "abs(sum_batch_grad) / processed_batches",
        "candidate_kind_count": {
            kind: int(
                sum(
                    1
                    for name in importance
                    if candidate_kinds.get(name) == kind
                )
            )
            for kind in sorted(set(candidate_kinds.values()))
        },
    }

    used_kinds = {
        name: candidate_kinds[name]
        for name in importance
    }

    return importance, used_kinds, report


def select_gps_topk(
    importance,
    candidate_kinds,
    topk_connections=1,
    bias_k=None,
    norm_k=None,
):
    """
    Build sparse GPS masks.

    matrix_weight:
        Top-K input connections per output neuron/channel.

    bias / norm_weight / norm_bias:
        Top-K scalar entries inside each 1-D tensor.
    """
    topk_connections = int(topk_connections)
    if topk_connections <= 0:
        raise ValueError("topk_connections must be positive")

    if bias_k is None:
        bias_k = topk_connections
    if norm_k is None:
        norm_k = topk_connections

    bias_k = int(bias_k)
    norm_k = int(norm_k)

    if bias_k <= 0:
        raise ValueError("bias_k must be positive")
    if norm_k <= 0:
        raise ValueError("norm_k must be positive")

    masks = {}
    selected_flat_indices = {}
    layer_report = {}

    for name, score in importance.items():
        kind = candidate_kinds[name]
        original_shape = tuple(score.shape)

        if kind == "matrix_weight":
            if score.ndim < 2:
                raise ValueError(
                    "matrix_weight {!r} must have ndim >= 2, got {}".format(
                        name,
                        score.ndim,
                    )
                )

            flat_score = score.reshape(score.shape[0], -1)
            in_connections = int(flat_score.shape[1])
            k = min(topk_connections, in_connections)

            topk_idx = torch.topk(
                flat_score,
                k=k,
                dim=1,
                largest=True,
                sorted=False,
            ).indices

            flat_mask = torch.zeros_like(flat_score, dtype=torch.bool)
            flat_mask.scatter_(1, topk_idx, True)
            mask = flat_mask.reshape(original_shape)

            selection_rule = "topk_per_output_neuron"
            report_extra = {
                "output_neurons": int(flat_score.shape[0]),
                "input_connections_per_neuron": int(in_connections),
                "selected_connections_per_neuron": int(k),
            }

        else:
            flat_score = score.reshape(-1)
            requested_k = bias_k if kind == "bias" else norm_k
            k = min(int(requested_k), int(flat_score.numel()))

            topk_idx = torch.topk(
                flat_score,
                k=k,
                largest=True,
                sorted=False,
            ).indices

            flat_mask = torch.zeros_like(flat_score, dtype=torch.bool)
            flat_mask[topk_idx] = True
            mask = flat_mask.reshape(original_shape)

            selection_rule = "topk_scalars_per_tensor"
            report_extra = {
                "tensor_elements": int(flat_score.numel()),
                "selected_scalars": int(k),
            }

        selected = torch.nonzero(
            mask.reshape(-1),
            as_tuple=False,
        ).flatten().cpu()

        masks[name] = mask
        selected_flat_indices[name] = selected

        layer_report[name] = {
            "kind": kind,
            "selection_rule": selection_rule,
            "shape": list(original_shape),
            "selected_parameters": int(mask.sum().item()),
            "candidate_parameters": int(mask.numel()),
            "selected_ratio_percent": float(
                100.0 * mask.sum().item() / max(mask.numel(), 1)
            ),
            "mean_gradient_score": float(score.mean().item()),
            "max_gradient_score": float(score.max().item()),
            **report_extra,
        }

    if not masks:
        raise RuntimeError("GPS did not produce any masks.")

    return masks, selected_flat_indices, layer_report


def _build_masks_from_flat_indices(
    backbone,
    selected_flat_indices,
    gps_scope="all",
    select_bias=False,
    select_norm=False,
):
    candidates, candidate_kinds = get_gps_candidate_parameters(
        backbone,
        gps_scope=gps_scope,
        select_bias=select_bias,
        select_norm=select_norm,
    )

    masks = {}

    for name, flat_indices in selected_flat_indices.items():
        if name not in candidates:
            raise KeyError(
                "GPS parameter {!r} does not exist in the current backbone."
                .format(name)
            )

        parameter = candidates[name]
        mask_flat = torch.zeros(
            parameter.numel(),
            dtype=torch.bool,
            device="cpu",
        )

        indices = torch.as_tensor(
            flat_indices,
            dtype=torch.long,
            device="cpu",
        ).flatten()

        if indices.numel() > 0:
            if (
                indices.min().item() < 0
                or indices.max().item() >= parameter.numel()
            ):
                raise ValueError(
                    "Saved GPS indices for {!r} are out of range."
                    .format(name)
                )
            mask_flat[indices] = True

        masks[name] = mask_flat.reshape(tuple(parameter.shape))

    used_kinds = {
        name: candidate_kinds[name]
        for name in masks
    }
    return masks, used_kinds


def enable_gps_masked_finetuning(
    model,
    masks,
    gps_scope="all",
    select_bias=False,
    select_norm=False,
    candidate_kinds=None,
):
    """
    Keep original DINOv3 modules intact and mask gradients in-place.

    Backbone weight decay MUST remain zero, otherwise optimizer decay can alter
    unselected entries even when their gradients are masked to zero.
    """
    for handle in getattr(model, "_gps_hook_handles", []):
        handle.remove()
    model._gps_hook_handles = []

    for parameter in model.parameters():
        parameter.requires_grad = False

    candidates, discovered_kinds = get_gps_candidate_parameters(
        model.backbone,
        gps_scope=gps_scope,
        select_bias=select_bias,
        select_norm=select_norm,
    )

    if candidate_kinds is None:
        candidate_kinds = discovered_kinds

    gpu_masks = {}

    for name, mask_cpu in masks.items():
        if name not in candidates:
            raise KeyError(
                "GPS mask parameter {!r} was not found.".format(name)
            )

        parameter = candidates[name]

        if tuple(mask_cpu.shape) != tuple(parameter.shape):
            raise ValueError(
                "Mask shape {} does not match {} shape {}.".format(
                    tuple(mask_cpu.shape),
                    name,
                    tuple(parameter.shape),
                )
            )

        parameter.requires_grad = True

        mask = mask_cpu.to(
            device=parameter.device,
            dtype=torch.bool,
        )
        gpu_masks[name] = mask

        def _mask_gradient(grad, local_mask=mask):
            return grad.masked_fill(~local_mask, 0)

        model._gps_hook_handles.append(
            parameter.register_hook(_mask_gradient)
        )

    for parameter in model.head.parameters():
        parameter.requires_grad = True

    model.gps_masks = gpu_masks
    model.gps_candidate_kinds = {
        name: candidate_kinds[name]
        for name in gpu_masks
    }
    model.gps_enabled = True


def get_gps_parameter_groups(
    model,
    gps_lr,
    head_lr=None,
    head_weight_decay=0.0,
):
    """Optimizer groups for sparse GPS backbone parameters + DPT head."""
    if not getattr(model, "gps_enabled", False):
        raise RuntimeError("GPS masks have not been enabled.")

    if head_lr is None:
        head_lr = gps_lr

    candidates, _ = get_gps_candidate_parameters(
        model.backbone,
        gps_scope=model.gps_scope,
        select_bias=model.gps_select_bias,
        select_norm=model.gps_select_norm,
    )

    backbone_parameters = [
        candidates[name]
        for name in model.gps_masks
    ]

    if not backbone_parameters:
        raise RuntimeError("No GPS backbone tensors are trainable.")

    return [
        {
            "params": backbone_parameters,
            "lr": gps_lr,
            "weight_decay": 0.0,
            "name": "gps_selected_backbone_parameters",
        },
        {
            "params": list(model.head.parameters()),
            "lr": head_lr,
            "weight_decay": head_weight_decay,
            "name": "dpt_head",
        },
    ]


def get_gps_effective_parameter_summary(model):
    """Count effective selected scalars rather than optimizer-visible tensors."""
    selected_by_kind = {}

    for name, mask in getattr(model, "gps_masks", {}).items():
        kind = getattr(model, "gps_candidate_kinds", {}).get(name, "unknown")
        selected_by_kind[kind] = selected_by_kind.get(kind, 0) + int(
            mask.sum().item()
        )

    selected_backbone = int(sum(selected_by_kind.values()))

    head_parameters = int(
        sum(parameter.numel() for parameter in model.head.parameters())
    )

    backbone_parameters = int(
        sum(parameter.numel() for parameter in model.backbone.parameters())
    )

    total_parameters = int(
        sum(parameter.numel() for parameter in model.parameters())
    )

    effective_trainable = selected_backbone + head_parameters

    return {
        "selected_backbone_parameters": selected_backbone,
        "selected_backbone_by_kind": {
            key: int(value)
            for key, value in sorted(selected_by_kind.items())
        },
        "backbone_parameters": backbone_parameters,
        "selected_backbone_ratio_percent": float(
            100.0 * selected_backbone / max(backbone_parameters, 1)
        ),
        "dpt_head_parameters": head_parameters,
        "effective_trainable_parameters": effective_trainable,
        "total_parameters": total_parameters,
        "effective_trainable_ratio_percent": float(
            100.0 * effective_trainable / max(total_parameters, 1)
        ),
    }


# ============================================================
# Complete DINOv3 + DPT model
# ============================================================

class DINO_GPS_DPT(nn.Module):
    def __init__(
        self,
        nclass=1,
        encoder_size="small",
        features=128,
        out_channels=(96, 192, 384, 768),
        use_bn=False,
        dino_repo=r"models",
        hub_model="dinov3_vits16plus",
        weights_path=None,
    ):
        super().__init__()

        self.intermediate_layer_idx = {
            "small": [2, 5, 8, 11],
            "base": [2, 5, 8, 11],
            "large": [4, 11, 17, 23],
            "giant": [9, 19, 29, 39],
        }

        if encoder_size not in self.intermediate_layer_idx:
            raise ValueError(
                "Unknown encoder_size={}".format(encoder_size)
            )

        self.encoder_size = encoder_size

        load_kwargs = {"source": "local"}
        if weights_path is not None:
            load_kwargs["weights"] = weights_path

        self.backbone = torch.hub.load(
            dino_repo,
            hub_model,
            **load_kwargs,
        )

        self.head = DPTHead(
            nclass=nclass,
            in_channels=self.backbone.embed_dim,
            features=features,
            use_bn=use_bn,
            out_channels=out_channels,
        )

        self.gps_scope = "all"
        self.gps_topk_connections = 1
        self.gps_select_bias = False
        self.gps_select_norm = False
        self.gps_bias_k = 1
        self.gps_norm_k = 1
        self.gps_importance = {}
        self.gps_masks = {}
        self.gps_selected_flat_indices = {}
        self.gps_layer_report = {}
        self.gps_calibration_report = {}
        self.gps_candidate_kinds = {}
        self.gps_enabled = False
        self._gps_hook_handles = []

        freeze_backbone_train_head(self)

    def forward(self, x):
        patch_size = int(self.backbone.patch_size)
        patch_h = x.shape[-2] // patch_size
        patch_w = x.shape[-1] // patch_size

        features = self.backbone.get_intermediate_layers(
            x,
            n=self.intermediate_layer_idx[self.encoder_size],
        )

        output = self.head(features, patch_h, patch_w)
        output = F.interpolate(
            output,
            (patch_h * patch_size, patch_w * patch_size),
            mode="bilinear",
            align_corners=True,
        )
        return output

    def select_and_enable_gps(
        self,
        data_loader,
        criterion,
        device,
        num_calibration_batches=20,
        topk_connections=1,
        gps_scope="all",
        use_amp=False,
        select_bias=False,
        select_norm=False,
        bias_k=None,
        norm_k=None,
    ):
        if self.gps_enabled:
            raise RuntimeError("GPS has already been enabled.")

        self.gps_scope = str(gps_scope).lower()
        self.gps_topk_connections = int(topk_connections)
        self.gps_select_bias = bool(select_bias)
        self.gps_select_norm = bool(select_norm)
        self.gps_bias_k = int(
            self.gps_topk_connections if bias_k is None else bias_k
        )
        self.gps_norm_k = int(
            self.gps_topk_connections if norm_k is None else norm_k
        )

        (
            self.gps_importance,
            self.gps_candidate_kinds,
            self.gps_calibration_report,
        ) = collect_gps_gradient_importance(
            model=self,
            data_loader=data_loader,
            criterion=criterion,
            device=device,
            num_batches=num_calibration_batches,
            gps_scope=self.gps_scope,
            use_amp=use_amp,
            select_bias=self.gps_select_bias,
            select_norm=self.gps_select_norm,
        )

        (
            masks,
            self.gps_selected_flat_indices,
            self.gps_layer_report,
        ) = select_gps_topk(
            importance=self.gps_importance,
            candidate_kinds=self.gps_candidate_kinds,
            topk_connections=self.gps_topk_connections,
            bias_k=self.gps_bias_k,
            norm_k=self.gps_norm_k,
        )

        enable_gps_masked_finetuning(
            model=self,
            masks=masks,
            gps_scope=self.gps_scope,
            select_bias=self.gps_select_bias,
            select_norm=self.gps_select_norm,
            candidate_kinds=self.gps_candidate_kinds,
        )

        summary = get_gps_effective_parameter_summary(self)

        return {
            "gps_scope": self.gps_scope,
            "topk_connections_per_neuron": int(self.gps_topk_connections),
            "select_bias": bool(self.gps_select_bias),
            "select_norm": bool(self.gps_select_norm),
            "bias_k": int(self.gps_bias_k),
            "norm_k": int(self.gps_norm_k),
            "calibration": dict(self.gps_calibration_report),
            "layer_report": dict(self.gps_layer_report),
            "effective_parameter_summary": summary,
            "selected_flat_indices": {
                name: indices.clone()
                for name, indices in self.gps_selected_flat_indices.items()
            },
        }

    def enable_gps_from_indices(
        self,
        selected_flat_indices,
        gps_scope="all",
        topk_connections=1,
        select_bias=False,
        select_norm=False,
        bias_k=None,
        norm_k=None,
    ):
        if self.gps_enabled:
            raise RuntimeError("GPS has already been enabled.")

        self.gps_scope = str(gps_scope).lower()
        self.gps_topk_connections = int(topk_connections)
        self.gps_select_bias = bool(select_bias)
        self.gps_select_norm = bool(select_norm)
        self.gps_bias_k = int(
            self.gps_topk_connections if bias_k is None else bias_k
        )
        self.gps_norm_k = int(
            self.gps_topk_connections if norm_k is None else norm_k
        )

        self.gps_selected_flat_indices = {
            str(name): torch.as_tensor(
                indices,
                dtype=torch.long,
                device="cpu",
            ).flatten()
            for name, indices in selected_flat_indices.items()
        }

        masks, candidate_kinds = _build_masks_from_flat_indices(
            backbone=self.backbone,
            selected_flat_indices=self.gps_selected_flat_indices,
            gps_scope=self.gps_scope,
            select_bias=self.gps_select_bias,
            select_norm=self.gps_select_norm,
        )
        self.gps_candidate_kinds = candidate_kinds

        enable_gps_masked_finetuning(
            model=self,
            masks=masks,
            gps_scope=self.gps_scope,
            select_bias=self.gps_select_bias,
            select_norm=self.gps_select_norm,
            candidate_kinds=self.gps_candidate_kinds,
        )

        return get_gps_effective_parameter_summary(self)

    def remove_gps_hooks(self):
        for handle in self._gps_hook_handles:
            handle.remove()
        self._gps_hook_handles = []
        self.gps_enabled = False
