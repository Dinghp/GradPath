import os
import numpy as np
import cv2
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from torchvision import transforms

from utils1.utils import calculate_metrics
from tqdm import tqdm

torch.backends.cudnn.benchmark = True
torch.backends.cudnn.deterministic = False
import torch.nn.functional as F
import os
import random

def _detect_ext(path, subdir):

    full_dir = os.path.join(path, subdir)
    if "GLaS" in path:
        if subdir == "images":
            return ".bmp"
        elif subdir == "masks":
            return "_anno.bmp"
    if "ISIC2017" in path:
        if subdir == "images":
            return ".jpg"
        elif subdir == "masks":
            return "_segmentation.png"
    if "ISIC2016" in path:
        if subdir == "images":
            return ".jpg"
        elif subdir == "masks":
            return "_segmentation.png"

    for f in sorted(os.listdir(full_dir)):
        f_lower = f.lower()
        if f_lower.endswith(".jpg") or f_lower.endswith(".jpeg"):
            return ".jpg"
        if f_lower.endswith(".png"):
            return ".png"

    raise ValueError(f"❌ No supported image found in {full_dir}")


def load_names(path, file_path):
    # 1. 读取 id
    with open(file_path, "r") as f:
        names = [line.strip() for line in f if line.strip()]

    # 2. 自动探测当前数据集的格式
    img_ext = _detect_ext(path, "images")
    mask_ext = _detect_ext(path, "masks")

    # 3. 构造路径
    images = [
        os.path.join(path, "images", name + img_ext)
        for name in names
    ]
    masks = [
        os.path.join(path, "masks", name + mask_ext)
        for name in names
    ]

    return images, masks


def load_data(path, val_name=None):
    train_names_path = os.path.join(path, "train.txt")
    valid_names_path = os.path.join(path, "val.txt" if val_name is None else f"val_{val_name}.txt")

    train_x, train_y = load_names(path, train_names_path)
    valid_x, valid_y = load_names(path, valid_names_path)

    return (train_x, train_y), (valid_x, valid_y)


def get_mean_and_std(img):
    x_mean, x_std = cv2.meanStdDev(img)
    x_mean = np.hstack(np.around(x_mean, 2))
    x_std = np.hstack(np.around(x_std, 2))

    return x_mean, x_std


class DATASET(Dataset):
    def __init__(self, images_path, masks_path, size, transform=None):
        super().__init__()
        self.images_path = images_path
        self.masks_path = masks_path
        self.n_samples = len(images_path)
        self.size = size
        self.transform = transform

    def __getitem__(self, index):
        """ 读取图像和掩码 """
        image = cv2.imread(self.images_path[index], cv2.IMREAD_COLOR)
        mask = cv2.imread(self.masks_path[index], cv2.IMREAD_GRAYSCALE)

        # if image.shape[:2] == mask.shape[:2]:
        #     print(self.images_path[index])
        #     print(self.masks_path[index])
        #     print("image:", image.shape)
        #     print("mask :", mask.shape)
        if "glas" in self.images_path[0].lower():
            # print(1)

            mask = mask > 0
            mask = mask.astype(np.uint8)  # 转换为无符号8位整数格式

        # image = cv2.resize(image, self.size)
        # mask = cv2.resize(mask, self.size)
        if "btmri" in self.images_path[0].lower():

            image = cv2.resize(image, self.size)
            mask = cv2.resize(mask, self.size)
        if self.transform is not None:
            augmentations = self.transform(image=image, mask=mask)
            image = augmentations["image"]
            mask = augmentations["mask"]

        """ 调整尺寸和归一化 """
        image = cv2.resize(image, self.size)
        image = np.transpose(image, (2, 0, 1))  # HWC → CHW
        image = image / 255.0  # 归一化

        mask = cv2.resize(mask, self.size)
        mask = np.expand_dims(mask, axis=0)  # [H,W] → [1,H,W]
        if "glas" in self.images_path[0].lower():
            # print(1)

            return image, mask
        mask = mask / 255.0

        return image, mask

    def __len__(self):
        return self.n_samples


def train(model, loader, optimizer, loss_fn, device):
    model.train()
    epoch_loss = 0.0
    epoch_jac = 0.0
    epoch_f1 = 0.0
    epoch_recall = 0.0
    epoch_precision = 0.0
    for i, (x, y1) in enumerate(tqdm(loader, desc="Training", total=len(loader))):

        x = x.to(device, dtype=torch.float32)
        y1 = y1.to(device, dtype=torch.float32)

        optimizer.zero_grad()

        Decoder_mask = model(x)
        loss=loss_fn(Decoder_mask, y1)

        loss.backward()

        optimizer.step()
        epoch_loss += loss.item()

        """ Calculate the metrics """
        batch_jac = []
        batch_f1 = []
        batch_recall = []
        batch_precision = []

        for yt, yp in zip(y1, Decoder_mask):
            score = calculate_metrics(yt, yp)
            batch_jac.append(score[0])
            batch_f1.append(score[1])
            batch_recall.append(score[2])
            batch_precision.append(score[3])

        epoch_jac += np.mean(batch_jac)
        epoch_f1 += np.mean(batch_f1)
        epoch_recall += np.mean(batch_recall)
        epoch_precision += np.mean(batch_precision)

    epoch_loss = epoch_loss / len(loader)
    epoch_jac = epoch_jac / len(loader)
    epoch_f1 = epoch_f1 / len(loader)
    epoch_recall = epoch_recall / len(loader)
    epoch_precision = epoch_precision / len(loader)

    return epoch_loss, [epoch_jac, epoch_f1, epoch_recall, epoch_precision]


def evaluate(model, loader, loss_fn, device):
    model.eval()

    epoch_loss = 0.0
    epoch_jac = 0.0
    epoch_f1 = 0.0
    epoch_recall = 0.0
    epoch_precision = 0.0

    with torch.no_grad():
        for i, (x, y1) in enumerate(tqdm(loader, desc="Evaluation", total=len(loader))):
            x = x.to(device, dtype=torch.float32)
            y1 = y1.to(device, dtype=torch.float32)

            Decoder_feature = model(x)
            loss_mask = loss_fn(Decoder_feature, y1)

            loss = loss_mask

            epoch_loss += loss.item()

            """ Calculate the metrics """
            batch_jac = []
            batch_f1 = []
            batch_recall = []
            batch_precision = []
            for yt, yp in zip(y1, Decoder_feature):
                score = calculate_metrics(yt, yp)
                batch_jac.append(score[0])
                batch_f1.append(score[1])
                batch_recall.append(score[2])
                batch_precision.append(score[3])


            epoch_jac += np.mean(batch_jac)
            epoch_f1 += np.mean(batch_f1)
            epoch_recall += np.mean(batch_recall)
            epoch_precision += np.mean(batch_precision)

        epoch_loss = epoch_loss / len(loader)
        epoch_jac = epoch_jac / len(loader)
        epoch_f1 = epoch_f1 / len(loader)
        epoch_recall = epoch_recall / len(loader)
        epoch_precision = epoch_precision / len(loader)

        return epoch_loss, [epoch_jac, epoch_f1, epoch_recall, epoch_precision]
