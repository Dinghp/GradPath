import os
import random
import numpy as np
import torch
from skimage.measure import label, regionprops, find_contours
from sklearn.utils import shuffle
from .metrics import precision, recall, F2, dice_score, jac_score
from sklearn.metrics import accuracy_score
import cv2

""" Seeding the randomness. """


def seeding(seed):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True


""" Create a directory """


def create_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


""" Shuffle the dataset. """


def shuffling(x, y):
    x, y = shuffle(x, y, random_state=42)
    return x, y


def epoch_time(start_time, end_time):
    elapsed_time = end_time - start_time
    elapsed_mins = int(elapsed_time / 60)
    elapsed_secs = int(elapsed_time - (elapsed_mins * 60))
    return elapsed_mins, elapsed_secs


def print_and_save(file_path, data_str):
    print(data_str)
    with open(file_path, "a") as file:
        file.write(data_str)
        file.write("\n")


""" Convert a mask to border image """


def mask_to_border(mask):
    h, w = mask.shape
    border = np.zeros((h, w))

    contours = find_contours(mask, 128)
    for contour in contours:
        for c in contour:
            x = int(c[0])
            y = int(c[1])
            border[x][y] = 255

    return border


""" Mask to bounding boxes """


def mask_to_bbox(mask):
    bboxes = []

    mask = mask_to_border(mask)
    lbl = label(mask)
    props = regionprops(lbl)
    for prop in props:
        x1 = prop.bbox[1]
        y1 = prop.bbox[0]

        x2 = prop.bbox[3]
        y2 = prop.bbox[2]

        bboxes.append([x1, y1, x2, y2])

    return bboxes
def calculate_metrics(y_true, y_pred):
    y_pred = torch.sigmoid(y_pred)
    y_true = y_true.detach().cpu().numpy()
    y_pred = y_pred.detach().cpu().numpy()

    # 获取原始预测和真实mask
    y_pred_bin = y_pred > 0.5
    y_true_bin = y_true > 0.5

    # 计算边界mask
    def get_boundary_mask(mask):
        boundary = np.zeros_like(mask)
        for i in range(1, mask.shape[0] - 1):
            for j in range(1, mask.shape[1] - 1):
                # 检查3x3邻域内是否有不同类别的像素
                patch = mask[i - 1:i + 2, j - 1:j + 2]
                if np.any(patch != mask[i, j]):
                    boundary[i, j] = 1
        return boundary

    # 计算边界IoU (公式实现)
    def boundary_iou(gt, pred):
        gt_boundary = get_boundary_mask(gt)
        pred_boundary = get_boundary_mask(pred)

        intersection = np.logical_and(gt_boundary, pred_boundary)
        union = np.logical_or(gt_boundary, pred_boundary)

        # 避免除以零
        if np.sum(union) == 0:
            return 0.0

        return np.sum(intersection) / np.sum(union)


    # 展平用于其他指标计算
    y_pred_flat = y_pred_bin.reshape(-1).astype(np.uint8)
    y_true_flat = y_true_bin.reshape(-1).astype(np.uint8)

    ## Score
    score_jaccard = jac_score(y_true_flat, y_pred_flat)
    score_f1 = dice_score(y_true_flat, y_pred_flat)
    score_recall = recall(y_true_flat, y_pred_flat)
    score_precision = precision(y_true_flat, y_pred_flat)
    score_fbeta = F2(y_true_flat, y_pred_flat)
    score_acc = accuracy_score(y_true_flat, y_pred_flat)

    return [score_jaccard, score_f1, score_recall, score_precision, score_acc, score_fbeta]
