#!/bin/bash

# ======================
# 训练配置
# ======================
export CUDA_VISIBLE_DEVICES=0
export PYTHONPATH=.

# ======================
# 方法列表
# ======================
methods=(
  "DINO_GPS_DPT"
)

# ======================
# 数据集列表
# ======================
datasets=(
  "Kvasir-SEG"
  "tn3k"
  "BTMRI"
  "GLaS"
  "ISIC2017"
)

# ======================
# 公共训练超参
# ======================
IMG_SIZE=256
BATCH_SIZE=12
EPOCHS=100
LR=1e-4

WARMUP_LR=1e-4
WARMUP_EPOCHS=5

WEIGHT_DECAY=0.0

SEED=9233
PATIENCE=50
NUM_WORKERS=8

CALIBRATION_BATCHES=200

GPS_K=10

GPS_SCOPE="all"

GPS_SELECT_BIAS=1
GPS_SELECT_NORM=0

GPS_BIAS_K=10
GPS_NORM_K=10

# ======================
# DINOv3路径配置
# ======================
DINO_REPO=""

WEIGHTS_PATH=""

HUB_MODEL="dinov3_vits16plus"
ENCODER_SIZE="small"

# ======================
# 开始训练
# ======================
for method in "${methods[@]}"; do
  for dataset in "${datasets[@]}"; do

    echo "========================================"
    echo "Running GPS Experiment"
    echo "  Method               : ${method}"
    echo "  Dataset              : ${dataset}"
    echo "  Image size           : ${IMG_SIZE}"
    echo "  Batch size           : ${BATCH_SIZE}"
    echo "  Epochs               : ${EPOCHS}"
    echo "  GPS LR               : ${LR}"
    echo "  Warm-up LR           : ${WARMUP_LR}"
    echo "  Warm-up Epochs       : ${WARMUP_EPOCHS}"
    echo "  Calibration batches  : ${CALIBRATION_BATCHES}"
    echo "  GPS K                : ${GPS_K}"
    echo "  GPS Scope            : ${GPS_SCOPE}"
    echo "  GPS Select Bias      : ${GPS_SELECT_BIAS} (K=${GPS_BIAS_K})"
    echo "  GPS Select Norm      : ${GPS_SELECT_NORM} (K=${GPS_NORM_K})"
    echo "  Weight decay         : ${WEIGHT_DECAY}"
    echo "  Seed                 : ${SEED}"
    echo "========================================"

    python train_dino_gps_dpt.py \
      --method "${method}" \
      --dataset "${dataset}" \
      --img_size "${IMG_SIZE}" \
      --batch_size "${BATCH_SIZE}" \
      --epochs "${EPOCHS}" \
      --lr "${LR}" \
      --warmup_lr "${WARMUP_LR}" \
      --warmup_epochs "${WARMUP_EPOCHS}" \
      --weight_decay "${WEIGHT_DECAY}" \
      --seed "${SEED}" \
      --patience "${PATIENCE}" \
      --num_workers "${NUM_WORKERS}" \
      --calibration_batches "${CALIBRATION_BATCHES}" \
      --gps_k "${GPS_K}" \
      --gps_scope "${GPS_SCOPE}" \
      --gps_select_bias "${GPS_SELECT_BIAS}" \
      --gps_select_norm "${GPS_SELECT_NORM}" \
      --gps_bias_k "${GPS_BIAS_K}" \
      --gps_norm_k "${GPS_NORM_K}" \
      --dino_repo "${DINO_REPO}" \
      --weights_path "${WEIGHTS_PATH}" \
      --hub_model "${HUB_MODEL}" \
      --encoder_size "${ENCODER_SIZE}"

    if [ $? -ne 0 ]; then
      echo "❌ Failed: ${method} on ${dataset}"
      exit 1
    fi

  done
done

echo "✅ All GPS experiments finished!"