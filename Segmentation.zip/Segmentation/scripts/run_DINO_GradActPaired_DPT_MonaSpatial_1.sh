#!/bin/bash

# ======================
# 训练配置
# ======================
export CUDA_VISIBLE_DEVICES=0
export PYTHONPATH=.
methods=(
  "DINO_GradActPaired_DPT_MonaSpatial"
)

datasets=(
  "Kvasir-SEG"
#  "tn3k"
# "BUSI"
#  "BTMRI"
#  "GLaS"
#  "ISIC2017"
)

IMG_SIZE=256
BATCH_SIZE=12
EPOCHS=300
LR=1e-4

WARMUP_LR=1e-3 #BTMRI
WARMUP_EPOCHS=5

SEED=9233
PATIENCE=100

RANK_PER_BLOCK=96
TOTAL_BUDGET=0
CALIBRATION_BATCHES=20 #
TOKEN_MODE="patch"
TARGET_BLOCKS="all"

IMPORTANCE_BALANCE="foreground_background"

UPDATE_SELECTED_BIAS=1
UPDATE_NORM2=0

USE_SPATIAL=1

SPATIAL_DIM=0

SPATIAL_KERNELS="3,5,7"

SPATIAL_GAMMA_INIT=-3.0

DINO_REPO=""
WEIGHTS_PATH=""
HUB_MODEL="dinov3_vits16plus"
ENCODER_SIZE="small"

for method in "${methods[@]}"; do
  for dataset in "${datasets[@]}"; do

    echo "========================================"
    echo "Running Experiment"
    echo "  Method               : ${method}"
    echo "  Dataset              : ${dataset}"
    echo "  LR                   : ${LR}"
    echo "  Warm-up LR           : ${WARMUP_LR}"
    echo "  Warm-up Epochs       : ${WARMUP_EPOCHS}"
    echo "  Rank per block       : ${RANK_PER_BLOCK}"
    echo "  Calibration batches  : ${CALIBRATION_BATCHES}"
    echo "  Token mode           : ${TOKEN_MODE}"
    echo "  Importance balance   : ${IMPORTANCE_BALANCE}"
    echo "  Update selected bias : ${UPDATE_SELECTED_BIAS}"
    echo "  Update norm2         : ${UPDATE_NORM2}"
    echo "  Use spatial          : ${USE_SPATIAL}"
    echo "  Spatial dim          : ${SPATIAL_DIM}"
    echo "  Spatial kernels      : ${SPATIAL_KERNELS}"
    echo "  Spatial gamma init   : ${SPATIAL_GAMMA_INIT}"
    echo "  Decoder taps         : RAW @ encoder blocks 3/6/9/12"
    echo "  Spatial propagation  : enhanced state -> deeper encoder only"
    echo "========================================"

    python train_DINO_GradActPaired_DPT_MonaSpatial_1.py \
      --method "${method}" \
      --dataset "${dataset}" \
      --img_size "${IMG_SIZE}" \
      --batch_size "${BATCH_SIZE}" \
      --epochs "${EPOCHS}" \
      --lr "${LR}" \
      --warmup_lr "${WARMUP_LR}" \
      --warmup_epochs "${WARMUP_EPOCHS}" \
      --seed "${SEED}" \
      --patience "${PATIENCE}" \
      --rank_per_block "${RANK_PER_BLOCK}" \
      --total_budget "${TOTAL_BUDGET}" \
      --calibration_batches "${CALIBRATION_BATCHES}" \
      --token_mode "${TOKEN_MODE}" \
      --importance_balance "${IMPORTANCE_BALANCE}" \
      --update_selected_bias "${UPDATE_SELECTED_BIAS}" \
      --update_norm2 "${UPDATE_NORM2}" \
      --use_spatial "${USE_SPATIAL}" \
      --spatial_dim "${SPATIAL_DIM}" \
      --spatial_kernels "${SPATIAL_KERNELS}" \
      --spatial_gamma_init "${SPATIAL_GAMMA_INIT}" \
      --target_blocks "${TARGET_BLOCKS}" \
      --dino_repo "${DINO_REPO}" \
      --weights_path "${WEIGHTS_PATH}" \
      --hub_model "${HUB_MODEL}" \
      --encoder_size "${ENCODER_SIZE}"

    if [ $? -ne 0 ]; then
      echo "❌ Failed: ${method} on ${dataset}"
      exit 1
    fi

  done
done

echo "✅ All experiments finished!"
