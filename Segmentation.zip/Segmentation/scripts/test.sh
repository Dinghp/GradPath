#!/bin/bash

# ======================
# GPU 设置
# ======================
export CUDA_VISIBLE_DEVICES=0
export PYTHONPATH=.

# ======================
# 方法列表（要和 train 保持一致）
# ======================
methods=(
  "Adapter_DPT"
  "LoRA_DPT"
  "MONA_DPT"
  "Earth_Adapter_DPT"
  "Evidence_Adapter_MoE"
)

# ======================
# 数据集列表
# ======================
datasets=(
  "Kvasir-SEG"
)

# ======================
# 公共配置
# ======================
IMG_SIZE=256

# ======================
# 开始测试
# ======================
for method in "${methods[@]}"; do
  for dataset in "${datasets[@]}"; do

    echo "========================================"
    echo "Running Test"
    echo "  Method : ${method}"
    echo "  Dataset: ${dataset}"
    echo "========================================"

    # ======================
    # Checkpoint 路径（根据你 train 的实际目录调整）
    # ======================
    CKPT_PATH="run_files/${method}/${dataset}/checkpoint.pth"

    if [ ! -f "${CKPT_PATH}" ]; then
      echo "❌ Checkpoint not found: ${CKPT_PATH}"
      exit 1
    fi

    python test_vit.py \
      --method "${method}" \
      --dataset "${dataset}" \
      --img_size ${IMG_SIZE} \
      --checkpoint "${CKPT_PATH}" \
      --save_name "${method}"

    if [ $? -ne 0 ]; then
      echo "❌ Test failed: ${method} on ${dataset}"
      exit 1
    fi

  done
done

echo "✅ All tests finished!"