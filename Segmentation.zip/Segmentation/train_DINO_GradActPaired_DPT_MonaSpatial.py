import argparse
import datetime
import json
import os
import random
import time
import warnings

import albumentations as A
import numpy as np
import torch
from torch.utils.data import DataLoader

from models.DINO_GradActPaired_DPT_MonaSpatial import (
    DINO_GradActPaired_DPT,
    get_final_parameter_groups,
)
from utils1.metrics import DiceBCELoss
from utils1.run_vit import (
    DATASET,
    evaluate,
    load_data,
    train,
)
from utils1.utils import (
    epoch_time,
    print_and_save,
    shuffling,
)


warnings.filterwarnings(
    "ignore",
    category=UserWarning,
)
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.deterministic = False


def my_seeding(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def parse_target_blocks(value):
    value = value.strip()

    if (
        value.lower() == "all"
        or value.lower().startswith("last")
    ):
        return value.lower()

    if "," in value:
        return [
            int(index.strip())
            for index in value.split(",")
            if index.strip()
        ]

    return [int(value)]


def count_parameters(model):
    total = sum(
        parameter.numel()
        for parameter in model.parameters()
    )
    trainable = sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )

    return total, trainable


def make_serializable_selection_report(
    report,
):
    return {
        "rank_by_block": {
            str(block_index): int(rank)
            for block_index, rank
            in report[
                "rank_by_block"
            ].items()
        },
        "mean_score_by_block": {
            str(block_index): float(score)
            for block_index, score
            in report[
                "mean_score_by_block"
            ].items()
        },
        "ffn_type_by_block": {
            str(block_index): ffn_type
            for block_index, ffn_type
            in report[
                "ffn_type_by_block"
            ].items()
        },
        "importance_balance_report": {
            str(key): value
            for key, value
            in report[
                "importance_balance_report"
            ].items()
        },
        "update_selected_bias": bool(
            report["update_selected_bias"]
        ),
        "update_norm2": bool(
            report["update_norm2"]
        ),
        "use_spatial": bool(
            report["use_spatial"]
        ),
        "spatial_dim": int(
            report["spatial_dim"]
        ),
        "spatial_kernels": [
            int(kernel)
            for kernel in report["spatial_kernels"]
        ],
        "spatial_gamma_init": float(
            report["spatial_gamma_init"]
        ),
        "trainable_backbone_summary": {
            str(key): int(value)
            for key, value
            in report[
                "trainable_backbone_summary"
            ].items()
        },
        "selected_indices": {
            str(block_index): indices.tolist()
            for block_index, indices
            in report[
                "selected_indices"
            ].items()
        },
    }


def save_checkpoint(
    model,
    checkpoint_path,
    epoch,
    valid_metrics,
    args,
):
    model.sync_selected_weights()

    checkpoint = {
        "epoch": int(epoch),
        "valid_metrics": [
            float(value)
            for value in valid_metrics
        ],
        "model_state_dict": model.state_dict(),
        "selected_indices": {
            int(block_index): (
                indices.detach().cpu()
            )
            for block_index, indices
            in model.selected_indices.items()
        },
        "ffn_type_by_block": dict(
            model.ffn_type_by_block
        ),
        "update_selected_bias": bool(
            model.update_selected_bias
        ),
        "update_norm2": bool(
            model.update_norm2
        ),
        "use_spatial": bool(
            model.use_spatial
        ),
        "spatial_dim": int(
            model.spatial_dim
        ),
        "spatial_kernels": list(
            model.spatial_kernels
        ),
        "spatial_gamma_init": float(
            model.spatial_gamma_init
        ),
        "args": vars(args),
    }

    torch.save(
        checkpoint,
        checkpoint_path,
    )


def main():
    parser = argparse.ArgumentParser(
        "DINOv3 gradient-activation paired "
        "FFN path segmentation"
    )

    parser.add_argument(
        "--method",
        type=str,
        default="DINO_GradActPaired_DPT",
    )
    parser.add_argument(
        "--dataset",
        type=str,
        default="GLaS",
    )
    parser.add_argument(
        "--img_size",
        type=int,
        default=256,
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=12,
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=100,
    )
    parser.add_argument(
        "--lr",
        type=float,
        default=1e-4,
    )
    parser.add_argument(
        "--head_lr",
        type=float,
        default=None,
    )
    parser.add_argument(
        "--warmup_lr",
        type=float,
        default=1e-3,
    )
    parser.add_argument(
        "--warmup_epochs",
        type=int,
        default=5,
    )
    parser.add_argument(
        "--weight_decay",
        type=float,
        default=0.0,
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=9233,
    )
    parser.add_argument(
        "--patience",
        type=int,
        default=50,
    )
    parser.add_argument(
        "--num_workers",
        type=int,
        default=8,
    )

    parser.add_argument(
        "--dino_repo",
        type=str,
        default=r"",
    )
    parser.add_argument(
        "--hub_model",
        type=str,
        default="dinov3_vits16plus",
    )
    parser.add_argument(
        "--weights_path",
        type=str,
        default=None,
    )
    parser.add_argument(
        "--encoder_size",
        type=str,
        choices=(
            "small",
            "base",
            "large",
            "giant",
        ),
        default="small",
    )
    parser.add_argument(
        "--target_blocks",
        type=str,
        default="all",
    )

    parser.add_argument(
        "--calibration_batches",
        type=int,
        default=20,
    )
    parser.add_argument(
        "--rank_per_block",
        type=int,
        default=64,
    )
    parser.add_argument(
        "--total_budget",
        type=int,
        default=768,
    )
    parser.add_argument(
        "--min_rank_per_block",
        type=int,
        default=16,
    )
    parser.add_argument(
        "--max_rank_per_block",
        type=int,
        default=128,
    )
    parser.add_argument(
        "--normalize_mode",
        type=str,
        choices=(
            "mean",
            "l2",
            "max",
            "none",
        ),
        default="mean",
    )
    parser.add_argument(
        "--token_mode",
        type=str,
        choices=(
            "all",
            "cls",
            "patch",
        ),
        default="patch",
    )
    parser.add_argument(
        "--importance_balance",
        type=str,
        choices=(
            "foreground_background",
            "none",
        ),
        default="foreground_background",
    )
    parser.add_argument(
        "--update_selected_bias",
        type=int,
        choices=(0, 1),
        default=0,
    )
    parser.add_argument(
        "--update_norm2",
        type=int,
        choices=(0, 1),
        default=0,
    )
    parser.add_argument(
        "--use_spatial",
        type=int,
        choices=(0, 1),
        default=1,
        help=(
            "1: apply multi-kernel depthwise spatial enhancement "
            "to GradAct-selected hidden channels; 0: disable it."
        ),
    )
    parser.add_argument(
        "--spatial_dim",
        type=int,
        default=0,
        help=(
            "Spatial branch width. 0 means use each block's selected "
            "rank directly (no 1x1 down/up projections)."
        ),
    )
    parser.add_argument(
        "--spatial_kernels",
        type=str,
        default="3,5,7",
        help=(
            "Comma-separated non-empty subset of 3,5,7, e.g. 3,5,7; "
            "3,5; 3; 5; or 7."
        ),
    )
    parser.add_argument(
        "--spatial_gamma_init",
        type=float,
        default=-5.0,
        help=(
            "Initial gamma for alpha=sigmoid(gamma) that fuses the "
            "original selected feature and averaged depthwise response."
        ),
    )
    parser.add_argument(
        "--use_amp_calibration",
        action="store_true",
    )

    args = parser.parse_args()

    args.spatial_kernels = tuple(
        int(value.strip())
        for value in args.spatial_kernels.split(",")
        if value.strip()
    )

    if not args.spatial_kernels:
        raise ValueError(
            "--spatial_kernels cannot be empty"
        )
    if len(set(args.spatial_kernels)) != len(
        args.spatial_kernels
    ):
        raise ValueError(
            "--spatial_kernels must not contain duplicates"
        )
    unsupported_kernels = [
        kernel
        for kernel in args.spatial_kernels
        if kernel not in (3, 5, 7)
    ]
    if unsupported_kernels:
        raise ValueError(
            "--spatial_kernels only supports combinations of 3, 5, 7; "
            "got {}".format(unsupported_kernels)
        )
    if args.spatial_dim < 0:
        raise ValueError(
            "--spatial_dim must be >= 0"
        )

    if args.epochs <= 0:
        raise ValueError(
            "--epochs must be positive"
        )
    if args.warmup_epochs <= 0:
        raise ValueError(
            "--warmup_epochs must be positive"
        )
    if args.calibration_batches <= 0:
        raise ValueError(
            "--calibration_batches must be positive"
        )
    if (
        args.total_budget <= 0
        and args.rank_per_block <= 0
    ):
        raise ValueError(
            "Set a positive total_budget or "
            "rank_per_block"
        )
    if (
        args.importance_balance
        == "foreground_background"
        and args.token_mode != "patch"
    ):
        raise ValueError(
            "Foreground/background balancing "
            "requires --token_mode patch"
        )

    my_seeding(
        args.seed
    )

    current_time = (
        datetime.datetime.now()
        .strftime("%Y%m%d-%H%M%S")
    )
    folder_name = (
        "{}_lr{}_{}".format(
            args.dataset,
            args.lr,
            current_time,
        )
    )

    data_path = os.path.join(
        "data",
        args.dataset,
    )
    save_dir = os.path.join(
        "run_files_DINO_GradActPaired",
        args.method,
        args.dataset,
        folder_name,
    )
    os.makedirs(
        save_dir,
        exist_ok=True,
    )

    train_log_path = os.path.join(
        save_dir,
        "train_log.txt",
    )
    checkpoint_path = os.path.join(
        save_dir,
        "checkpoint.pth",
    )
    checkpoint_last_path = os.path.join(
        save_dir,
        "checkpoint_last.pth",
    )
    selection_path = os.path.join(
        save_dir,
        "selection_report.json",
    )
    config_path = os.path.join(
        save_dir,
        "config.json",
    )

    with open(
        config_path,
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            vars(args),
            file,
            indent=4,
            ensure_ascii=False,
        )

    with open(
        train_log_path,
        "w",
        encoding="utf-8",
    ) as file:
        file.write("\n")

    print_and_save(
        train_log_path,
        str(datetime.datetime.now()),
    )
    print_and_save(
        train_log_path,
        (
            "Image Size: {}\n"
            "Batch Size: {}\n"
            "Warm-up Epochs: {}\n"
            "Main Epochs: {}\n"
            "Path LR: {}\n"
            "Head LR: {}\n"
            "Warm-up LR: {}\n"
            "Calibration Batches: {}\n"
            "Token Mode: {}\n"
            "Importance Balance: {}\n"
            "Update Selected Bias: {}\n"
            "Update Norm2: {}\n"
            "Use Spatial: {}\n"
            "Spatial Dim: {}\n"
            "Spatial Kernels: {}\n"
            "Spatial Gamma Init: {}\n"
            "Total Budget: {}\n"
            "Min/Max Rank: {}/{}\n"
            "Normalize Mode: {}\n"
        ).format(
            args.img_size,
            args.batch_size,
            args.warmup_epochs,
            args.epochs,
            args.lr,
            args.head_lr,
            args.warmup_lr,
            args.calibration_batches,
            args.token_mode,
            args.importance_balance,
            bool(args.update_selected_bias),
            bool(args.update_norm2),
            bool(args.use_spatial),
            args.spatial_dim,
            args.spatial_kernels,
            args.spatial_gamma_init,
            args.total_budget,
            args.min_rank_per_block,
            args.max_rank_per_block,
            args.normalize_mode,
        ),
    )

    transform = A.Compose(
        [
            A.Rotate(
                limit=90,
                p=0.5,
            ),
            A.HorizontalFlip(
                p=0.5,
            ),
            A.VerticalFlip(
                p=0.5,
            ),
            A.CoarseDropout(
                p=0.3,
                max_holes=10,
                max_height=32,
                max_width=32,
            ),
        ]
    )

    (
        train_x,
        train_y,
    ), (
        valid_x,
        valid_y,
    ) = load_data(
        data_path,
        val_name=None,
    )

    train_x, train_y = shuffling(
        train_x,
        train_y,
    )

    print_and_save(
        train_log_path,
        (
            "Dataset Size:\n"
            "Train: {} - Valid: {}\n"
        ).format(
            len(train_x),
            len(valid_x),
        ),
    )

    train_ds = DATASET(
        train_x,
        train_y,
        (
            args.img_size,
            args.img_size,
        ),
        transform=transform,
    )
    calibration_ds = DATASET(
        train_x,
        train_y,
        (
            args.img_size,
            args.img_size,
        ),
        transform=None,
    )
    val_ds = DATASET(
        valid_x,
        valid_y,
        (
            args.img_size,
            args.img_size,
        ),
        transform=None,
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
    )
    calibration_loader = DataLoader(
        calibration_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
    )
    valid_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
    )

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    model = DINO_GradActPaired_DPT(
        nclass=1,
        encoder_size=args.encoder_size,
        dino_repo=args.dino_repo,
        hub_model=args.hub_model,
        weights_path=args.weights_path,
        target_blocks=parse_target_blocks(
            args.target_blocks
        ),
    ).to(device)

    ffn_structure = model.print_ffn_structure()
    print_and_save(
        train_log_path,
        (
            "DINOv3 storage tokens: {}\n"
            "FFN structure: {}"
        ).format(
            int(
                getattr(
                    model.backbone,
                    "n_storage_tokens",
                    0,
                )
            ),
            ffn_structure,
        ),
    )

    loss_fn = DiceBCELoss()
    loss_name = "BCE Dice Loss"

    total_parameters, trainable_parameters = (
        count_parameters(model)
    )
    print_and_save(
        train_log_path,
        (
            "Before warm-up - Total parameters: "
            "{:.4f}M | Trainable parameters: "
            "{:.4f}M\nOptimizer: Adam\n"
            "Loss: {}"
        ).format(
            total_parameters / 1e6,
            trainable_parameters / 1e6,
            loss_name,
        ),
    )

    # ========================================================
    # Stage 1: warm up only the DPT head
    # ========================================================

    warmup_optimizer = torch.optim.Adam(
        model.head.parameters(),
        lr=args.warmup_lr,
        weight_decay=args.weight_decay,
    )

    warmup_valid_metrics = None

    for warmup_epoch in range(
        1,
        args.warmup_epochs + 1,
    ):
        warmup_start = time.time()

        warmup_train_loss, warmup_train_metrics = train(
            model,
            train_loader,
            warmup_optimizer,
            loss_fn,
            device,
        )
        warmup_valid_loss, warmup_valid_metrics = evaluate(
            model,
            valid_loader,
            loss_fn,
            device,
        )

        warmup_mins, warmup_secs = epoch_time(
            warmup_start,
            time.time(),
        )

        print_and_save(
            train_log_path,
            (
                "[Warm-up Epoch {}/{}]\n"
                "\tTime: {}m {}s\n"
                "\tTrain Loss: {:.4f} - "
                "mIoU: {:.4f} - F1: {:.4f} - "
                "Recall: {:.4f} - Precision: {:.4f}\n"
                "\tVal Loss: {:.4f} - "
                "mIoU: {:.4f} - F1: {:.4f} - "
                "Recall: {:.4f} - Precision: {:.4f}\n"
            ).format(
                warmup_epoch,
                args.warmup_epochs,
                warmup_mins,
                warmup_secs,
                warmup_train_loss,
                warmup_train_metrics[0],
                warmup_train_metrics[1],
                warmup_train_metrics[2],
                warmup_train_metrics[3],
                warmup_valid_loss,
                warmup_valid_metrics[0],
                warmup_valid_metrics[1],
                warmup_valid_metrics[2],
                warmup_valid_metrics[3],
            ),
        )

    del warmup_optimizer

    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    # ========================================================
    # Stage 2: collect |activation * gradient| and inject paths
    # ========================================================

    use_global_budget = (
        args.total_budget > 0
    )

    if use_global_budget:
        print_and_save(
            train_log_path,
            (
                "Using global budget: total={}, "
                "minimum={}, maximum={}, "
                "normalization={}, token_mode={}"
            ).format(
                args.total_budget,
                args.min_rank_per_block,
                args.max_rank_per_block,
                args.normalize_mode,
                args.token_mode,
            ),
        )
    else:
        print_and_save(
            train_log_path,
            (
                "Using fixed rank per block: {}, "
                "token_mode={}"
            ).format(
                args.rank_per_block,
                args.token_mode,
            ),
        )

    selection_report = model.select_and_inject(
        data_loader=calibration_loader,
        criterion=loss_fn,
        device=device,
        num_calibration_batches=(
            args.calibration_batches
        ),
        rank_per_block=(
            None
            if use_global_budget
            else args.rank_per_block
        ),
        total_budget=(
            args.total_budget
            if use_global_budget
            else None
        ),
        min_rank_per_block=(
            args.min_rank_per_block
        ),
        max_rank_per_block=(
            args.max_rank_per_block
        ),
        normalize_mode=args.normalize_mode,
        token_mode=args.token_mode,
        use_amp=args.use_amp_calibration,
        importance_balance=args.importance_balance,
        update_selected_bias=bool(
            args.update_selected_bias
        ),
        update_norm2=bool(
            args.update_norm2
        ),
        use_spatial=bool(
            args.use_spatial
        ),
        spatial_dim=args.spatial_dim,
        spatial_kernels=args.spatial_kernels,
        spatial_gamma_init=args.spatial_gamma_init,
    )

    serializable_report = (
        make_serializable_selection_report(
            selection_report
        )
    )

    with open(
        selection_path,
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            serializable_report,
            file,
            indent=4,
            ensure_ascii=False,
        )

    print_and_save(
        train_log_path,
        (
            "FFN types by block: {}"
        ).format(
            json.dumps(
                serializable_report[
                    "ffn_type_by_block"
                ],
                ensure_ascii=False,
            )
        ),
    )
    print_and_save(
        train_log_path,
        (
            "Selected ranks by block: {}"
        ).format(
            json.dumps(
                serializable_report[
                    "rank_by_block"
                ],
                ensure_ascii=False,
            )
        ),
    )
    print_and_save(
        train_log_path,
        (
            "Mean importance by block: {}"
        ).format(
            json.dumps(
                serializable_report[
                    "mean_score_by_block"
                ],
                ensure_ascii=False,
            )
        ),
    )
    print_and_save(
        train_log_path,
        (
            "Foreground/background balance report: {}"
        ).format(
            json.dumps(
                serializable_report[
                    "importance_balance_report"
                ],
                ensure_ascii=False,
            )
        ),
    )
    print_and_save(
        train_log_path,
        (
            "Update selected bias: {} | Update norm2: {}"
        ).format(
            serializable_report[
                "update_selected_bias"
            ],
            serializable_report[
                "update_norm2"
            ],
        ),
    )
    print_and_save(
        train_log_path,
        (
            "Trainable backbone parameter summary: {}"
        ).format(
            json.dumps(
                serializable_report[
                    "trainable_backbone_summary"
                ],
                ensure_ascii=False,
            )
        ),
    )

    total_parameters, trainable_parameters = (
        count_parameters(model)
    )
    print_and_save(
        train_log_path,
        (
            "After path injection - Total parameters: "
            "{:.4f}M | Trainable parameters: "
            "{:.4f}M | Trainable ratio: {:.4f}%"
        ).format(
            total_parameters / 1e6,
            trainable_parameters / 1e6,
            100.0
            * trainable_parameters
            / total_parameters,
        ),
    )

    # ========================================================
    # Stage 3: train selected FFN paths and the DPT head
    # ========================================================

    final_optimizer = torch.optim.Adam(
        get_final_parameter_groups(
            model=model,
            path_lr=args.lr,
            head_lr=args.head_lr,
            weight_decay=args.weight_decay,
        ),
        lr=args.lr,
    )

    scheduler = (
        torch.optim.lr_scheduler
        .ReduceLROnPlateau(
            final_optimizer,
            mode="min",
            patience=30,
        )
    )

    best_valid_miou = -1.0
    early_stopping_count = 0
    last_epoch = 0
    last_valid_metrics = warmup_valid_metrics

    for epoch in range(
        1,
        args.epochs + 1,
    ):
        last_epoch = epoch
        start_time = time.time()

        train_loss, train_metrics = train(
            model,
            train_loader,
            final_optimizer,
            loss_fn,
            device,
        )
        valid_loss, valid_metrics = evaluate(
            model,
            valid_loader,
            loss_fn,
            device,
        )
        last_valid_metrics = valid_metrics

        scheduler.step(
            valid_loss
        )

        if valid_metrics[0] > best_valid_miou:
            print_and_save(
                train_log_path,
                (
                    "Valid mIoU improved from "
                    "{:.4f} to {:.4f}. "
                    "Saving checkpoint: {}"
                ).format(
                    best_valid_miou,
                    valid_metrics[0],
                    checkpoint_path,
                ),
            )

            best_valid_miou = valid_metrics[0]

            save_checkpoint(
                model=model,
                checkpoint_path=checkpoint_path,
                epoch=epoch,
                valid_metrics=valid_metrics,
                args=args,
            )
            early_stopping_count = 0
        else:
            early_stopping_count += 1

        epoch_mins, epoch_secs = epoch_time(
            start_time,
            time.time(),
        )

        data_str = (
            "Epoch: {:02d} | Epoch Time: {}m {}s\n"
        ).format(
            epoch,
            epoch_mins,
            epoch_secs,
        )
        data_str += (
            "\tTrain Loss: {:.4f} - "
            "mIoU: {:.4f} - F1: {:.4f} - "
            "Recall: {:.4f} - Precision: {:.4f}\n"
        ).format(
            train_loss,
            train_metrics[0],
            train_metrics[1],
            train_metrics[2],
            train_metrics[3],
        )
        data_str += (
            "\t Val. Loss: {:.4f} - "
            "mIoU: {:.4f} - F1: {:.4f} - "
            "Recall: {:.4f} - Precision: {:.4f}\n"
        ).format(
            valid_loss,
            valid_metrics[0],
            valid_metrics[1],
            valid_metrics[2],
            valid_metrics[3],
        )

        print_and_save(
            train_log_path,
            data_str,
        )

        if early_stopping_count >= args.patience:
            print_and_save(
                train_log_path,
                (
                    "Early stopping: validation mIoU "
                    "did not improve for {} epochs."
                ).format(
                    args.patience
                ),
            )
            break

    save_checkpoint(
        model=model,
        checkpoint_path=checkpoint_last_path,
        epoch=last_epoch,
        valid_metrics=last_valid_metrics,
        args=args,
    )

    print_and_save(
        train_log_path,
        (
            "Best validation mIoU: {:.4f}\n"
            "Best checkpoint: {}\n"
            "Last checkpoint: {}\n"
            "Selection report: {}"
        ).format(
            best_valid_miou,
            checkpoint_path,
            checkpoint_last_path,
            selection_path,
        ),
    )


if __name__ == "__main__":
    main()