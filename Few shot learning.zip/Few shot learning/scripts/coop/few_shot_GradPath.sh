#!/bin/bash

# Usage:
# bash scripts/coop/few_shot_tune.sh DATA_ROOT DATASET SHOTS MODEL
# Example:
# bash scripts/coop/few_shot_tune.sh /path/to/data dermamnist 4 BiomedCLIP

DATA=$1
DATASET=$2
SHOTS=$3

MODEL=BiomedCLIP
NCTX=4
CSC=False
CTP=end
CFG=vit_b16_tune1


# The supplied tuned trainer is CoOpTune_BiomedCLIP.
TRAINER=CoOpTune_${MODEL}

# GradAct settings. You can change them here without editing yaml.
RANK_PER_BLOCK=96
TOTAL_BUDGET=0
TOKEN_MODE=all
CALIBRATION_PASSES=1
CALIBRATION_BATCHES=0
UPDATE_SELECTED_BIAS=True
PROMPT_LR=0.0
FFN_LR=0.0002

for DATASET in btmri chmnist covid kvasir lungcolon octmnist CTKIDNEY
do
for SHOTS in 4 8 16
do
for SEED in  1 2 3
do
    DIR=output/${DATASET}/shots_${SHOTS}/${TRAINER}/rank${RANK_PER_BLOCK}_${TOKEN_MODE}/seed${SEED}

    if [ -d "$DIR" ]; then
        echo "Oops! The results exist at ${DIR} (skip)"
    else
        python train_GradPath.py \
            --root "${DATA}" \
            --seed "${SEED}" \
            --trainer "${TRAINER}" \
            --dataset-config-file "configs/datasets/${DATASET}.yaml" \
            --config-file "configs/trainers/CoOp/${CFG}.yaml" \
            --output-dir "${DIR}" \
            TRAINER.COOP.N_CTX ${NCTX} \
            TRAINER.COOP.CSC ${CSC} \
            TRAINER.COOP.CLASS_TOKEN_POSITION ${CTP} \
            DATASET.NUM_SHOTS ${SHOTS} \
            TUNE.GRADACT.RANK_PER_BLOCK ${RANK_PER_BLOCK} \
            TUNE.GRADACT.TOTAL_BUDGET ${TOTAL_BUDGET} \
            TUNE.GRADACT.TOKEN_MODE ${TOKEN_MODE} \
            TUNE.GRADACT.CALIBRATION_PASSES ${CALIBRATION_PASSES} \
            TUNE.GRADACT.CALIBRATION_BATCHES ${CALIBRATION_BATCHES} \
            TUNE.GRADACT.UPDATE_SELECTED_BIAS ${UPDATE_SELECTED_BIAS}
    fi
done
done
done
