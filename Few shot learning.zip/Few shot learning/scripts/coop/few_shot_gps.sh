#!/bin/bash

# Fixed Prompt + GPS visual-backbone tuning
#
# Usage:
# bash scripts/coop/few_shot_gps.sh DATA_ROOT DATASET SHOTS MODEL
#
# Example:
# bash scripts/coop/few_shot_gps.sh /path/to/data btmri 8 BiomedCLIP

DATA=$1
DATASET=$2
SHOTS=$3
MODEL=BiomedCLIP

NCTX=4
CSC=False
CTP=end
CFG=vit_b16_gps

TRAINER=CoOpGPS_${MODEL}

# ============================================================
# GPS settings
# ============================================================
GPS_SCOPE=all
GPS_K=10
CALIBRATION_PASSES=1
CALIBRATION_BATCHES=0
GPS_WARMUP_EPOCHS=0
GPS_LR=0.0002

for DATASET in btmri busi chmnist covid kvasir lungcolon octmnist CTKIDNEY
do
for SHOTS in 4 8 16
do
for SEED in  1 2 3
do
    DIR=output_gps/${DATASET}/shots_${SHOTS}/${TRAINER}/gps_k${GPS_K}_${GPS_SCOPE}_lr${GPS_LR}/seed${SEED}

    if [ -d "$DIR" ]; then
        echo "Oops! The results exist at ${DIR} (skip)"
    else
        python train_tune_gps.py \
            --root "${DATA}" \
            --seed "${SEED}" \
            --trainer "${TRAINER}" \
            --dataset-config-file "configs/datasets/${DATASET}.yaml" \
            --config-file "configs/trainers/CoOp/${CFG}.yaml" \
            --output-dir "${DIR}" \
            TRAINER.COOP.N_CTX ${NCTX} \
            TRAINER.COOP.CSC ${CSC} \
            TRAINER.COOP.CLASS_TOKEN_POSITION ${CTP} \
            DATASET.NUM_SHOTS ${SHOTS} \
            TUNE.GPS.WARMUP_EPOCHS ${GPS_WARMUP_EPOCHS} \
            TUNE.GPS.SCOPE ${GPS_SCOPE} \
            TUNE.GPS.K ${GPS_K} \
            TUNE.GPS.CALIBRATION_PASSES ${CALIBRATION_PASSES} \
            TUNE.GPS.CALIBRATION_BATCHES ${CALIBRATION_BATCHES} \
            TUNE.GPS.LR ${GPS_LR}
    fi
done
done
done
