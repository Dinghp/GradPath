#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Generic GPS tuning entry for prompt-based CLIP trainers.

Current CoOp protocol
---------------------
1. Build BiomedCLIP with the fixed prompt ``a photo of a [CLASS]``.
2. Freeze prompt/text encoder/visual encoder.
3. Before epoch 1, collect GPS importance on the few-shot training set:

       score(w) = mean_batch |dL / dw|

   for original visual-backbone Linear/Conv2d weights.
4. For every output neuron/channel of every candidate weight tensor, select
   the Top-K input connections with the largest gradient importance.
5. Keep the original visual modules unchanged and mask gradients so only the
   selected scalar connections can change during fine-tuning.

This follows the user's previous GPS implementation. Unlike GradAct, GPS
selects individual pretrained weight connections directly, so calibration
makes the candidate visual weights temporarily require gradients; input images
do not need ``requires_grad_(True)``.

A trainer opts in by exposing:
    trainer.get_gps_backbone() -> visual backbone nn.Module
    trainer.gps_selection_loss(image, label) -> scalar task loss
"""

import argparse
import json
import os
import os.path as osp
from typing import Dict, Iterable, Sequence

import torch
import torch.nn as nn
from torch.nn import functional as F
from yacs.config import CfgNode as CN

from dassl.config import get_cfg_default
from dassl.engine import build_trainer
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.utils import setup_logger, set_random_seed, collect_env_info

import train as base_train
import trainers.CoOp.coop_biomedclip_gps  # noqa: F401


# =============================================================================
# GPS candidate discovery
# =============================================================================

def _module_matches_gps_scope(module_name: str, gps_scope: str) -> bool:
    scope = str(gps_scope).lower()
    if scope == "all":
        return True

    name = module_name.lower()
    if scope == "ffn":
        return (
            ".mlp" in name
            or name.endswith("mlp")
            or ".ffn" in name
            or name.endswith("ffn")
        )
    if scope == "attn":
        return (
            ".attn" in name
            or name.endswith("attn")
            or ".attention" in name
            or name.endswith("attention")
        )

    raise ValueError(
        "GPS.SCOPE must be one of {'all', 'ffn', 'attn'}, "
        f"got {gps_scope!r}"
    )


def get_gps_candidate_weights(backbone: nn.Module, gps_scope: str = "all"):
    """Return original visual-backbone Linear/Conv2d weight tensors.

    Linear weight: [out_features, in_features]
    Conv2d weight: [out_channels, in_channels, kh, kw]

    Dimension 0 is the output neuron/channel. All remaining dimensions are
    flattened into the input connections of that output unit.
    """
    candidates = {}
    seen_parameter_ids = set()

    for module_name, module in backbone.named_modules():
        if not _module_matches_gps_scope(module_name, gps_scope):
            continue
        if not isinstance(module, (nn.Linear, nn.Conv2d)):
            continue

        weight = getattr(module, "weight", None)
        if (
            weight is None
            or not isinstance(weight, nn.Parameter)
            or weight.ndim < 2
        ):
            continue

        if id(weight) in seen_parameter_ids:
            continue
        seen_parameter_ids.add(id(weight))

        parameter_name = (
            f"{module_name}.weight" if module_name else "weight"
        )
        candidates[parameter_name] = weight

    if not candidates:
        raise RuntimeError(
            f"No Linear/Conv2d visual weights found for GPS scope={gps_scope!r}"
        )

    return candidates


# =============================================================================
# Calibration: mean absolute parameter gradient
# =============================================================================

def _parse_train_batch(trainer, batch):
    parsed = trainer.parse_batch_train(batch)
    if not isinstance(parsed, (tuple, list)) or len(parsed) < 2:
        raise TypeError(
            "trainer.parse_batch_train(batch) must return at least "
            "(image, label)"
        )
    return parsed[0], parsed[1]


def get_gps_backbone(trainer):
    if hasattr(trainer, "get_gps_backbone"):
        backbone = trainer.get_gps_backbone()
    else:
        model = (
            trainer.model.module
            if isinstance(trainer.model, nn.DataParallel)
            else trainer.model
        )
        if not hasattr(model, "image_encoder"):
            raise AttributeError(
                "Trainer must expose get_gps_backbone() or model.image_encoder"
            )
        visual = model.image_encoder
        backbone = visual.trunk if hasattr(visual, "trunk") else visual

    if not isinstance(backbone, nn.Module):
        raise TypeError("GPS visual backbone must be an nn.Module")
    return backbone


def collect_gps_gradient_importance(trainer, cfg, backbone):
    tune_cfg = cfg.TUNE.GPS
    gps_scope = str(tune_cfg.SCOPE)
    passes = int(tune_cfg.CALIBRATION_PASSES)
    max_batches = int(tune_cfg.CALIBRATION_BATCHES)
    use_amp = bool(
        tune_cfg.CALIBRATION_AMP and trainer.device.type == "cuda"
    )

    if passes <= 0:
        raise ValueError("GPS.CALIBRATION_PASSES must be positive")
    if max_batches < 0:
        raise ValueError("GPS.CALIBRATION_BATCHES cannot be negative")

    model = trainer.model
    candidates = get_gps_candidate_weights(
        backbone,
        gps_scope=gps_scope,
    )

    params = list(model.parameters())
    requires_grad_flags = [p.requires_grad for p in params]
    module_training_flags = [(m, m.training) for m in model.modules()]

    # GPS needs dL/dw for the candidate pretrained weights themselves.
    for p in params:
        p.requires_grad_(False)
    for p in candidates.values():
        p.requires_grad_(True)

    model.eval()

    importance = {
        name: torch.zeros(
            tuple(parameter.shape),
            dtype=torch.float32,
            device="cpu",
        )
        for name, parameter in candidates.items()
    }
    seen_batches = {name: 0 for name in candidates}

    processed_batches = 0
    loss_sum = 0.0

    try:
        for pass_idx in range(passes):
            print(
                f"[GPS] calibration pass {pass_idx + 1}/{passes} "
                f"(max_batches={max_batches if max_batches > 0 else 'all'})"
            )

            for batch_idx, batch in enumerate(trainer.train_loader_x):
                if max_batches > 0 and batch_idx >= max_batches:
                    break

                image, label = _parse_train_batch(trainer, batch)
                # No image.requires_grad_(True) is needed for GPS because the
                # selected candidate weights themselves require gradients.
                image = image.detach()

                model.zero_grad(set_to_none=True)
                with torch.cuda.amp.autocast(enabled=use_amp):
                    if hasattr(trainer, "gps_selection_loss"):
                        loss = trainer.gps_selection_loss(image, label)
                    else:
                        logits = model(image)
                        loss = F.cross_entropy(logits, label)

                if loss.ndim != 0:
                    loss = loss.mean()
                loss.backward()

                processed_batches += 1
                loss_sum += float(loss.detach().float().cpu())

                for name, parameter in candidates.items():
                    if parameter.grad is None:
                        continue
                    importance[name].add_(
                        parameter.grad.detach().float().abs().cpu()
                    )
                    seen_batches[name] += 1

        if processed_batches == 0:
            raise RuntimeError("GPS calibration consumed zero batches")

    finally:
        model.zero_grad(set_to_none=True)

        for p, flag in zip(params, requires_grad_flags):
            p.requires_grad_(flag)
        for module, flag in module_training_flags:
            module.training = flag

    unused = [name for name, count in seen_batches.items() if count == 0]
    for name in unused:
        importance.pop(name, None)
        seen_batches.pop(name, None)

    if not importance:
        raise RuntimeError("None of the GPS candidate weights received gradients")

    for name in importance:
        importance[name].div_(float(seen_batches[name]))

    calibration_report = {
        "processed_batches": int(processed_batches),
        "mean_calibration_loss": float(loss_sum / processed_batches),
        "candidate_tensor_count": int(len(importance)),
        "candidate_parameter_count": int(
            sum(score.numel() for score in importance.values())
        ),
        "unused_candidate_tensors": unused,
    }

    print(
        f"[GPS] collected gradients from {processed_batches} batches; "
        f"candidate tensors={len(importance)}"
    )
    return importance, calibration_report


# =============================================================================
# GPS selection: Top-K input connections per output neuron/channel
# =============================================================================

def select_gps_topk_per_neuron(importance, topk_connections=1):
    topk_connections = int(topk_connections)
    if topk_connections <= 0:
        raise ValueError("GPS.K must be positive")

    masks = {}
    selected_flat_indices = {}
    layer_report = {}

    for name, score in importance.items():
        if score.ndim < 2:
            continue

        original_shape = tuple(score.shape)
        flat_score = score.reshape(score.shape[0], -1)
        input_connections = int(flat_score.shape[1])
        k = min(topk_connections, input_connections)

        topk_idx = torch.topk(
            flat_score,
            k=k,
            dim=1,
            largest=True,
            sorted=False,
        ).indices

        flat_mask = torch.zeros_like(flat_score, dtype=torch.bool)
        flat_mask.scatter_(1, topk_idx, True)
        mask = flat_mask.reshape(original_shape)

        selected = torch.nonzero(
            mask.reshape(-1),
            as_tuple=False,
        ).flatten().cpu()

        masks[name] = mask.cpu()
        selected_flat_indices[name] = selected
        layer_report[name] = {
            "shape": list(original_shape),
            "output_neurons": int(flat_score.shape[0]),
            "input_connections_per_neuron": int(input_connections),
            "selected_connections_per_neuron": int(k),
            "selected_parameters": int(mask.sum().item()),
            "candidate_parameters": int(mask.numel()),
            "selected_ratio_percent": float(
                100.0 * mask.sum().item() / mask.numel()
            ),
            "mean_gradient_score": float(score.mean().item()),
            "max_gradient_score": float(score.max().item()),
        }

    if not masks:
        raise RuntimeError("GPS did not produce any masks")

    return masks, selected_flat_indices, layer_report


def build_masks_from_flat_indices(
    backbone,
    selected_flat_indices,
    gps_scope="all",
):
    candidates = get_gps_candidate_weights(
        backbone,
        gps_scope=gps_scope,
    )

    masks = {}
    for name, flat_indices in selected_flat_indices.items():
        if name not in candidates:
            raise KeyError(
                f"Saved GPS parameter {name!r} does not exist in visual backbone"
            )

        parameter = candidates[name]
        mask_flat = torch.zeros(
            parameter.numel(),
            dtype=torch.bool,
            device="cpu",
        )
        indices = torch.as_tensor(
            flat_indices,
            dtype=torch.long,
            device="cpu",
        ).flatten()

        if indices.numel() > 0:
            if (
                indices.min().item() < 0
                or indices.max().item() >= parameter.numel()
            ):
                raise ValueError(f"Saved GPS indices for {name!r} are out of range")
            mask_flat[indices] = True

        masks[name] = mask_flat.reshape(tuple(parameter.shape))

    return masks


# =============================================================================
# Masked fine-tuning: original modules remain unchanged
# =============================================================================

def enable_gps_masked_finetuning(
    trainer,
    backbone,
    masks,
    gps_scope="all",
):
    model = trainer.model

    for handle in getattr(trainer, "_gps_hook_handles", []):
        handle.remove()
    trainer._gps_hook_handles = []

    # Visual-only tuning requested here: prompt/text and every unselected
    # visual parameter remain frozen.
    for parameter in model.parameters():
        parameter.requires_grad_(False)

    candidates = get_gps_candidate_weights(
        backbone,
        gps_scope=gps_scope,
    )

    gpu_masks = {}
    for name in sorted(masks):
        if name not in candidates:
            raise KeyError(f"GPS mask parameter {name!r} was not found")

        parameter = candidates[name]
        mask_cpu = masks[name]
        if tuple(mask_cpu.shape) != tuple(parameter.shape):
            raise ValueError(
                f"Mask shape {tuple(mask_cpu.shape)} does not match "
                f"{name} shape {tuple(parameter.shape)}"
            )

        parameter.requires_grad_(True)
        mask = mask_cpu.to(device=parameter.device, dtype=torch.bool)
        gpu_masks[name] = mask

        def _mask_gradient(grad, local_mask=mask):
            return grad.masked_fill(~local_mask, 0)

        trainer._gps_hook_handles.append(
            parameter.register_hook(_mask_gradient)
        )

    trainer.gps_masks = gpu_masks
    trainer.gps_scope = str(gps_scope)
    trainer.gps_active = True


class GPSCheckpointState(nn.Module):
    """Checkpoint GPS candidate tensors through Dassl.

    GPS keeps the original Linear/Conv layers unchanged, so the trainable
    objects are the original dense weight tensors carrying sparse gradient
    masks. We register references to those tensors here so Dassl saves/restores
    them together with optimizer/scheduler state.
    """

    def __init__(self, backbone, selected_names, gps_scope="all"):
        super().__init__()
        candidates = get_gps_candidate_weights(
            backbone,
            gps_scope=gps_scope,
        )

        self.params = nn.ParameterDict()
        self.parameter_name_map = {}

        for idx, name in enumerate(sorted(selected_names)):
            if name not in candidates:
                raise KeyError(f"GPS checkpoint parameter {name!r} not found")
            key = f"p{idx:04d}"
            self.params[key] = candidates[name]
            self.parameter_name_map[key] = name

        if len(self.params) == 0:
            raise RuntimeError("No GPS candidate tensors to checkpoint")


def gps_effective_parameter_summary(trainer):
    selected = int(
        sum(mask.sum().item() for mask in getattr(trainer, "gps_masks", {}).values())
    )
    total = int(sum(p.numel() for p in trainer.model.parameters()))
    optimizer_visible = int(
        sum(
            p.numel()
            for p in trainer.model.parameters()
            if p.requires_grad
        )
    )

    return {
        "selected_visual_parameters": selected,
        "optimizer_visible_tensor_parameters": optimizer_visible,
        "total_model_parameters": total,
        "effective_trainable_ratio_percent": float(
            100.0 * selected / max(total, 1)
        ),
    }


def register_gps_checkpoint(trainer, backbone, masks, gps_scope):
    if "gps_visual" in trainer._models:
        return trainer._models["gps_visual"]

    state = GPSCheckpointState(
        backbone,
        selected_names=masks.keys(),
        gps_scope=gps_scope,
    )
    trainer.register_model("gps_visual", state, None, None)
    return state


def build_gps_optimizer_and_scheduler(trainer, cfg, backbone, masks):
    gps_scope = str(cfg.TUNE.GPS.SCOPE)
    candidates = get_gps_candidate_weights(
        backbone,
        gps_scope=gps_scope,
    )

    gps_params = [candidates[name] for name in sorted(masks)]
    if not gps_params:
        raise RuntimeError("No GPS visual parameters are trainable")

    gps_lr = float(cfg.TUNE.GPS.LR)
    if gps_lr < 0:
        gps_lr = float(cfg.OPTIM.LR)

    # Critical GPS requirement: zero weight decay on masked backbone tensors.
    # Otherwise an optimizer could change unselected entries even though their
    # gradients are zero.
    param_groups = [
        {
            "params": gps_params,
            "lr": gps_lr,
            "weight_decay": 0.0,
        }
    ]

    optim_cfg = cfg.OPTIM.clone()
    optim_cfg.defrost()
    optim_cfg.STAGED_LR = False
    optim_cfg.LR = gps_lr
    optim_cfg.WEIGHT_DECAY = 0.0
    optim_cfg.freeze()

    optim = build_optimizer(param_groups, optim_cfg)
    sched = build_lr_scheduler(optim, optim_cfg)

    trainer._optims["gps_visual"] = optim
    trainer._scheds["gps_visual"] = sched

    if hasattr(trainer, "optim"):
        trainer.optim = optim
    if hasattr(trainer, "sched"):
        trainer.sched = sched

    print(
        f"[GPS] optimizer built: tensors={len(gps_params)}, "
        f"gps_lr={gps_lr:g}, backbone_weight_decay=0"
    )


# =============================================================================
# Selection report / activation / restore
# =============================================================================

def selection_json_path(directory, cfg):
    return osp.join(directory, str(cfg.TUNE.GPS.SELECTION_FILE))


def save_selection_report(cfg, report):
    os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
    path = selection_json_path(cfg.OUTPUT_DIR, cfg)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"[GPS] selection report saved to: {path}")


def load_selection_report(directory, cfg):
    path = selection_json_path(directory, cfg)
    if not osp.isfile(path):
        raise FileNotFoundError(
            f"GPS selection file not found: {path}. "
            "Use train_tune_gps.py for both training and tuned evaluation."
        )
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def activate_gps(
    trainer,
    cfg,
    selected_flat_indices=None,
    save_report=True,
):
    backbone = get_gps_backbone(trainer)
    gps_scope = str(cfg.TUNE.GPS.SCOPE)
    gps_k = int(cfg.TUNE.GPS.K)

    importance = None
    calibration_report = {}
    layer_report = {}

    if selected_flat_indices is None:
        print("\n" + "=" * 72)
        print("[GPS] starting gradient-based parameter selection")
        print(f"[GPS] visual scope: {gps_scope}")
        print(f"[GPS] Top-K connections per output neuron/channel: {gps_k}")
        print("=" * 72)

        importance, calibration_report = collect_gps_gradient_importance(
            trainer,
            cfg,
            backbone,
        )
        masks, selected_flat_indices, layer_report = (
            select_gps_topk_per_neuron(
                importance,
                topk_connections=gps_k,
            )
        )
    else:
        selected_flat_indices = {
            str(name): torch.as_tensor(indices, dtype=torch.long)
            for name, indices in selected_flat_indices.items()
        }
        masks = build_masks_from_flat_indices(
            backbone,
            selected_flat_indices,
            gps_scope=gps_scope,
        )

    enable_gps_masked_finetuning(
        trainer,
        backbone,
        masks,
        gps_scope=gps_scope,
    )
    register_gps_checkpoint(
        trainer,
        backbone,
        masks,
        gps_scope=gps_scope,
    )
    build_gps_optimizer_and_scheduler(
        trainer,
        cfg,
        backbone,
        masks,
    )

    summary = gps_effective_parameter_summary(trainer)

    report = {
        "version": 1,
        "method": "GPS",
        "gps_scope": gps_scope,
        "topk_connections_per_neuron": gps_k,
        "calibration": calibration_report,
        "effective_parameter_summary": summary,
        "layer_report": layer_report,
        "selected_flat_indices": {
            str(name): indices.tolist()
            for name, indices in selected_flat_indices.items()
        },
        "warmup_epochs": int(cfg.TUNE.GPS.WARMUP_EPOCHS),
        "calibration_passes": int(cfg.TUNE.GPS.CALIBRATION_PASSES),
        "calibration_batches": int(cfg.TUNE.GPS.CALIBRATION_BATCHES),
    }

    if save_report:
        save_selection_report(cfg, report)

    print(
        "[GPS] effective selected visual params: "
        f"{summary['selected_visual_parameters']:,}"
    )
    print(
        "[GPS] optimizer-visible dense tensor params: "
        f"{summary['optimizer_visible_tensor_parameters']:,}"
    )
    print(
        "[GPS] effective trainable ratio: "
        f"{summary['effective_trainable_ratio_percent']:.4f}%"
    )
    print(
        "[GPS] NOTE: requires_grad counts full candidate tensors; the "
        "scientifically meaningful GPS count is mask.sum() above."
    )
    print("=" * 72 + "\n")

    trainer.gps_active = True
    return report


def restore_gps_structure(
    trainer,
    cfg,
    directory,
    rebuild_optimizer=True,
):
    report = load_selection_report(directory, cfg)

    # Use the saved method settings during restore.
    selected = report["selected_flat_indices"]
    backbone = get_gps_backbone(trainer)
    gps_scope = str(report.get("gps_scope", cfg.TUNE.GPS.SCOPE))

    masks = build_masks_from_flat_indices(
        backbone,
        selected,
        gps_scope=gps_scope,
    )
    enable_gps_masked_finetuning(
        trainer,
        backbone,
        masks,
        gps_scope=gps_scope,
    )
    register_gps_checkpoint(
        trainer,
        backbone,
        masks,
        gps_scope=gps_scope,
    )

    if rebuild_optimizer:
        build_gps_optimizer_and_scheduler(
            trainer,
            cfg,
            backbone,
            masks,
        )

    trainer.gps_active = True
    return report


# =============================================================================
# Training loop
# =============================================================================

def train_with_gps(trainer, cfg):
    warmup_epochs = int(cfg.TUNE.GPS.WARMUP_EPOCHS)
    if warmup_epochs < 0:
        raise ValueError("GPS.WARMUP_EPOCHS cannot be negative")
    if warmup_epochs >= int(cfg.OPTIM.MAX_EPOCH):
        raise ValueError("GPS.WARMUP_EPOCHS must be smaller than OPTIM.MAX_EPOCH")

    # The supplied CoOpGPS trainer is fixed-prompt and owns no stage-1
    # optimizer, so its intended setting is WARMUP_EPOCHS=0.
    if warmup_epochs > 0:
        active_optims = [
            name for name, optim in trainer._optims.items() if optim is not None
        ]
        if not active_optims:
            raise RuntimeError(
                "GPS.WARMUP_EPOCHS > 0 requires a trainer with a stage-1 "
                "optimizer. CoOpGPS_BiomedCLIP uses a fixed prompt; set "
                "TUNE.GPS.WARMUP_EPOCHS=0."
            )

    # Resume stage-2 structure before Dassl loads model/optimizer states.
    if cfg.RESUME:
        resume_selection = selection_json_path(cfg.RESUME, cfg)
        if osp.isfile(resume_selection):
            print("[GPS] restoring masked visual structure before resume")
            restore_gps_structure(
                trainer,
                cfg,
                cfg.RESUME,
                rebuild_optimizer=True,
            )

    trainer.start_epoch = 0
    trainer.max_epoch = int(cfg.OPTIM.MAX_EPOCH)

    # Fixed-prompt CoOpGPS has no stage-1 optimizer.  GPS must therefore be
    # activated BEFORE Dassl.before_train().  activate_gps() registers the
    # only trainable checkpoint object (gps_visual) and immediately attaches
    # a real optimizer/scheduler to it.  This guarantees that
    # TrainerBase.get_current_lr() never sees an optim=None entry.
    #
    # For resume, restore_gps_structure() above has already rebuilt the masked
    # structure and optimizer before before_train() loads checkpoint states.
    if not getattr(trainer, "gps_active", False):
        if warmup_epochs == 0:
            activate_gps(trainer, cfg)
        else:
            raise RuntimeError(
                "Fixed-prompt CoOpGPS requires TUNE.GPS.WARMUP_EPOCHS=0. "
                "A positive GPS warm-up needs a trainer that owns a real "
                "stage-1 optimizer."
            )

    trainer.before_train()

    for trainer.epoch in range(trainer.start_epoch, trainer.max_epoch):
        trainer.before_epoch()
        trainer.run_epoch()

        if (
            not getattr(trainer, "gps_active", False)
            and (trainer.epoch + 1) == warmup_epochs
        ):
            activate_gps(trainer, cfg)

        trainer.after_epoch()

    trainer.after_train()


# =============================================================================
# Config / CLI
# =============================================================================

def extend_gps_cfg(cfg):
    cfg.TUNE = CN()
    cfg.TUNE.GPS = CN()

    cfg.TUNE.GPS.ENABLE = True

    # Fixed CoOp prompt: select GPS connections before epoch 1.
    cfg.TUNE.GPS.WARMUP_EPOCHS = 0

    # Original GPS baseline uses the whole pretrained visual backbone.
    cfg.TUNE.GPS.SCOPE = "all"  # all / ffn / attn
    cfg.TUNE.GPS.K = 1

    # Few-shot calibration. 0 batches = whole train loader each pass.
    cfg.TUNE.GPS.CALIBRATION_PASSES = 1
    cfg.TUNE.GPS.CALIBRATION_BATCHES = 0
    cfg.TUNE.GPS.CALIBRATION_AMP = False

    cfg.TUNE.GPS.LR = 0.0002
    cfg.TUNE.GPS.SELECTION_FILE = "gps_selection.json"


def setup_cfg(args):
    cfg = get_cfg_default()
    base_train.extend_cfg(cfg)
    extend_gps_cfg(cfg)

    if args.dataset_config_file:
        cfg.merge_from_file(args.dataset_config_file)
    if args.config_file:
        cfg.merge_from_file(args.config_file)

    base_train.reset_cfg(cfg, args)
    cfg.merge_from_list(args.opts)
    cfg.freeze()
    return cfg


def main(args):
    cfg = setup_cfg(args)

    if cfg.SEED >= 0:
        print(f"Setting fixed seed: {cfg.SEED}")
        set_random_seed(cfg.SEED)

    setup_logger(cfg.OUTPUT_DIR)

    if torch.cuda.is_available() and cfg.USE_CUDA:
        torch.backends.cudnn.benchmark = True

    base_train.print_args(args, cfg)
    print("Collecting env info ...")
    print("** System info **\n{}\n".format(collect_env_info()))

    trainer = build_trainer(cfg)
    print("Trainer built successfully.")

    if args.eval_only:
        if cfg.TUNE.GPS.ENABLE:
            restore_gps_structure(
                trainer,
                cfg,
                args.model_dir,
                rebuild_optimizer=False,
            )
        trainer.load_model(args.model_dir, epoch=args.load_epoch)
        trainer.test()
        return

    if args.no_train:
        return

    if cfg.TUNE.GPS.ENABLE:
        train_with_gps(trainer, cfg)
    else:
        trainer.train()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=str, default="", help="path to dataset")
    parser.add_argument("--output-dir", type=str, default="", help="output directory")
    parser.add_argument("--resume", type=str, default="", help="checkpoint directory")
    parser.add_argument("--seed", type=int, default=-1)
    parser.add_argument("--source-domains", type=str, nargs="+")
    parser.add_argument("--target-domains", type=str, nargs="+")
    parser.add_argument("--transforms", type=str, nargs="+")
    parser.add_argument("--config-file", type=str, default="")
    parser.add_argument("--dataset-config-file", type=str, default="")
    parser.add_argument("--trainer", type=str, default="")
    parser.add_argument("--backbone", type=str, default="")
    parser.add_argument("--head", type=str, default="")
    parser.add_argument("--eval-only", action="store_true")
    parser.add_argument("--model-dir", type=str, default="")
    parser.add_argument("--load-epoch", type=int)
    parser.add_argument("--no-train", action="store_true")
    parser.add_argument(
        "opts",
        default=None,
        nargs=argparse.REMAINDER,
        help="modify config options from command line",
    )

    main(parser.parse_args())
