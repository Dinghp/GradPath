#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Generic prompt-learning + GradActPaired training entry.

Training protocol
-----------------
Stage 1: ordinary prompt-learning warm-up for TUNE.GRADACT.WARMUP_EPOCHS.
Stage 2: use the few-shot training set to collect |activation * gradient|
         scores at every selected ViT FFN hidden neuron.
Stage 3: select Top-K hidden neurons (or a global budget), replace fc1/fc2
         with paired partial-update layers, and jointly optimize the original
         trainable prompt parameters + selected visual FFN paths.

The code is intentionally trainer-agnostic. A prompt trainer can opt in by
exposing:
    trainer.get_gradact_backbone() -> ViT object with blocks[i].mlp.fc1/fc2
    trainer.gradact_selection_loss(image, label) -> scalar task loss

CoOpTune_BiomedCLIP provides both methods.
"""

import argparse
import copy
import datetime
import json
import math
import os
import os.path as osp
import time
from typing import Dict, Iterable, List, Optional, Sequence

import torch
import torch.nn as nn
from torch.nn import functional as F

from yacs.config import CfgNode as CN

from dassl.config import get_cfg_default
from dassl.engine import build_trainer
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.utils import setup_logger, set_random_seed, collect_env_info

# Reuse all dataset/trainer registrations and the original CLI config fields.
import train as base_train

# Tuned trainers are imported here only for registry side effects.
import trainers.CoOp.coop_biomedclip_GradPath  # noqa: F401


# -----------------------------------------------------------------------------
# Partial paired FFN layers
# -----------------------------------------------------------------------------

class _PartialRowLinearFunction(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        x: torch.Tensor,
        weight: torch.Tensor,
        bias: Optional[torch.Tensor],
        selected_rows: torch.Tensor,
        selected_bias: Optional[torch.Tensor],
        selected_indices: torch.Tensor,
        scaling: float,
    ) -> torch.Tensor:
        ctx.scaling = float(scaling)
        ctx.row_parameter_dtype = selected_rows.dtype
        ctx.bias_parameter_dtype = (
            selected_bias.dtype if selected_bias is not None else None
        )
        ctx.has_selected_bias = selected_bias is not None
        ctx.save_for_backward(x, weight, selected_indices)
        return F.linear(x, weight, bias)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        x, weight, selected_indices = ctx.saved_tensors

        grad_x = None
        grad_selected_rows = None
        grad_selected_bias = None

        if ctx.needs_input_grad[0]:
            grad_x = torch.matmul(
                grad_output,
                weight.to(dtype=grad_output.dtype),
            )

        selected_grad_output = None
        if ctx.needs_input_grad[3] or ctx.needs_input_grad[4]:
            selected_grad_output = grad_output.index_select(
                dim=-1,
                index=selected_indices,
            )

        if ctx.needs_input_grad[3]:
            grad2d = selected_grad_output.reshape(
                -1, selected_grad_output.shape[-1]
            )
            x2d = x.reshape(-1, x.shape[-1])
            grad_selected_rows = grad2d.float().transpose(0, 1) @ x2d.float()
            grad_selected_rows.mul_(ctx.scaling)
            grad_selected_rows = grad_selected_rows.to(ctx.row_parameter_dtype)

        if ctx.needs_input_grad[4] and ctx.has_selected_bias:
            reduce_dims = tuple(range(selected_grad_output.ndim - 1))
            grad_selected_bias = selected_grad_output.float().sum(dim=reduce_dims)
            grad_selected_bias.mul_(ctx.scaling)
            grad_selected_bias = grad_selected_bias.to(ctx.bias_parameter_dtype)

        return (
            grad_x,
            None,
            None,
            grad_selected_rows,
            grad_selected_bias,
            None,
            None,
        )


class _PartialColumnLinearFunction(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        x: torch.Tensor,
        weight: torch.Tensor,
        bias: Optional[torch.Tensor],
        selected_columns: torch.Tensor,
        selected_indices: torch.Tensor,
        scaling: float,
    ) -> torch.Tensor:
        selected_x = x.index_select(dim=-1, index=selected_indices)
        ctx.scaling = float(scaling)
        ctx.parameter_dtype = selected_columns.dtype
        ctx.save_for_backward(selected_x, weight)
        return F.linear(x, weight, bias)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        selected_x, weight = ctx.saved_tensors

        grad_x = None
        grad_selected_columns = None

        if ctx.needs_input_grad[0]:
            grad_x = torch.matmul(
                grad_output,
                weight.to(dtype=grad_output.dtype),
            )

        if ctx.needs_input_grad[3]:
            grad_output_2d = grad_output.reshape(-1, grad_output.shape[-1])
            selected_x_2d = selected_x.reshape(-1, selected_x.shape[-1])
            grad_selected_columns = (
                grad_output_2d.float().transpose(0, 1) @ selected_x_2d.float()
            )
            grad_selected_columns.mul_(ctx.scaling)
            grad_selected_columns = grad_selected_columns.to(ctx.parameter_dtype)

        return (
            grad_x,
            None,
            None,
            grad_selected_columns,
            None,
            None,
        )


class PartialRowLinear(nn.Module):
    """Freeze a Linear layer except selected output rows (+ optional bias)."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        selected_indices: torch.Tensor,
        bias: bool = True,
        update_selected_bias: bool = False,
        alpha: Optional[float] = None,
        device=None,
        dtype=None,
    ):
        super().__init__()

        indices = torch.as_tensor(
            selected_indices,
            dtype=torch.long,
            device="cpu",
        ).flatten()
        if indices.numel() == 0:
            raise ValueError("selected_indices cannot be empty")
        if indices.unique().numel() != indices.numel():
            raise ValueError("selected_indices must not contain duplicates")
        if indices.min().item() < 0 or indices.max().item() >= out_features:
            raise ValueError("selected row index is out of range")

        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.rank = int(indices.numel())
        self.alpha = float(alpha if alpha is not None else self.rank)
        self.scaling = self.alpha / self.rank
        self.update_selected_bias = bool(update_selected_bias and bias)

        self.weight = nn.Parameter(
            torch.empty(out_features, in_features, device=device, dtype=dtype),
            requires_grad=False,
        )
        if bias:
            self.bias = nn.Parameter(
                torch.empty(out_features, device=device, dtype=dtype),
                requires_grad=False,
            )
        else:
            self.register_parameter("bias", None)

        self.register_buffer("selected_indices", indices, persistent=True)
        self.selected_rows = nn.Parameter(
            torch.empty(self.rank, in_features, device=device, dtype=dtype),
            requires_grad=True,
        )

        if self.update_selected_bias:
            self.selected_bias = nn.Parameter(
                torch.empty(self.rank, device=device, dtype=dtype),
                requires_grad=True,
            )
        else:
            self.register_parameter("selected_bias", None)

    @classmethod
    def from_linear(
        cls,
        linear: nn.Linear,
        selected_indices: torch.Tensor,
        update_selected_bias: bool = False,
        alpha: Optional[float] = None,
    ):
        layer = cls(
            linear.in_features,
            linear.out_features,
            selected_indices,
            bias=linear.bias is not None,
            update_selected_bias=update_selected_bias,
            alpha=alpha,
            device=linear.weight.device,
            dtype=linear.weight.dtype,
        )

        with torch.no_grad():
            layer.weight.copy_(linear.weight)
            if linear.bias is not None:
                layer.bias.copy_(linear.bias)

            idx = layer.selected_indices.to(layer.weight.device)
            rows = layer.weight.index_select(0, idx)
            layer.selected_rows.copy_(rows / layer.scaling)

            if layer.selected_bias is not None:
                bias_values = layer.bias.index_select(0, idx)
                layer.selected_bias.copy_(bias_values / layer.scaling)

            layer.sync_weight()

        return layer

    @torch.no_grad()
    def sync_weight(self):
        idx = self.selected_indices.to(self.weight.device)
        rows = self.scaling * self.selected_rows
        self.weight.index_copy_(
            0,
            idx,
            rows.to(device=self.weight.device, dtype=self.weight.dtype),
        )

        if self.selected_bias is not None:
            values = self.scaling * self.selected_bias
            self.bias.index_copy_(
                0,
                idx,
                values.to(device=self.bias.device, dtype=self.bias.dtype),
            )

    def forward(self, x):
        self.sync_weight()
        idx = self.selected_indices.to(x.device)
        return _PartialRowLinearFunction.apply(
            x,
            self.weight,
            self.bias,
            self.selected_rows,
            self.selected_bias,
            idx,
            self.scaling,
        )


class PartialColumnLinear(nn.Module):
    """Freeze a Linear layer except selected input columns."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        selected_indices: torch.Tensor,
        bias: bool = True,
        alpha: Optional[float] = None,
        device=None,
        dtype=None,
    ):
        super().__init__()

        indices = torch.as_tensor(
            selected_indices,
            dtype=torch.long,
            device="cpu",
        ).flatten()
        if indices.numel() == 0:
            raise ValueError("selected_indices cannot be empty")
        if indices.unique().numel() != indices.numel():
            raise ValueError("selected_indices must not contain duplicates")
        if indices.min().item() < 0 or indices.max().item() >= in_features:
            raise ValueError("selected column index is out of range")

        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.rank = int(indices.numel())
        self.alpha = float(alpha if alpha is not None else self.rank)
        self.scaling = self.alpha / self.rank

        self.weight = nn.Parameter(
            torch.empty(out_features, in_features, device=device, dtype=dtype),
            requires_grad=False,
        )
        if bias:
            self.bias = nn.Parameter(
                torch.empty(out_features, device=device, dtype=dtype),
                requires_grad=False,
            )
        else:
            self.register_parameter("bias", None)

        self.register_buffer("selected_indices", indices, persistent=True)
        self.selected_columns = nn.Parameter(
            torch.empty(out_features, self.rank, device=device, dtype=dtype),
            requires_grad=True,
        )

    @classmethod
    def from_linear(
        cls,
        linear: nn.Linear,
        selected_indices: torch.Tensor,
        alpha: Optional[float] = None,
    ):
        layer = cls(
            linear.in_features,
            linear.out_features,
            selected_indices,
            bias=linear.bias is not None,
            alpha=alpha,
            device=linear.weight.device,
            dtype=linear.weight.dtype,
        )

        with torch.no_grad():
            layer.weight.copy_(linear.weight)
            if linear.bias is not None:
                layer.bias.copy_(linear.bias)

            idx = layer.selected_indices.to(layer.weight.device)
            cols = layer.weight.index_select(1, idx)
            layer.selected_columns.copy_(cols / layer.scaling)
            layer.sync_weight()

        return layer

    @torch.no_grad()
    def sync_weight(self):
        idx = self.selected_indices.to(self.weight.device)
        cols = self.scaling * self.selected_columns
        self.weight.index_copy_(
            1,
            idx,
            cols.to(device=self.weight.device, dtype=self.weight.dtype),
        )

    def forward(self, x):
        self.sync_weight()
        idx = self.selected_indices.to(x.device)
        return _PartialColumnLinearFunction.apply(
            x,
            self.weight,
            self.bias,
            self.selected_columns,
            idx,
            self.scaling,
        )


# -----------------------------------------------------------------------------
# GradAct importance collection and selection
# -----------------------------------------------------------------------------

class GradientActivationImportanceCollector:
    def __init__(self, backbone, block_indices: Sequence[int], token_mode="cls"):
        token_mode = token_mode.lower()
        if token_mode not in {"all", "cls", "patch"}:
            raise ValueError("TOKEN_MODE must be one of: all, cls, patch")

        self.backbone = backbone
        self.block_indices = list(block_indices)
        self.token_mode = token_mode
        self.scores: Dict[int, torch.Tensor] = {}
        self.counts: Dict[int, int] = {}
        self.handles = []

        for block_idx in self.block_indices:
            fc2 = backbone.blocks[block_idx].mlp.fc2
            if not isinstance(fc2, nn.Linear):
                raise TypeError(
                    f"Block {block_idx} mlp.fc2 must be nn.Linear before "
                    f"GradAct injection, got {type(fc2).__name__}"
                )

            hidden_dim = fc2.in_features
            self.scores[block_idx] = torch.zeros(
                hidden_dim, dtype=torch.float64, device="cpu"
            )
            self.counts[block_idx] = 0
            self.handles.append(
                fc2.register_forward_hook(self._make_forward_hook(block_idx))
            )

    def _select_tokens(self, x: torch.Tensor):
        if x.ndim != 3 or self.token_mode == "all":
            return x
        if self.token_mode == "cls":
            return x[:, :1, :]
        if x.shape[1] <= 1:
            raise RuntimeError("PATCH token mode requested but no patch tokens exist")
        return x[:, 1:, :]

    def _make_forward_hook(self, block_idx):
        def hook(module, inputs, output):
            del module, output
            hidden = inputs[0]
            if not hidden.requires_grad:
                raise RuntimeError(
                    "FFN hidden activation has no gradient graph. During "
                    "calibration, input images must require gradients."
                )

            activation = hidden.detach()

            def grad_hook(gradient):
                a = self._select_tokens(activation)
                g = self._select_tokens(gradient.detach())
                reduce_dims = tuple(range(a.ndim - 1))
                batch_score = (a.float() * g.float()).abs().sum(dim=reduce_dims)
                sample_count = a.numel() // a.shape[-1]
                self.scores[block_idx].add_(batch_score.double().cpu())
                self.counts[block_idx] += int(sample_count)

            hidden.register_hook(grad_hook)

        return hook

    def normalized_scores(self):
        out = {}
        for block_idx in self.block_indices:
            count = max(self.counts[block_idx], 1)
            out[block_idx] = (self.scores[block_idx] / count).float()
        return out

    def close(self):
        for h in self.handles:
            h.remove()
        self.handles.clear()


def _parse_train_batch(trainer, batch):
    parsed = trainer.parse_batch_train(batch)
    if not isinstance(parsed, (tuple, list)) or len(parsed) < 2:
        raise TypeError(
            "trainer.parse_batch_train(batch) must return at least (image, label)"
        )
    return parsed[0], parsed[1]


def collect_gradact_importance(trainer, cfg, backbone, block_indices):
    tune_cfg = cfg.TUNE.GRADACT
    passes = int(tune_cfg.CALIBRATION_PASSES)
    max_batches = int(tune_cfg.CALIBRATION_BATCHES)
    use_amp = bool(tune_cfg.CALIBRATION_AMP and trainer.device.type == "cuda")

    if passes <= 0:
        raise ValueError("CALIBRATION_PASSES must be positive")

    collector = GradientActivationImportanceCollector(
        backbone,
        block_indices,
        token_mode=tune_cfg.TOKEN_MODE,
    )

    # Snapshot exact flags; calibration should not update any parameter.
    model = trainer.model
    params = list(model.parameters())
    requires_grad_flags = [p.requires_grad for p in params]
    module_training_flags = [(m, m.training) for m in model.modules()]

    for p in params:
        p.requires_grad_(False)
    model.eval()

    total_batches = 0
    try:
        for pass_idx in range(passes):
            print(
                f"[GradAct] calibration pass {pass_idx + 1}/{passes} "
                f"(max_batches={max_batches if max_batches > 0 else 'all'})"
            )

            for batch_idx, batch in enumerate(trainer.train_loader_x):
                if max_batches > 0 and batch_idx >= max_batches:
                    break

                image, label = _parse_train_batch(trainer, batch)
                image = image.detach().requires_grad_(True)

                model.zero_grad(set_to_none=True)
                with torch.cuda.amp.autocast(enabled=use_amp):
                    if hasattr(trainer, "gradact_selection_loss"):
                        loss = trainer.gradact_selection_loss(image, label)
                    else:
                        logits = model(image)
                        loss = F.cross_entropy(logits, label)

                if loss.ndim != 0:
                    loss = loss.mean()
                loss.backward()
                total_batches += 1

        if total_batches == 0:
            raise RuntimeError("GradAct calibration consumed zero batches")

    finally:
        collector.close()
        model.zero_grad(set_to_none=True)

        for p, flag in zip(params, requires_grad_flags):
            p.requires_grad_(flag)

        # Restore each module's previous training flag without recursive train().
        for module, flag in module_training_flags:
            module.training = flag

    scores = collector.normalized_scores()
    print(f"[GradAct] collected importance from {total_batches} batches")
    return scores


def select_topk_per_block(importance_scores, rank_per_block):
    rank_per_block = int(rank_per_block)
    if rank_per_block <= 0:
        raise ValueError("RANK_PER_BLOCK must be positive")

    selected = {}
    for block_idx, score in importance_scores.items():
        if rank_per_block > score.numel():
            raise ValueError(
                f"RANK_PER_BLOCK={rank_per_block} > FFN hidden dim "
                f"{score.numel()} at block {block_idx}"
            )
        indices = torch.topk(
            score,
            k=rank_per_block,
            largest=True,
            sorted=False,
        ).indices
        selected[block_idx] = indices.sort().values.cpu()
    return selected


def _normalize_score(score: torch.Tensor, mode: str, eps=1e-8):
    score = score.detach().float().cpu()
    mode = mode.lower()
    if mode == "none":
        return score
    if mode == "mean":
        return score / (score.mean().abs() + eps)
    if mode == "l2":
        return score / (score.norm(p=2) + eps)
    if mode == "max":
        return score / (score.abs().max() + eps)
    raise ValueError("NORMALIZE_MODE must be mean, l2, max or none")


def select_with_global_budget(
    importance_scores,
    total_budget,
    min_rank_per_block=1,
    max_rank_per_block=128,
    normalize_mode="mean",
):
    block_indices = sorted(importance_scores)
    if not block_indices:
        raise ValueError("importance_scores is empty")

    total_budget = int(total_budget)
    min_rank_per_block = int(min_rank_per_block)
    max_rank_per_block = int(max_rank_per_block)

    min_budget = min_rank_per_block * len(block_indices)
    max_budget = sum(
        min(max_rank_per_block, importance_scores[b].numel())
        for b in block_indices
    )
    if total_budget < min_budget or total_budget > max_budget:
        raise ValueError(
            f"TOTAL_BUDGET must be in [{min_budget}, {max_budget}], "
            f"got {total_budget}"
        )

    normalized = {
        b: _normalize_score(importance_scores[b], normalize_mode)
        for b in block_indices
    }

    selected_sets = {b: set() for b in block_indices}

    # Guarantee minimum rank in each block first.
    for b in block_indices:
        k = min(min_rank_per_block, normalized[b].numel())
        if k > 0:
            top = torch.topk(normalized[b], k=k, largest=True).indices.tolist()
            selected_sets[b].update(int(i) for i in top)

    remaining = total_budget - sum(len(v) for v in selected_sets.values())

    candidates = []
    for b in block_indices:
        for idx, value in enumerate(normalized[b].tolist()):
            if idx not in selected_sets[b]:
                candidates.append((float(value), b, idx))
    candidates.sort(key=lambda x: x[0], reverse=True)

    for _, b, idx in candidates:
        if remaining <= 0:
            break
        layer_cap = min(max_rank_per_block, normalized[b].numel())
        if len(selected_sets[b]) >= layer_cap:
            continue
        selected_sets[b].add(int(idx))
        remaining -= 1

    if remaining != 0:
        raise RuntimeError(f"Unable to allocate {remaining} global-budget paths")

    return {
        b: torch.tensor(sorted(selected_sets[b]), dtype=torch.long)
        for b in block_indices
    }


def parse_target_blocks(target: str, num_blocks: int):
    target = str(target).strip().lower()
    if target == "all":
        return list(range(num_blocks))

    items = []
    for part in target.split(","):
        part = part.strip()
        if not part:
            continue
        idx = int(part)
        if idx < 0 or idx >= num_blocks:
            raise ValueError(
                f"TARGET_BLOCKS contains invalid block {idx}; "
                f"valid range is [0, {num_blocks - 1}]"
            )
        items.append(idx)

    items = sorted(set(items))
    if not items:
        raise ValueError("TARGET_BLOCKS cannot be empty")
    return items


# -----------------------------------------------------------------------------
# Injection / optimizer / checkpoint helpers
# -----------------------------------------------------------------------------

def get_gradact_backbone(trainer):
    if hasattr(trainer, "get_gradact_backbone"):
        backbone = trainer.get_gradact_backbone()
    else:
        model = trainer.model.module if isinstance(trainer.model, nn.DataParallel) else trainer.model
        if not hasattr(model, "image_encoder"):
            raise AttributeError(
                "Trainer must expose get_gradact_backbone() or model.image_encoder"
            )
        visual = model.image_encoder
        backbone = visual.trunk if hasattr(visual, "trunk") else visual

    if not hasattr(backbone, "blocks"):
        raise AttributeError("GradAct backbone must expose .blocks")
    return backbone


def inject_paired_paths(
    backbone,
    selected_indices,
    update_selected_bias=False,
    fc1_alpha=None,
    fc2_alpha=None,
):
    # Keep the entire visual backbone frozen; only the newly created selected
    # row/column Parameters become trainable.
    for p in backbone.parameters():
        p.requires_grad_(False)

    injected = []
    for block_idx in sorted(selected_indices):
        block = backbone.blocks[block_idx]
        old_fc1 = block.mlp.fc1
        old_fc2 = block.mlp.fc2

        if not isinstance(old_fc1, nn.Linear) or not isinstance(old_fc2, nn.Linear):
            raise TypeError(
                f"Block {block_idx}: expected nn.Linear fc1/fc2 before injection; "
                f"got {type(old_fc1).__name__}/{type(old_fc2).__name__}"
            )
        if old_fc1.out_features != old_fc2.in_features:
            raise ValueError(
                f"Block {block_idx}: fc1.out_features != fc2.in_features"
            )

        indices = selected_indices[block_idx]
        block.mlp.fc1 = PartialRowLinear.from_linear(
            old_fc1,
            selected_indices=indices,
            update_selected_bias=update_selected_bias,
            alpha=fc1_alpha,
        )
        block.mlp.fc2 = PartialColumnLinear.from_linear(
            old_fc2,
            selected_indices=indices,
            alpha=fc2_alpha,
        )
        injected.append(block_idx)

    return injected


def selected_path_parameters(backbone):
    params = []
    for module in backbone.modules():
        if isinstance(module, PartialRowLinear):
            params.append(module.selected_rows)
            if module.selected_bias is not None:
                params.append(module.selected_bias)
        elif isinstance(module, PartialColumnLinear):
            params.append(module.selected_columns)
    return params


class GradActCheckpointState(nn.Module):
    """Checkpoint only the selected trainable FFN tensors, not the full ViT."""

    def __init__(self, backbone):
        super().__init__()
        self.params = nn.ParameterDict()

        for block_idx, block in enumerate(backbone.blocks):
            fc1 = block.mlp.fc1
            fc2 = block.mlp.fc2
            if isinstance(fc1, PartialRowLinear):
                self.params[f"b{block_idx:02d}_fc1_rows"] = fc1.selected_rows
                if fc1.selected_bias is not None:
                    self.params[f"b{block_idx:02d}_fc1_bias"] = fc1.selected_bias
            if isinstance(fc2, PartialColumnLinear):
                self.params[f"b{block_idx:02d}_fc2_cols"] = fc2.selected_columns

        if len(self.params) == 0:
            raise RuntimeError("No selected FFN path parameters found")


def _unique_parameters(params: Iterable[nn.Parameter]):
    out = []
    seen = set()
    for p in params:
        if id(p) not in seen:
            seen.add(id(p))
            out.append(p)
    return out


def _copy_optimizer_state_for_shared_params(old_optim, new_optim, params):
    if old_optim is None:
        return
    for p in params:
        if p in old_optim.state:
            new_optim.state[p] = copy.deepcopy(old_optim.state[p])


def rebuild_optimizer_and_scheduler(
    trainer,
    cfg,
    preexisting_trainable: Sequence[nn.Parameter],
    path_params: Sequence[nn.Parameter],
):
    """Rebuild the trainer's single optimizer after path injection.

    Existing trainable parameters (e.g. CoOp context vectors) keep their
    optimizer state when possible. Selected FFN paths form a separate LR group.
    The second-stage scheduler has no additional warm-up.
    """

    optim_names = [
        name for name, optim in trainer._optims.items() if optim is not None
    ]
    if len(optim_names) != 1:
        raise RuntimeError(
            "Generic train_tune currently expects exactly one registered "
            f"optimizer before GradAct injection, found {optim_names}. "
            "For a multi-optimizer trainer, add a method-specific adapter."
        )

    optim_name = optim_names[0]
    old_optim = trainer._optims[optim_name]

    old_params = _unique_parameters(
        p for p in preexisting_trainable if p.requires_grad
    )
    path_params = _unique_parameters(
        p for p in path_params if p.requires_grad
    )

    old_ids = {id(p) for p in old_params}
    path_ids = {id(p) for p in path_params}
    if old_ids & path_ids:
        raise RuntimeError("Prompt/original and FFN path parameter groups overlap")

    prompt_lr = float(cfg.TUNE.GRADACT.PROMPT_LR)
    ffn_lr = float(cfg.TUNE.GRADACT.FFN_LR)
    # if prompt_lr <= 0:
    #     prompt_lr = float(cfg.OPTIM.LR)
    if ffn_lr <= 0:
        ffn_lr = float(cfg.OPTIM.LR)

    param_groups = []
    if old_params:
        param_groups.append({"params": old_params, "lr": prompt_lr})
    if path_params:
        param_groups.append({"params": path_params, "lr": ffn_lr})
    if not param_groups:
        raise RuntimeError("No trainable parameters remain after GradAct injection")

    stage2_optim_cfg = cfg.OPTIM.clone()
    stage2_optim_cfg.defrost()
    stage2_optim_cfg.STAGED_LR = False
    stage2_optim_cfg.WARMUP_EPOCH = 0
    stage2_optim_cfg.MAX_EPOCH = max(
        1,
        int(cfg.OPTIM.MAX_EPOCH) - int(cfg.TUNE.GRADACT.WARMUP_EPOCHS),
    )
    stage2_optim_cfg.freeze()

    new_optim = build_optimizer(param_groups, stage2_optim_cfg)
    _copy_optimizer_state_for_shared_params(old_optim, new_optim, old_params)
    new_sched = build_lr_scheduler(new_optim, stage2_optim_cfg)

    trainer._optims[optim_name] = new_optim
    trainer._scheds[optim_name] = new_sched

    # Most prompt trainers also access these direct attributes.
    if hasattr(trainer, "optim"):
        trainer.optim = new_optim
    if hasattr(trainer, "sched"):
        trainer.sched = new_sched

    print(
        f"[GradAct] optimizer rebuilt: prompt/original={sum(p.numel() for p in old_params):,}, "
        f"selected_ffn={sum(p.numel() for p in path_params):,}, "
        f"prompt_lr={prompt_lr:g}, ffn_lr={ffn_lr:g}"
    )


def register_gradact_checkpoint(trainer, backbone):
    if "gradact_ffn" in trainer._models:
        return trainer._models["gradact_ffn"]

    state = GradActCheckpointState(backbone)
    trainer.register_model("gradact_ffn", state, None, None)
    return state


def count_trainable(model):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total, trainable


def selection_json_path(directory, cfg):
    return osp.join(directory, str(cfg.TUNE.GRADACT.SELECTION_FILE))


def save_selection_report(cfg, report):
    os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
    path = selection_json_path(cfg.OUTPUT_DIR, cfg)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"[GradAct] selection report saved to: {path}")


def load_selection_report(directory, cfg):
    path = selection_json_path(directory, cfg)
    if not osp.isfile(path):
        raise FileNotFoundError(
            f"GradAct selection file not found: {path}. "
            "Use train_tune.py for both training and tuned evaluation."
        )
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def activate_gradact(trainer, cfg, selected_indices=None, save_report=True):
    """Collect/select (or restore) FFN paths and switch to stage-2 training."""

    backbone = get_gradact_backbone(trainer)
    block_indices = parse_target_blocks(
        cfg.TUNE.GRADACT.TARGET_BLOCKS,
        len(backbone.blocks),
    )

    preexisting_trainable = [
        p for p in trainer.model.parameters() if p.requires_grad
    ]

    importance_scores = None
    if selected_indices is None:
        print("\n" + "=" * 72)
        print("[GradAct] starting gradient-activation calibration")
        print(f"[GradAct] target blocks: {block_indices}")
        print(f"[GradAct] token mode: {cfg.TUNE.GRADACT.TOKEN_MODE}")
        print("=" * 72)

        importance_scores = collect_gradact_importance(
            trainer,
            cfg,
            backbone,
            block_indices,
        )

        if int(cfg.TUNE.GRADACT.TOTAL_BUDGET) > 0:
            selected_indices = select_with_global_budget(
                importance_scores,
                total_budget=cfg.TUNE.GRADACT.TOTAL_BUDGET,
                min_rank_per_block=cfg.TUNE.GRADACT.MIN_RANK_PER_BLOCK,
                max_rank_per_block=cfg.TUNE.GRADACT.MAX_RANK_PER_BLOCK,
                normalize_mode=cfg.TUNE.GRADACT.NORMALIZE_MODE,
            )
        else:
            selected_indices = select_topk_per_block(
                importance_scores,
                rank_per_block=cfg.TUNE.GRADACT.RANK_PER_BLOCK,
            )
    else:
        selected_indices = {
            int(k): torch.as_tensor(v, dtype=torch.long)
            for k, v in selected_indices.items()
        }

    injected = inject_paired_paths(
        backbone,
        selected_indices,
        update_selected_bias=bool(cfg.TUNE.GRADACT.UPDATE_SELECTED_BIAS),
    )

    path_params = selected_path_parameters(backbone)
    rebuild_optimizer_and_scheduler(
        trainer,
        cfg,
        preexisting_trainable=preexisting_trainable,
        path_params=path_params,
    )
    register_gradact_checkpoint(trainer, backbone)

    rank_by_block = {
        str(k): int(v.numel()) for k, v in selected_indices.items()
    }
    mean_score_by_block = {}
    if importance_scores is not None:
        mean_score_by_block = {
            str(k): float(v.mean().item())
            for k, v in importance_scores.items()
        }

    report = {
        "version": 1,
        "method": "GradActPaired",
        "target_blocks": injected,
        "token_mode": str(cfg.TUNE.GRADACT.TOKEN_MODE),
        "rank_by_block": rank_by_block,
        "selected_indices": {
            str(k): v.tolist() for k, v in selected_indices.items()
        },
        "mean_score_by_block": mean_score_by_block,
        "update_selected_bias": bool(cfg.TUNE.GRADACT.UPDATE_SELECTED_BIAS),
        "warmup_epochs": int(cfg.TUNE.GRADACT.WARMUP_EPOCHS),
        "calibration_passes": int(cfg.TUNE.GRADACT.CALIBRATION_PASSES),
        "calibration_batches": int(cfg.TUNE.GRADACT.CALIBRATION_BATCHES),
    }

    if save_report:
        save_selection_report(cfg, report)

    total, trainable = count_trainable(trainer.model)
    print(f"[GradAct] injected blocks: {injected}")
    print(f"[GradAct] selected rank by block: {rank_by_block}")
    print(
        f"[GradAct] trainable model params after injection: "
        f"{trainable:,}/{total:,} ({100.0 * trainable / total:.4f}%)"
    )
    print("=" * 72 + "\n")

    trainer.gradact_active = True
    return report


def restore_gradact_structure(trainer, cfg, directory, rebuild_optimizer=True):
    report = load_selection_report(directory, cfg)
    selected = report["selected_indices"]

    if rebuild_optimizer:
        return activate_gradact(
            trainer,
            cfg,
            selected_indices=selected,
            save_report=False,
        )

    # Evaluation path: injection + lightweight checkpoint registration only.
    backbone = get_gradact_backbone(trainer)
    selected = {
        int(k): torch.as_tensor(v, dtype=torch.long)
        for k, v in selected.items()
    }
    inject_paired_paths(
        backbone,
        selected,
        update_selected_bias=bool(report.get("update_selected_bias", True)),
    )
    register_gradact_checkpoint(trainer, backbone)
    trainer.gradact_active = True
    return report


# -----------------------------------------------------------------------------
# Generic tuned training loop
# -----------------------------------------------------------------------------

def train_with_gradact(trainer, cfg):
    warmup_epochs = int(cfg.TUNE.GRADACT.WARMUP_EPOCHS)
    if warmup_epochs < 0:
        raise ValueError("WARMUP_EPOCHS cannot be negative")
    if warmup_epochs >= int(cfg.OPTIM.MAX_EPOCH):
        raise ValueError("WARMUP_EPOCHS must be smaller than OPTIM.MAX_EPOCH")

    # If resuming a stage-2 run, reconstruct selected FFN modules BEFORE
    # Dassl loads checkpoints/optimizer state in before_train().
    if cfg.RESUME:
        resume_selection = selection_json_path(cfg.RESUME, cfg)
        if osp.isfile(resume_selection):
            print("[GradAct] restoring FFN structure before resume")
            restore_gradact_structure(
                trainer,
                cfg,
                cfg.RESUME,
                rebuild_optimizer=True,
            )

    trainer.start_epoch = 0
    trainer.max_epoch = cfg.OPTIM.MAX_EPOCH
    trainer.before_train()

    # A prompt-only checkpoint resumed at/after the warm-up boundary has no
    # stored selection yet. Calibrate immediately before continuing.
    if (
        not getattr(trainer, "gradact_active", False)
        and trainer.start_epoch >= warmup_epochs
    ):
        activate_gradact(trainer, cfg)

    for trainer.epoch in range(trainer.start_epoch, trainer.max_epoch):
        trainer.before_epoch()
        trainer.run_epoch()

        # Epoch index is zero-based: after epoch 0, epoch+1 == 1.
        if (
            not getattr(trainer, "gradact_active", False)
            and (trainer.epoch + 1) == warmup_epochs
        ):
            activate_gradact(trainer, cfg)

        trainer.after_epoch()

    trainer.after_train()


# -----------------------------------------------------------------------------
# Config / CLI
# -----------------------------------------------------------------------------

def extend_tune_cfg(cfg):
    cfg.TUNE = CN()
    cfg.TUNE.GRADACT = CN()

    cfg.TUNE.GRADACT.ENABLE = True

    # Stage-1 ordinary prompt warm-up. For your current CoOp setup this is 1.
    cfg.TUNE.GRADACT.WARMUP_EPOCHS = 1

    # FFN path selection.
    cfg.TUNE.GRADACT.TARGET_BLOCKS = "all"
    cfg.TUNE.GRADACT.TOKEN_MODE = "all"  # all / cls / patch
    cfg.TUNE.GRADACT.RANK_PER_BLOCK = 64
    cfg.TUNE.GRADACT.TOTAL_BUDGET = 0
    cfg.TUNE.GRADACT.MIN_RANK_PER_BLOCK = 16
    cfg.TUNE.GRADACT.MAX_RANK_PER_BLOCK = 128
    cfg.TUNE.GRADACT.NORMALIZE_MODE = "mean"

    # Few-shot calibration. 0 batches = use the whole train loader each pass.
    cfg.TUNE.GRADACT.CALIBRATION_PASSES = 1
    cfg.TUNE.GRADACT.CALIBRATION_BATCHES = 0
    cfg.TUNE.GRADACT.CALIBRATION_AMP = False

    cfg.TUNE.GRADACT.UPDATE_SELECTED_BIAS = True

    # Separate learning rates: prompt keeps CoOp LR; FFN uses 1/10 LR.
    cfg.TUNE.GRADACT.PROMPT_LR = 0.002
    cfg.TUNE.GRADACT.FFN_LR = 0.0002

    cfg.TUNE.GRADACT.SELECTION_FILE = "gradact_selection.json"


def setup_cfg(args):
    cfg = get_cfg_default()
    base_train.extend_cfg(cfg)
    extend_tune_cfg(cfg)

    if args.dataset_config_file:
        cfg.merge_from_file(args.dataset_config_file)
    if args.config_file:
        cfg.merge_from_file(args.config_file)

    base_train.reset_cfg(cfg, args)
    cfg.merge_from_list(args.opts)
    cfg.freeze()
    return cfg


def main(args):
    cfg = setup_cfg(args)

    if cfg.SEED >= 0:
        print(f"Setting fixed seed: {cfg.SEED}")
        set_random_seed(cfg.SEED)

    setup_logger(cfg.OUTPUT_DIR)

    if torch.cuda.is_available() and cfg.USE_CUDA:
        torch.backends.cudnn.benchmark = True

    base_train.print_args(args, cfg)
    print("Collecting env info ...")
    print("** System info **\n{}\n".format(collect_env_info()))

    trainer = build_trainer(cfg)
    print("Trainer built successfully.")

    if args.eval_only:
        if cfg.TUNE.GRADACT.ENABLE:
            restore_gradact_structure(
                trainer,
                cfg,
                args.model_dir,
                rebuild_optimizer=False,
            )
        trainer.load_model(args.model_dir, epoch=args.load_epoch)
        trainer.test()
        return

    if args.no_train:
        return

    if cfg.TUNE.GRADACT.ENABLE:
        train_with_gradact(trainer, cfg)
    else:
        trainer.train()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=str, default="", help="path to dataset")
    parser.add_argument("--output-dir", type=str, default="", help="output directory")
    parser.add_argument("--resume", type=str, default="", help="checkpoint directory")
    parser.add_argument("--seed", type=int, default=-1)
    parser.add_argument("--source-domains", type=str, nargs="+")
    parser.add_argument("--target-domains", type=str, nargs="+")
    parser.add_argument("--transforms", type=str, nargs="+")
    parser.add_argument("--config-file", type=str, default="")
    parser.add_argument("--dataset-config-file", type=str, default="")
    parser.add_argument("--trainer", type=str, default="")
    parser.add_argument("--backbone", type=str, default="")
    parser.add_argument("--head", type=str, default="")
    parser.add_argument("--eval-only", action="store_true")
    parser.add_argument("--model-dir", type=str, default="")
    parser.add_argument("--load-epoch", type=int)
    parser.add_argument("--no-train", action="store_true")
    parser.add_argument(
        "opts",
        default=None,
        nargs=argparse.REMAINDER,
        help="modify config options from the command line",
    )
    main(parser.parse_args())
